const Games = [
{
"index": 1,
"jawaban": "Aurora",
"soal": "https://cdn.filestackcontent.com/7E3o7jDTS6dxqbffNTzw"
},
{
"index": 2,
"jawaban": "Akai",
"soal": "https://cdn.filestackcontent.com/menPS7oRtq3Q4SIjSjiG"
},
{
"index": 3,
"jawaban": "Fanny",
"soal": "https://cdn.filestackcontent.com/mHk6dvOES76sI1Pjic21"
},
{
"index": 4,
"jawaban": "Alice",
"soal": "https://cdn.filestackcontent.com/t2c1o2eqToO6MmArrh0C"
},
{
"index": 5,
"jawaban": "Alucard",
"soal": "https://cdn.filestackcontent.com/dVrXEg34RFmaO43QWuaW"
},
{
"index": 6,
"jawaban": "Alpha",
"soal": "https://cdn.filestackcontent.com/OpJEIHEGR2O4WHBL9sPU"
},
{
"index": 7,
"jawaban": "Angela",
"soal": "https://cdn.filestackcontent.com/X8nnL9aTje8VzrfTy30U"
},
{
"index": 8,
"jawaban": "Argus",
"soal": "https://cdn.filestackcontent.com/cZx4BzHEQa2haDQFxjzz"
},
{
"index": 9,
"jawaban": "Balmond",
"soal": "https://cdn.filestackcontent.com/HvHPfeazQImfw3E9t1Nr"
},
{
"index": 10,
"jawaban": "Bruno",
"soal": "https://cdn.filestackcontent.com/Hvj5zYRKevPOTpxLb3aQ"
},
{
"index": 11,
"jawaban": "Belerick",
"soal": "https://cdn.filestackcontent.com/GQSdVtDRF2BcWBCVrhkj"
},
{
"index": 12,
"jawaban": "Bane",
"soal": "https://cdn.filestackcontent.com/hwbYQVJR4W8kNAEGnDVK"
},
{
"index": 13,
"jawaban": "Chou",
"soal": "https://cdn.filestackcontent.com/GB54gWuWR06oT6DT7vyf"
},
{
"index": 14,
"jawaban": "Change",
"soal": "https://cdn.filestackcontent.com/ZxcYT9x8QY6w0ppHxNri"
},
{
"index": 15,
"jawaban": "Claude",
"soal": "https://cdn.filestackcontent.com/jPYvkNCuRk2JMaLeGbRu"
},
{
"index": 16,
"jawaban": "Hilda",
"soal": "https://cdn.filestackcontent.com/mPfBxIUQmyG2nPRrBfzg"
},
{
"index": 17,
"jawaban": "Clint",
"soal": "https://cdn.filestackcontent.com/XOHB4fpORcClqEFodVpk"
},
{
"index": 18,
"jawaban": "Cyclops",
"soal": "https://cdn.filestackcontent.com/nf46sUSdW1L4QUjtyfAr"
},
{
"index": 19,
"jawaban": "Diggie",
"soal": "https://cdn.filestackcontent.com/araF0TgWQmeImEKjeGgJ"
},
{
"index": 20,
"jawaban": "Estes",
"soal": "https://cdn.filestackcontent.com/44POMkMoTRW0QVEBjn2w"
},
{
"index": 21,
"jawaban": "Fanny",
"soal": "https://cdn.filestackcontent.com/ChBSL6T8R4uPcvW4s047"
},
{
"index": 22,
"jawaban": "Eudora",
"soal": "https://cdn.filestackcontent.com/QUgXmNAURmHmtBVAUewN"
},
{
"index": 23,
"jawaban": "Gatotkaca",
"soal": "https://cdn.filestackcontent.com/LdiUiRn8T4KHlp1Mbgnq"
},
{
"index": 24,
"jawaban": "Freya",
"soal": "https://cdn.filestackcontent.com/P0M7GvavQVmnqTeyO59F"
},
{
"index": 25,
"jawaban": "Franco",
"soal": "https://cdn.filestackcontent.com/ljL5NFATnKLsRSaJ2T9t"
},
{
"index": 26,
"jawaban": "Gusion",
"soal": "https://cdn.filestackcontent.com/1CAOEfS2cBV7IWDU5SQw"
},
{
"index": 27,
"jawaban": "Grock",
"soal": "https://cdn.filestackcontent.com/hJjhnB0kRM234NPReqBK"
},
{
"index": 28,
"jawaban": "Alucard",
"soal": "https://cdn.filestackcontent.com/phJBrwiTCejS6iyFhhDt"
},
{
"index": 29,
"jawaban": "Hanabi",
"soal": "https://cdn.filestackcontent.com/pyDu6xh3Rgq1QijNsmUm"
},
{
"index": 30,
"jawaban": "Harith",
"soal": "https://cdn.filestackcontent.com/cJ3ynCnuTeqeKNqtzhZU"
},
{
"index": 31,
"jawaban": "Harley",
"soal": "https://cdn.filestackcontent.com/Ga8ECwD7RuSbDylqWyRQ"
},
{
"index": 32,
"jawaban": "Hayabusa",
"soal": "https://cdn.filestackcontent.com/PGJBwbfEQuN2p3nh4ikY"
},
{
"index": 33,
"jawaban": "Helcurt",
"soal": "https://cdn.filestackcontent.com/zOKNJeMySjaRm2x2HlOO"
},
{
"index": 34,
"jawaban": "Hylos",
"soal": "https://cdn.filestackcontent.com/mejFz86SliccXmdNj27R"
},
{
"index": 35,
"jawaban": "Irithel",
"soal": "https://cdn.filestackcontent.com/p0vD9mqQyqJBifZebA6w"
},
{
"index": 36,
"jawaban": "Johnson",
"soal": "https://cdn.filestackcontent.com/FOIK8qiSkifwWTcyHFGT"
},
{
"index": 37,
"jawaban": "Kadita",
"soal": "https://cdn.filestackcontent.com/NNEIfTJRwyBEj7zJlz0D"
},
{
"index": 38,
"jawaban": "Kagura",
"soal": "https://cdn.filestackcontent.com/CIH8DCTT6eZoqEPSwI9Q"
},
{
"index": 39,
"jawaban": "https://cdn.filestackcontent.com/aesCAB6eTDmOiu5Fkd2b",
"soal": "Karina"
},
{
"index": 40,
"jawaban": "https://cdn.filestackcontent.com/n9vqHW3ROeQWFWKQtxm4",
"soal": "Kaja"
},
{
"index": 41,
"jawaban": "Layla",
"soal": "https://cdn.filestackcontent.com/xeeTqO3yTKGaJnzR7xcw"
},
{
"index": 42,
"jawaban": "Kimmy",
"soal": "https://cdn.filestackcontent.com/6Ly6M8dbRkyBVI5TkaNb"
},
{
"index": 43,
"jawaban": "Lancelot",
"soal": "https://cdn.filestackcontent.com/vtmodv9cRcCSs3eOftV3"
},
{
"index": 44,
"jawaban": "Leomord",
"soal": "https://cdn.filestackcontent.com/IUVkLeO4QxGs163k5HLq"
},
{
"index": 45,
"jawaban": "Lapu lapu",
"soal": "https://cdn.filestackcontent.com/OqaH9LHQ3yTSiVD13dDJ"
},
{
"index": 46,
"jawaban": "Lolita",
"soal": "https://cdn.filestackcontent.com/wKdGELrtTsqLpGUy0HZT"
},
{
"index": 47,
"jawaban": "Lesley",
"soal": "https://cdn.filestackcontent.com/EC24YmbHQ4atUUGFXwcF"
},
{
"index": 48,
"jawaban": "Minotaur",
"soal": "https://cdn.filestackcontent.com/4eNe0mP5TXaFSSGJ3dlt"
},
{
"index": 49,
"jawaban": "Miya",
"soal": "https://cdn.filestackcontent.com/HOCakwpCRuWeMsUPYxsl"
},
{
"index": 50,
"jawaban": "https://cdn.filestackcontent.com/VLXOwHFSne6KDdi3tjZA",
"soal": "Lunox"
},
{
"index": 51,
"jawaban": "Martis",
"soal": "https://cdn.filestackcontent.com/QxVNyrQSyGiuKoVzsstQ"
},
{
"index": 52,
"jawaban": "Minsitthar",
"soal": "https://cdn.filestackcontent.com/JRUAKErS8a1UioEECUPA"
},
{
"index": 53,
"jawaban": "Moskov",
"soal": "https://cdn.filestackcontent.com/Em3pkcbcTiKOORu68WPa"
},
{
"index": 54,
"jawaban": "Natalia",
"soal": "https://cdn.filestackcontent.com/r6Z9GIyQ9aHIwvZ7AyBF"
},
{
"index": 55,
"jawaban": "Pharsa",
"soal": "https://cdn.filestackcontent.com/K4ph0JL3RiN9cUd5SQrO"
},
{
"index": 56,
"jawaban": "Odette",
"soal": "https://cdn.filestackcontent.com/aVHodCDXRGuhiCUM08vG"
},
{
"index": 57,
"jawaban": "Ruby",
"soal": "https://cdn.filestackcontent.com/ipQSWF6LTHqR1ZdHnuJ8"
},
{
"index": 58,
"jawaban": "Roger",
"soal": "https://cdn.filestackcontent.com/8j7UwoaFQAC5g4pOv5zn"
},
{
"index": 59,
"jawaban": "Saber",
"soal": "https://cdn.filestackcontent.com/QJy33nNTPmxyvwAy0A4A"
},
{
"index": 60,
"jawaban": "Sun",
"soal": "https://cdn.filestackcontent.com/40I55t0ESQ2T4mAPkxGI"
},
{
"index": 61,
"jawaban": "Thamuz",
"soal": "https://cdn.filestackcontent.com/LJMAX270TneEt1VKaQSC"
},
{
"index": 62,
"jawaban": "Uranus",
"soal": "https://cdn.filestackcontent.com/wOIehLbwRUKxJqv64BbC"
},
{
"index": 63,
"jawaban": "Vale",
"soal": "https://cdn.filestackcontent.com/Itg0gPXS7mLyECgfZNna"
},
{
"index": 64,
"jawaban": "Tigreal",
"soal": "https://cdn.filestackcontent.com/XhppCRxGTwqqKf0rf8kw"
},
{
"index": 65,
"jawaban": "Yi Sun Shin",
"soal": "https://cdn.filestackcontent.com/ju0KUzVTrKjgrK11bbiw"
},
{
"index": 66,
"jawaban": "Zhask",
"soal": "https://cdn.filestackcontent.com/wxCHGSaRS5GlsUb1OLSA"
},
{
"index": 67,
"jawaban": "Badang",
"soal": "https://cdn.filestackcontent.com/RhiL9LVBShCProdfN5iH"
},
{
"index": 68,
"jawaban": "Kufra",
"soal": "https://cdn.filestackcontent.com/PWSXo0XT1GFd8unIMx7L"
},
{
"index": 69,
"jawaban": "Zilong",
"soal": "https://cdn.filestackcontent.com/4iRrBhxnTi6qr7nATLwu"
},
{
"index": 70,
"jawaban": "Esmeralda",
"soal": "https://cdn.filestackcontent.com/JjlVWJwiQl2jsshMDMYW"
},
{
"index": 71,
"jawaban": "Terizla",
"soal": "https://cdn.filestackcontent.com/kqAhp4t3Qt2GRYMZbJhg"
},
{
"index": 72,
"jawaban": "Guinevere",
"soal": "https://cdn.filestackcontent.com/09ZA38jYRiumqcnSuv1M"
},
{
"index": 73,
"jawaban": "https://cdn.filestackcontent.com/a23NpRIT6yuwJuntP24Q",
"soal": "Granger"
},
{
"index": 74,
"jawaban": "X Borg",
"soal": "https://cdn.filestackcontent.com/bUdeIQqGTAmRhzmRq5Vs"
},
{
"index": 75,
"jawaban": "Dyrroth",
"soal": "https://cdn.filestackcontent.com/mwbv5Eg6RoCHVzcvwFqI"
},
{
"index": 76,
"jawaban": "Lylia",
"soal": "https://cdn.filestackcontent.com/RFzsCPbCQWmb5v7jnmGb"
},
{
"index": 77,
"jawaban": "Masha",
"soal": "https://cdn.filestackcontent.com/haYhnionRxu0fd56zjwV"
},
{
"index": 78,
"jawaban": "Wanwan",
"soal": "https://cdn.filestackcontent.com/QYYAsHCIRjKqEAxy764t"
},
{
"index": 79,
"jawaban": "Ling",
"soal": "https://cdn.filestackcontent.com/OgFhVAeFRXKD3ZCUobI5"
},
{
"index": 80,
"jawaban": "Baxia",
"soal": "https://cdn.filestackcontent.com/P6pb1Z34TKSkw6korqE7"
},
{
"index": 81,
"jawaban": "Atlas",
"soal": "https://cdn.filestackcontent.com/New81cnTuCRbtJUUdFVJ"
},
{
"index": 82,
"jawaban": "Cecilon",
"soal": "https://cdn.filestackcontent.com/KP3m6n5T8So6osRTR2F8"
},
{
"index": 83,
"jawaban": "Carmila",
"soal": "https://cdn.filestackcontent.com/N1RVOPmStSAusARdEE0w"
},
{
"index": 84,
"jawaban": "Popol & Kupa",
"soal": "https://cdn.filestackcontent.com/SCzSiWbT3m243QnaZjC9"
},
{
"index": 85,
"jawaban": "Yu Zhong",
"soal": "https://cdn.filestackcontent.com/pKxkulmOSpuFwLOhQmQQ"
},
{
"index": 86,
"jawaban": "Luo Yi",
"soal": "https://cdn.filestackcontent.com/AcVZ5S1Od0wJBSyd4jQL"
},
{
"index": 87,
"jawaban": "Brody",
"soal": "https://cdn.filestackcontent.com/vmF0WqJMTraHky9Oe4kz"
},
{
"index": 88,
"jawaban": "Barats",
"soal": "https://cdn.filestackcontent.com/TBBX6FRsRhKNbcom8Ejd"
},
{
"index": 89,
"jawaban": "Khaleed",
"soal": "https://cdn.filestackcontent.com/m5J8zThqRlmvrHraLAuA"
},
{
"index": 90,
"jawaban": "Benedetta",
"soal": "https://cdn.filestackcontent.com/diAdXdf0QsCi36IZveqA"
},
{
"index": 91,
"jawaban": "Yve",
"soal": "https://cdn.filestackcontent.com/ySVSnJIAR1WUR6EKkPxX"
},
{
"index": 92,
"jawaban": "Beatrix",
"soal": "https://cdn.filestackcontent.com/b2EijFPTs63boKkMqxki"
},
{
"index": 93,
"jawaban": "Paquito",
"soal": "https://cdn.filestackcontent.com/zTLXFnfYRCiJ7x67p8UA"
},
{
"index": 94,
"jawaban": "Mathilda",
"soal": "https://cdn.filestackcontent.com/8lWkn6l1SmS0fdTvZI4Q"
},
{
"index": 95,
"jawaban": "Nathan",
"soal": "https://cdn.filestackcontent.com/FMzQs4d1TsiQmm881jrk"
},
{
"index": 96,
"jawaban": "Phoveus",
"soal": "https://cdn.filestackcontent.com/ld0atG75RaqbDKAIFqgL"
},
{
"index": 97,
"jawaban": "Gloo",
"soal": "https://cdn.filestackcontent.com/MZmW1ZknRnKE8ooDijA1"
},
{
"index": 98,
"jawaban": "Floryn",
"soal": "https://cdn.filestackcontent.com/rtca9UcSgWp2KEir5EW5"
},
{
"index": 99,
"jawaban": "Aulus",
"soal": "https://cdn.filestackcontent.com/DU18e0kVQdqDLZ9rKAD1"
},
{
"index": 100,
"jawaban": "Akai",
"soal": "https://cdn.filestackcontent.com/l953r6M8QXSvpEGeMuKR"
},
{
"index": 101,
"jawaban": "Alice",
"soal": "https://cdn.filestackcontent.com/UDsCObbZSWNNloDNb97a"
},
{
"index": 102,
"jawaban": "Aldous",
"soal": "https://cdn.filestackcontent.com/0QZNFPQhuyzvyMlobqyw"
},
{
"index": 103,
"jawaban": "Alpha",
"soal": "https://cdn.filestackcontent.com/B0Ht6NMmSduMgWMKkDwK"
},
{
"index": 104,
"jawaban": "Alucard",
"soal": "https://cdn.filestackcontent.com/4pxoKlnwSBCHQKx1L7fV"
},
{
"index": 105,
"jawaban": "Bane",
"soal": "https://cdn.filestackcontent.com/L9rPV5zXQzubaVBhpspR"
},
{
"index": 106,
"jawaban": "Balmond",
"soal": "https://cdn.filestackcontent.com/G8CL07HtQvm2rX8K59Vt"
},
{
"index": 107,
"jawaban": "Aurora",
"soal": "https://cdn.filestackcontent.com/WRCcILXvSMiuABzpynZL"
},
{
"index": 108,
"jawaban": "Argus",
"soal": "https://cdn.filestackcontent.com/myYj1sS0WR6lBo1XSupw"
},
{
"index": 109,
"jawaban": "Belerick",
"soal": "https://cdn.filestackcontent.com/32VsQ9aRUGQXAruC2Sow"
},
{
"index": 110,
"jawaban": "Bruno",
"soal": "https://cdn.filestackcontent.com/12Khr8UsSvGSSUChvGKo"
},
{
"index": 111,
"jawaban": "Change",
"soal": "https://cdn.filestackcontent.com/q7X4zspzRRGsZMPwUAda"
},
{
"index": 112,
"jawaban": "Cyclops",
"soal": "https://cdn.filestackcontent.com/5sFE1MDnTQaC5X9vegAM"
},
{
"index": 113,
"jawaban": "Clint",
"soal": "https://cdn.filestackcontent.com/nTHDBPbQTlWUD6xSvxVT"
},
{
"index": 114,
"jawaban": "Claude",
"soal": "https://cdn.filestackcontent.com/aDOxAy9jT325QsbnnqTk"
},
{
"index": 115,
"jawaban": "Chou",
"soal": "https://cdn.filestackcontent.com/S8wnI11TRdmZ3s4fkSPH"
},
{
"index": 116,
"jawaban": "Franco",
"soal": "https://cdn.filestackcontent.com/r64GQM19Ry2d8efPUszL"
},
{
"index": 117,
"jawaban": "Fanny",
"soal": "https://cdn.filestackcontent.com/vDoYwPGTHeSYT4VaXkNJ"
},
{
"index": 118,
"jawaban": "Eudora",
"soal": "https://cdn.filestackcontent.com/3Dtf2QIYQ9q6csUoAPE7"
},
{
"index": 119,
"jawaban": "Estes",
"soal": "https://cdn.filestackcontent.com/7tAjpgPTcykwxjXi8nyg"
},
{
"index": 120,
"jawaban": "Diggie",
"soal": "https://cdn.filestackcontent.com/OV1jSv7QRnCvQo8n9VfH"
},
{
"index": 121,
"jawaban": "Grock",
"soal": "https://cdn.filestackcontent.com/hBUzWYoAQSyoZpUD99mr"
},
{
"index": 122,
"jawaban": "Gord",
"soal": "https://cdn.filestackcontent.com/OVs3F35CRiWjEZ6bso26"
},
{
"index": 123,
"jawaban": "Gatotkaca",
"soal": "https://cdn.filestackcontent.com/Wfm3uhDcQqWbhAZHU9tZ"
},
{
"index": 124,
"jawaban": "Freya",
"soal": "https://cdn.filestackcontent.com/uYhONTASie8zcVM45ZeQ"
},
{
"index": 125,
"jawaban": "Hanabi",
"soal": "https://cdn.filestackcontent.com/syRiSlPpTFKQjHh3RQDQ"
},
{
"index": 126,
"jawaban": "Harley",
"soal": "https://cdn.filestackcontent.com/1JrFEEDVTvmWYcEChlDF"
},
{
"index": 127,
"jawaban": "Gusion",
"soal": "https://cdn.filestackcontent.com/oBARSEZhROG3Rc3iFXLk"
},
{
"index": 128,
"jawaban": "Harith",
"soal": "https://cdn.filestackcontent.com/uu8zjn7SjqAKKZWs6nXo"
},
{
"index": 129,
"jawaban": "Hylos",
"soal": "https://cdn.filestackcontent.com/IKAZEMClTK6xCqSipXYQ"
},
{
"index": 130,
"jawaban": "Irithel",
"soal": "https://cdn.filestackcontent.com/lRzALlnSSUKCXqlaClUZ"
},
{
"index": 131,
"jawaban": "Hilda",
"soal": "https://cdn.filestackcontent.com/hWKXWigpSpurk0tIzCNT"
},
{
"index": 132,
"jawaban": "Helcurt",
"soal": "https://cdn.filestackcontent.com/WCprjpFAR8WwzG9hRwcs"
},
{
"index": 133,
"jawaban": "Hayabusa",
"soal": "https://cdn.filestackcontent.com/L4dGRqZFS5myeWpZzlz0"
},
{
"index": 134,
"jawaban": "Kadita",
"soal": "https://cdn.filestackcontent.com/uyRy0aycS4OHsgc0ZGOQ"
},
{
"index": 135,
"jawaban": "Kaja",
"soal": "https://cdn.filestackcontent.com/occaIGdjT8GnzxyGs1GY"
},
{
"index": 136,
"jawaban": "Karina",
"soal": "https://cdn.filestackcontent.com/BWM5VlPT6SSQCmnph8XA"
},
{
"index": 137,
"jawaban": "Kagura",
"soal": "https://cdn.filestackcontent.com/BgER4QzjQvaUSlrszeVg"
},
{
"index": 138,
"jawaban": "Johnson",
"soal": "https://cdn.filestackcontent.com/6xNUwfL4Sbuu4TNjbtPV"
},
{
"index": 139,
"jawaban": "Layla",
"soal": "https://cdn.filestackcontent.com/qg4ld3XhRUeMZmw36X6K"
},
{
"index": 140,
"jawaban": "Lancelot",
"soal": "https://cdn.filestackcontent.com/TCuntwsPT2KDIfTodhZg"
},
{
"index": 141,
"jawaban": "Kimmy",
"soal": "https://cdn.filestackcontent.com/jPNWAxjpQSmMpM6JgvNR"
},
{
"index": 142,
"jawaban": "Lapu lapu",
"soal": "https://cdn.filestackcontent.com/9GWY5HeoQWiUerdjSBcV"
},
{
"index": 143,
"jawaban": "Leomord",
"soal": "https://cdn.filestackcontent.com/kcAKYOi0QKzJOExCHoq3"
},
{
"index": 144,
"jawaban": "Lesley",
"soal": "https://cdn.filestackcontent.com/krrRohtZRaSzh3s8HqSU"
},
{
"index": 145,
"jawaban": "Lunox",
"soal": "https://cdn.filestackcontent.com/iAWana0QSCUJ3bfLjZng"
},
{
"index": 146,
"jawaban": "Martis",
"soal": "https://cdn.filestackcontent.com/r5J5cd9dQ3K3HJrgSZUd"
},
{
"index": 147,
"jawaban": "Lolita",
"soal": "https://cdn.filestackcontent.com/J0Iw9iwXShmUQx8ojZQ5"
},
{
"index": 148,
"jawaban": "Minsitthar",
"soal": "https://cdn.filestackcontent.com/trLYCM5BS72lRLa8t8Mm"
},
{
"index": 149,
"jawaban": "Minotaur",
"soal": "https://cdn.filestackcontent.com/AxSa4tTRQJ6ayDegMIgC"
},
{
"index": 150,
"jawaban": "Odette",
"soal": "https://cdn.filestackcontent.com/Yce7DwwPQHurZuY7leAW"
},
{
"index": 151,
"jawaban": "Natalia",
"soal": "https://cdn.filestackcontent.com/VjAntK8IRvul7eavRZvM"
},
{
"index": 152,
"jawaban": "Moskov",
"soal": "https://cdn.filestackcontent.com/15bePMA8Ra3ZvzngvWLM"
},
{
"index": 153,
"jawaban": "Miya",
"soal": "https://cdn.filestackcontent.com/lsrrePR2SWyHK8Vkq5Aw"
},
{
"index": 154,
"jawaban": "Thamuz",
"soal": "https://cdn.filestackcontent.com/i4PHlckNRk2SCf6IIUa8"
},
{
"index": 155,
"jawaban": "Uranus",
"soal": "https://cdn.filestackcontent.com/jZLe11iMRsSK4buoO4TM"
},
{
"index": 156,
"jawaban": "Sun",
"soal": "https://cdn.filestackcontent.com/Xyfo1whBTF6jKix8nYBI"
},
{
"index": 157,
"jawaban": "Ruby",
"soal": "https://cdn.filestackcontent.com/ZPdBSCGrSlCYAXIiV8Bp"
},
{
"index": 158,
"jawaban": "Roger",
"soal": "https://cdn.filestackcontent.com/mpHTk5AuSzOGyVTtuMr7"
},
{
"index": 159,
"jawaban": "Pharsa",
"soal": "https://cdn.filestackcontent.com/nPkh9wqYRZ2NJd8WtzSN"
},
{
"index": 160,
"jawaban": "Saber",
"soal": "https://cdn.filestackcontent.com/NHjhnQ6uQyWlFn0wzODg"
},
{
"index": 161,
"jawaban": "Tigreal",
"soal": "https://cdn.filestackcontent.com/ao36HKeZRii4dMhU6U9Z"
},
{
"index": 162,
"jawaban": "Vale",
"soal": "https://cdn.filestackcontent.com/5mfkvRFSBW7o3lRexOnq"
},
{
"index": 163,
"jawaban": "Yi Sun Shin",
"soal": "https://cdn.filestackcontent.com/OmvqgoRnaBcriGmjatKA"
},
{
"index": 164,
"jawaban": "Zhask",
"soal": "https://cdn.filestackcontent.com/OmvqgoRnaBcriGmjatKA"
},
{
"index": 165,
"jawaban": "Zilong",
"soal": "https://cdn.filestackcontent.com/g95v09hfTlW08om9nmJy"
},
{
"index": 166,
"jawaban": "Badang",
"soal": "https://cdn.filestackcontent.com/hpoe0Suyoz07Q6nUCfA4"
},
{
"index": 167,
"jawaban": "Terizla",
"soal": "https://cdn.filestackcontent.com/Jx7AtmY4QJurE8qEUBft"
},
{
"index": 168,
"jawaban": "Guinevere",
"soal": "https://cdn.filestackcontent.com/GpqbKPhQHqOtOMVRqhEw"
},
{
"index": 169,
"jawaban": "Esmeralda",
"soal": "https://cdn.filestackcontent.com/EJh1CooS86gnpHqzjtXO"
},
{
"index": 170,
"jawaban": "Granger",
"soal": "https://cdn.filestackcontent.com/Bh2vHsMNTIyTADbJC7wd"
},
{
"index": 171,
"jawaban": "Kufra",
"soal": "https://cdn.filestackcontent.com/fAGIrNUVQGafuBEmoH9e"
},
{
"index": 172,
"jawaban": "Lylia",
"soal": "https://cdn.filestackcontent.com/zM8M9Oc4SvCHDUPZAZm3"
},
{
"index": 173,
"jawaban": "Dyrroth",
"soal": "https://cdn.filestackcontent.com/vjZpbWceT423CaxpWa99"
},
{
"index": 174,
"jawaban": "X Borg",
"soal": "https://cdn.filestackcontent.com/3HbfvYmAQXac7AkuujRv"
},
{
"index": 175,
"jawaban": "Masha",
"soal": "https://cdn.filestackcontent.com/o1Huofj0R8iOdUDTtFmg"
},
{
"index": 176,
"jawaban": "Baxia",
"soal": "https://cdn.filestackcontent.com/MeYkfn1IRh6ZcbbUPmfw"
},
{
"index": 177,
"jawaban": "Carmila",
"soal": "https://cdn.filestackcontent.com/6jwAhfVISH6lascwgxXh"
},
{
"index": 178,
"jawaban": "Cecilon",
"soal": "https://cdn.filestackcontent.com/Nf3pWbdJRUmyugmuspnQ"
},
{
"index": 179,
"jawaban": "Silvana",
"soal": "https://cdn.filestackcontent.com/kaNtWLUhSYeA2PmMkKTA"
},
{
"index": 180,
"jawaban": "Wanwan",
"soal": "https://cdn.filestackcontent.com/slv4jY7WRv20mdDWlESQ"
},
{
"index": 181,
"jawaban": "Ling",
"soal": "https://cdn.filestackcontent.com/QMq30fWQRj6pchBJuXcp"
},
{
"index": 182,
"jawaban": "Yu Zhong",
"soal": "https://cdn.filestackcontent.com/Iw5Oojf3RTG7U19t6EwS"
},
{
"index": 183,
"jawaban": "Luo Yi",
"soal": "https://cdn.filestackcontent.com/WMQzfZtZRRuQT2vWYPCe"
},
{
"index": 184,
"jawaban": "Benedetta",
"soal": "https://cdn.filestackcontent.com/rRnB7JotRLymvhO04ulm"
},
{
"index": 185,
"jawaban": "Barats",
"soal": "https://cdn.filestackcontent.com/STjQsqoeR2aSVV7kJ1jG"
},
{
"index": 186,
"jawaban": "Popol & Kupa",
"soal": "https://cdn.filestackcontent.com/LQl5OxOLT9aXp1UIlYbj"
},
{
"index": 187,
"jawaban": "Atlas",
"soal": "https://cdn.filestackcontent.com/EneaaatRpGu9fRSpEMnf"
},
{
"index": 188,
"jawaban": "Brody",
"soal": "https://cdn.filestackcontent.com/YL3jeSoxShO34rrdaXFZ"
},
{
"index": 189,
"jawaban": "Yve",
"soal": "https://cdn.filestackcontent.com/XB1mZQXSQjC1DV2NHWsB"
},
{
"index": 190,
"jawaban": "Yve",
"soal": "https://cdn.filestackcontent.com/4wZXjMcUT7GTBlr34MBY"
},
{
"index": 191,
"jawaban": "Brody",
"soal": "https://cdn.filestackcontent.com/KjXGpXFvR7qqy8y3qDfI"
},
{
"index": 192,
"jawaban": "Brody",
"soal": "https://cdn.filestackcontent.com/iriwPpcVSLescttG7xkP"
},
{
"index": 193,
"jawaban": "Luo Yi",
"soal": "https://cdn.filestackcontent.com/cMfYMDaKQtGfmLuyf95Z"
},
{
"index": 194,
"jawaban": "Luo Yi",
"soal": "https://cdn.filestackcontent.com/WAuQXLjxQSS0NdvKIXkt"
},
{
"index": 195,
"jawaban": "Luo Yi",
"soal": "https://cdn.filestackcontent.com/oEwf3bWLRyevbo04h8W4"
},
{
"index": 196,
"jawaban": "Yu Zhong",
"soal": "https://cdn.filestackcontent.com/VO8k6WRuRFO5c0F2CNH5"
},
{
"index": 197,
"jawaban": "Yu Zhong",
"soal": "https://cdn.filestackcontent.com/ZJf0GZq0TG6li2TORGuM"
},
{
"index": 198,
"jawaban": "Yu Zhong",
"soal": "https://cdn.filestackcontent.com/fFHmWR1TOm8s5nHYjL55"
},
{
"index": 199,
"jawaban": "Benedetta",
"soal": "https://cdn.filestackcontent.com/XnuarvQRTWjiyJcdlDnW"
},
{
"index": 200,
"jawaban": "Benedetta",
"soal": "https://cdn.filestackcontent.com/lye2H0QvS5mz96qZuTOz"
},
{
"index": 201,
"jawaban": "Benedetta",
"soal": "https://cdn.filestackcontent.com/cKerLJ2ETBq1Xi7ZmJy7"
},
{
"index": 202,
"jawaban": "Silvana",
"soal": "https://cdn.filestackcontent.com/YGwHW5kQDONZShItoSQb"
},
{
"index": 203,
"jawaban": "Silvana",
"soal": "https://cdn.filestackcontent.com/S1B4z9lSHqLNm13lLIin"
},
{
"index": 204,
"jawaban": "Silvana",
"soal": "https://cdn.filestackcontent.com/XJTgJZmURTCRxJQq3p2f"
},
{
"index": 205,
"jawaban": "Silvana",
"soal": "https://cdn.filestackcontent.com/PMuRXZNZQ0y2ItsVhFxu"
},
{
"index": 206,
"jawaban": "Ling",
"soal": "https://cdn.filestackcontent.com/3ZU30McyTZyf2ALxeaPg"
},
{
"index": 207,
"jawaban": "Ling",
"soal": "https://cdn.filestackcontent.com/eADIDGfeTN3JjFD1pDnQ"
},
{
"index": 208,
"jawaban": "Ling",
"soal": "https://cdn.filestackcontent.com/zMRsCx7FTrKuM0waOSge"
},
{
"index": 209,
"jawaban": "Wanwan",
"soal": "https://cdn.filestackcontent.com/a6htZzMFTnmTKKT2p4gN"
},
{
"index": 210,
"jawaban": "Wanwan",
"soal": "https://cdn.filestackcontent.com/xOwrnGG0RQm1DX2RnLgH"
},
{
"index": 211,
"jawaban": "Wanwan",
"soal": "https://cdn.filestackcontent.com/xdl2nbsKQqivhxvQDooI"
},
{
"index": 212,
"jawaban": "Carmila",
"soal": "https://cdn.filestackcontent.com/LlJMns5JTba00dbnemM5"
},
{
"index": 213,
"jawaban": "Carmila",
"soal": "https://cdn.filestackcontent.com/X2f4xwsTTySL7lIrxdnM"
},
{
"index": 214,
"jawaban": "Carmila",
"soal": "https://cdn.filestackcontent.com/bm0h2A64TVusUkOixiiT"
},
{
"index": 215,
"jawaban": "Cecilion",
"soal": "https://cdn.filestackcontent.com/Hz0LEkETimV88QywcPIS"
},
{
"index": 216,
"jawaban": "Cecilion",
"soal": "https://cdn.filestackcontent.com/VRau8D0dQcaUCu3Sj53p"
},
{
"index": 217,
"jawaban": "Cecilion",
"soal": "https://cdn.filestackcontent.com/paAcL8THQ76zYIDuedLo"
},
{
"index": 218,
"jawaban": "Baxia",
"soal": "https://cdn.filestackcontent.com/vXBKDk6pQP3g2dn8xM8D"
},
{
"index": 219,
"jawaban": "Baxia",
"soal": "https://cdn.filestackcontent.com/ffU33xTXQ0aFwsAiZF4u"
},
{
"index": 220,
"jawaban": "Baxia",
"soal": "https://cdn.filestackcontent.com/l9IFzyeUSq2SK1I4UpzF"
},
{
"index": 221,
"jawaban": "Masha",
"soal": "https://cdn.filestackcontent.com/dkscSV6ARA1bWJrhwS4K"
},
{
"index": 222,
"jawaban": "Masha",
"soal": "https://cdn.filestackcontent.com/PdRi28gYTPEx9CQ5ZHgc"
},
{
"index": 223,
"jawaban": "Lylia",
"soal": "https://cdn.filestackcontent.com/XNFPT1G0TxSdMpfNaBks"
},
{
"index": 224,
"jawaban": "Dyrroth",
"soal": "https://cdn.filestackcontent.com/VXzsYd9pQFiMpURiUU6j"
},
{
"index": 225,
"jawaban": "Dyrroth",
"soal": "https://cdn.filestackcontent.com/TzIoM6ikR3i5pxt8FDSn"
},
{
"index": 226,
"jawaban": "Dyrroth",
"soal": "https://cdn.filestackcontent.com/5B5VMoBzS4KY5I655LqN"
},
{
"index": 227,
"jawaban": "X Borg",
"soal": "https://cdn.filestackcontent.com/J1huwUKBTmeTIQqyZ6t4"
},
{
"index": 228,
"jawaban": "Granger",
"soal": "https://cdn.filestackcontent.com/rMeaTVuSSqB6VNgZiNwL"
},
{
"index": 229,
"jawaban": "Granger",
"soal": "https://cdn.filestackcontent.com/uZzoMqbT9SiJRcCjZxID"
},
{
"index": 230,
"jawaban": "Granger",
"soal": "https://cdn.filestackcontent.com/SRlEYjTOQXewq21jOLGK"
},
{
"index": 231,
"jawaban": "Guinevere",
"soal": "https://cdn.filestackcontent.com/CuBRu7pPQea8P8Da7QT3"
},
{
"index": 232,
"jawaban": "Guinevere",
"soal": "https://cdn.filestackcontent.com/jt6htVl8QQiKKz6K7My8"
},
{
"index": 233,
"jawaban": "Guinevere",
"soal": "https://cdn.filestackcontent.com/6oa3qbQxiyFlw9h9SdIg"
},
{
"index": 234,
"jawaban": "Terizla",
"soal": "https://cdn.filestackcontent.com/uTvqBXDRA2YMl0JhCEbc"
},
{
"index": 235,
"jawaban": "Terizla",
"soal": "https://cdn.filestackcontent.com/f3d0tWXRyiaxD1Nhwuia"
},
{
"index": 236,
"jawaban": "Terizla",
"soal": "https://cdn.filestackcontent.com/E6fYFmHBRAaQ4lYGB1Od"
},
{
"index": 237,
"jawaban": "Terizla",
"soal": "https://cdn.filestackcontent.com/KOhWF8rVQQysVq12OGzF"
},
{
"index": 238,
"jawaban": "Esmeralda",
"soal": "https://cdn.filestackcontent.com/Opk9P4XTkqJrb8bIc3qA"
},
{
"index": 239,
"jawaban": "Kufra",
"soal": "https://cdn.filestackcontent.com/490swHRYRPq49KQBFtPf"
},
{
"index": 240,
"jawaban": "Kufra",
"soal": "https://cdn.filestackcontent.com/kBkq8IhbSAGoZjw4qqQP"
},
{
"index": 241,
"jawaban": "Kufra",
"soal": "https://cdn.filestackcontent.com/hEtKjlNnRjCyjbWJTD73"
},
{
"index": 242,
"jawaban": "Kufra",
"soal": "https://cdn.filestackcontent.com/C53XRFgBSvG4PpVHhHRK"
},
{
"index": 243,
"jawaban": "Pharsa",
"soal": "https://cdn.filestackcontent.com/GAJ7ORs7TxqXU7bU1VNG"
},
{
"index": 244,
"jawaban": "Pharsa",
"soal": "https://cdn.filestackcontent.com/hQumzPCvRO2wKzJobygc"
},
{
"index": 245,
"jawaban": "Pharsa",
"soal": "https://cdn.filestackcontent.com/n4934lLnRNC07yJRquHr"
},
{
"index": 246,
"jawaban": "Odette",
"soal": "https://cdn.filestackcontent.com/0TwwiBxjSbyzr1gIxYTg"
},
{
"index": 247,
"jawaban": "Odette",
"soal": "https://cdn.filestackcontent.com/NkolqghPSQuSjx1Y64ZQ"
},
{
"index": 248,
"jawaban": "Odette",
"soal": "https://cdn.filestackcontent.com/W9zk5WSWQqaJlU338Diy"
},
{
"index": 249,
"jawaban": "Kadita",
"soal": "https://cdn.filestackcontent.com/3KAqUXKbRRKG99dOfxOF"
},
{
"index": 250,
"jawaban": "Kadita",
"soal": "https://cdn.filestackcontent.com/9nMU17RySNiGtpFGZK3g"
},
{
"index": 251,
"jawaban": "Kadita",
"soal": "https://cdn.filestackcontent.com/ruTzZYisRo65I6PbZ2dx"
},
{
"index": 252,
"jawaban": "Lesley",
"soal": "https://cdn.filestackcontent.com/l2oUcRl9S6l8UzhMoD7s"
},
{
"index": 253,
"jawaban": "Lesley",
"soal": "https://cdn.filestackcontent.com/r5eUF8WURY6umq52Pn9j"
},
{
"index": 254,
"jawaban": "Lesley",
"soal": "https://cdn.filestackcontent.com/XUUAPz1TSqDmeUY4hH2R"
},
{
"index": 255,
"jawaban": "Karina",
"soal": "https://cdn.filestackcontent.com/l4EG8llRTl2iuMcWBIN3"
},
{
"index": 256,
"jawaban": "Karina",
"soal": "https://cdn.filestackcontent.com/jD8PWQFQXKQdZCzDxBNe"
},
{
"index": 257,
"jawaban": "Karina",
"soal": "https://cdn.filestackcontent.com/eHejdi1mRom5c7NAMUhz"
},
{
"index": 258,
"jawaban": "Harley",
"soal": "https://cdn.filestackcontent.com/uOOmIR6TRYqDxOHIbBdg"
},
{
"index": 259,
"jawaban": "Harley",
"soal": "https://cdn.filestackcontent.com/DrcWjxDrSiaNIXKyM3X2"
},
{
"index": 260,
"jawaban": "Harley",
"soal": "https://cdn.filestackcontent.com/oIxI4hZRTluZ9l3WB5OI"
},
{
"index": 261,
"jawaban": "Eudora",
"soal": "https://cdn.filestackcontent.com/30putr5rSxmc6ZeIrfF5"
},
{
"index": 262,
"jawaban": "Eudora",
"soal": "https://cdn.filestackcontent.com/dpASEig9TYem2GYdfGFp"
},
{
"index": 263,
"jawaban": "Eudora",
"soal": "https://cdn.filestackcontent.com/4YVZhnjIRJOOTblELk12"
},
{
"index": 264,
"jawaban": "Fanny",
"soal": "https://cdn.filestackcontent.com/AZU8iYISQvmlp71cNQwv"
},
{
"index": 265,
"jawaban": "Fanny",
"soal": "https://cdn.filestackcontent.com/3EotZFu3T5ClWbib5oR3"
},
{
"index": 266,
"jawaban": "Fanny",
"soal": "https://cdn.filestackcontent.com/ttsxzmKZRMKsWqZbUfs9"
},
{
"index": 267,
"jawaban": "Chou",
"soal": "https://cdn.filestackcontent.com/fNwRX44nRdOU8QhXg8Hc"
},
{
"index": 268,
"jawaban": "Chou",
"soal": "https://cdn.filestackcontent.com/jtW7C7K1QBicEi2xJkAK"
},
{
"index": 269,
"jawaban": "Chou",
"soal": "https://cdn.filestackcontent.com/fuy5XfsMRNqYKcZ6pIdS"
},
{
"index": 270,
"jawaban": "Alice",
"soal": "https://cdn.filestackcontent.com/3lMO66X8QBS9CCipZHNL"
},
{
"index": 271,
"jawaban": "Alice",
"soal": "https://cdn.filestackcontent.com/XxAsmacARRqomSI7nla8"
},
{
"index": 272,
"jawaban": "Alice",
"soal": "https://cdn.filestackcontent.com/0U8guzaGTRGDWD2wVpag"
},
{
"index": 273,
"jawaban": "Balmond",
"soal": "https://cdn.filestackcontent.com/nPvBsHIRHeKkmx1Yg0jy"
},
{
"index": 274,
"jawaban": "Balmond",
"soal": "https://cdn.filestackcontent.com/PHgdgRJmTwOsUVFhms6w"
},
{
"index": 275,
"jawaban": "Balmond",
"soal": "https://cdn.filestackcontent.com/oTHVmcJRTiePN9QX9DmX"
},
{
"index": 276,
"jawaban": "Aldous",
"soal": "https://cdn.filestackcontent.com/Lh4heWzSiyAO1MUNkbDv"
},
{
"index": 277,
"jawaban": "Aldous",
"soal": "https://cdn.filestackcontent.com/y4HsN7YcR6qJXGRfDs1R"
},
{
"index": 278,
"jawaban": "Aldous",
"soal": "https://cdn.filestackcontent.com/j0WU7oRpRrK4ZqkyEDdj"
},
{
"index": 279,
"jawaban": "Akai",
"soal": "https://cdn.filestackcontent.com/8gmsQ4JS9yAvuFVCM7Uj"
},
{
"index": 280,
"jawaban": "Akai",
"soal": "https://cdn.filestackcontent.com/hSovqxmbSZeMvRHZj5Ah"
},
{
"index": 281,
"jawaban": "Akai",
"soal": "https://cdn.filestackcontent.com/Q3ido9xkRSa3OsrxFf5P"
},
{
"index": 282,
"jawaban": "Aurora",
"soal": "https://cdn.filestackcontent.com/SyZHsshThS06lDPVsREP"
},
{
"index": 283,
"jawaban": "Aurora",
"soal": "https://cdn.filestackcontent.com/V6osvMfmS5bfdojs2E4j"
},
{
"index": 284,
"jawaban": "Aurora",
"soal": "https://cdn.filestackcontent.com/kN37pwGTSVy41hD7M3Mg"
},
{
"index": 285,
"jawaban": "Bruno",
"soal": "https://cdn.filestackcontent.com/RoL62oqPRbGra9krreQ4"
},
{
"index": 286,
"jawaban": "Bruno",
"soal": "https://cdn.filestackcontent.com/E7hVkqpQQ4ufSV9nJeeg"
},
{
"index": 287,
"jawaban": "Bruno",
"soal": "https://cdn.filestackcontent.com/zXM8SSeTOrONx2ass9HQ"
},
{
"index": 288,
"jawaban": "Kimmy",
"soal": "https://cdn.filestackcontent.com/yStuVEEjShOsaUREa8gg"
},
{
"index": 289,
"jawaban": "Kimmy",
"soal": "https://cdn.filestackcontent.com/G46Zki1OREmwR5jG7LC6"
},
{
"index": 290,
"jawaban": "Kimmy",
"soal": "https://cdn.filestackcontent.com/vWcGQxfJQzORpvMq5ijY"
},
{
"index": 291,
"jawaban": "Lunox",
"soal": "https://cdn.filestackcontent.com/RnkcExiTTqwnPYO96eEo"
},
{
"index": 292,
"jawaban": "Lunox",
"soal": "https://cdn.filestackcontent.com/KeepUVBRrSQHirj1Sw6y"
},
{
"index": 293,
"jawaban": "Lunox",
"soal": "https://cdn.filestackcontent.com/Ab4Zk6kOTYSmIM75QQnM"
},
{
"index": 294,
"jawaban": "Martis",
"soal": "https://cdn.filestackcontent.com/NSXpQtR7QD6u4zgfNrDD"
},
{
"index": 295,
"jawaban": "Martis",
"soal": "https://cdn.filestackcontent.com/tj3Pfl8vTkOKTc5TY3sD"
},
{
"index": 296,
"jawaban": "Martis",
"soal": "https://cdn.filestackcontent.com/pLxAVyYS4Or970jTjdw4"
},
{
"index": 297,
"jawaban": "Vale",
"soal": "https://cdn.filestackcontent.com/mONEFoa1SESvxcBj6Y7e"
},
{
"index": 298,
"jawaban": "Vale",
"soal": "https://cdn.filestackcontent.com/Egiij8euTvC07mD4ccgW"
},
{
"index": 299,
"jawaban": "Beatrix",
"soal": "https://cdn.filestackcontent.com/FOsU8FxGRqym1K3ARrYX"
},
{
"index": 300,
"jawaban": "Beatrix",
"soal": "https://cdn.filestackcontent.com/7ITxniiIRT6SahHdXfgv"
},
{
"index": 301,
"jawaban": "Beatrix",
"soal": "https://cdn.filestackcontent.com/kpir1tS0RzuMKipX2b5y"
},
{
"index": 302,
"jawaban": "Nathan",
"soal": "https://cdn.filestackcontent.com/DNfFrFkbRU6MSMtBGRtQ"
},
{
"index": 303,
"jawaban": "Nathan",
"soal": "https://cdn.filestackcontent.com/mTi2ZYIwRQeFC7vn5i6k"
},
{
"index": 304,
"jawaban": "Nathan",
"soal": "https://cdn.filestackcontent.com/JRsOnj04To23DcmOOBUF"
},
{
"index": 305,
"jawaban": "Gatotkaca",
"soal": "https://cdn.filestackcontent.com/DQy47PyRDCmA3PZhN8hK"
},
{
"index": 306,
"jawaban": "Gatotkaca",
"soal": "https://cdn.filestackcontent.com/hgTsgty6QnKUUNva74YQ"
},
{
"index": 307,
"jawaban": "Gatotkaca",
"soal": "https://cdn.filestackcontent.com/a6jFqFVJRVanSkf4ci0H"
},
{
"index": 308,
"jawaban": "Paquito",
"soal": "https://cdn.filestackcontent.com/TCwU2deyTSGbBf3pWDm7"
},
{
"index": 309,
"jawaban": "Paquito",
"soal": "https://cdn.filestackcontent.com/EPKZARgyTWOH56NIed7r"
},
{
"index": 310,
"jawaban": "Paquito",
"soal": "https://cdn.filestackcontent.com/RcXotlzJSVqaDg8TrkSm"
},
{
"index": 311,
"jawaban": "Lapu lapu",
"soal": "https://cdn.filestackcontent.com/TYo30vpkSZKVgOfU28vl"
},
{
"index": 312,
"jawaban": "Lapu lapu",
"soal": "https://cdn.filestackcontent.com/M1UO8NSBQ32W2C61jpHp"
},
{
"index": 313,
"jawaban": "Lapu lapu",
"soal": "https://cdn.filestackcontent.com/9uaJ5wNHS9CuPgCpARt3"
},
{
"index": 314,
"jawaban": "Floryn",
"soal": "https://cdn.filestackcontent.com/cT7NbtKLSauAbBQT7lJq"
},
{
"index": 315,
"jawaban": "Floryn",
"soal": "https://cdn.filestackcontent.com/2d9fXc91Rp2PDDAKsKY9"
},
{
"index": 316,
"jawaban": "Floryn",
"soal": "https://cdn.filestackcontent.com/dr6dH5I4TnyQsOQE0j56"
},
{
"index": 317,
"jawaban": "Gloo",
"soal": "https://cdn.filestackcontent.com/0cjHnXvFRECuKhkoDhG1"
},
{
"index": 318,
"jawaban": "Gloo",
"soal": "https://cdn.filestackcontent.com/Sv1Nyu3AQ0G4ihjF1kuN"
},
{
"index": 319,
"jawaban": "Gloo",
"soal": "https://cdn.filestackcontent.com/q3RmhganTgyExxp3Hbt1"
},
{
"index": 320,
"jawaban": "Leomord",
"soal": "https://cdn.filestackcontent.com/8Sb75l7ZTxifItXce50g"
},
{
"index": 321,
"jawaban": "Leomord",
"soal": "https://cdn.filestackcontent.com/KGQIAg4OTFWnSW7R9JSj"
},
{
"index": 322,
"jawaban": "Leomord",
"soal": "https://cdn.filestackcontent.com/NFEs3PqKSdBVyF0jUmKe"
},
{
"index": 323,
"jawaban": "Lancelot",
"soal": "https://cdn.filestackcontent.com/orzqu0aQ8OHrHUMD6WYZ"
},
{
"index": 324,
"jawaban": "Lancelot",
"soal": "https://cdn.filestackcontent.com/w1g6Oee7QGWkRnklpnyc"
},
{
"index": 325,
"jawaban": "Lancelot",
"soal": "https://cdn.filestackcontent.com/Lwa3OHTPCQlz4W4DBfBQ"
},
{
"index": 326,
"jawaban": "Johnson",
"soal": "https://cdn.filestackcontent.com/TvtJ1KxESDev8HmX18bG"
},
{
"index": 327,
"jawaban": "Johnson",
"soal": "https://cdn.filestackcontent.com/pfbuwjPGRzaVHPDXiy6L"
},
{
"index": 328,
"jawaban": "Johnson",
"soal": "https://cdn.filestackcontent.com/St6ELi66RXDliXacj9yS"
},
{
"index": 329,
"jawaban": "Clint",
"soal": "https://cdn.filestackcontent.com/cFouzlAFQSecFO4a4laI"
},
{
"index": 330,
"jawaban": "Clint",
"soal": "https://cdn.filestackcontent.com/saIuShpyTLWQTorwzTsa"
},
{
"index": 331,
"jawaban": "Clint",
"soal": "https://cdn.filestackcontent.com/yDcCT26Sce3EQvF02qvo"
},
{
"index": 332,
"jawaban": "Jawhead",
"soal": "https://cdn.filestackcontent.com/qR9pORGHQzqHRuPg1YhU"
},
{
"index": 333,
"jawaban": "Jawhead",
"soal": "https://cdn.filestackcontent.com/osLvoGqrQcyrT5DOHPh2"
},
{
"index": 334,
"jawaban": "Jawhead",
"soal": "https://cdn.filestackcontent.com/1yLCBsL6TCCYuv7XdQ89"
},
{
"index": 335,
"jawaban": "Phoveus",
"soal": "https://cdn.filestackcontent.com/LWHpV7iTgKZe0LPc2alP"
},
{
"index": 336,
"jawaban": "Phoveus",
"soal": "https://cdn.filestackcontent.com/m1ZniPoJQxeLYbRpcFXE"
},
{
"index": 337,
"jawaban": "Phoveus",
"soal": "https://cdn.filestackcontent.com/072AZJKnSMudzvM3LVrC"
},
{
"index": 338,
"jawaban": "Aulus",
"soal": "https://cdn.filestackcontent.com/2f29B6C1TxKyUvCjgU6Q"
},
{
"index": 339,
"jawaban": "Aulus",
"soal": "https://cdn.filestackcontent.com/6bjb056TpuVTuxf7fCSM"
},
{
"index": 340,
"jawaban": "Aulus",
"soal": "https://cdn.filestackcontent.com/ba5BFb8mSK7RHECQ3fyw"
},
{
"index": 341,
"jawaban": "Tigreal",
"soal": "https://cdn.filestackcontent.com/txmRD4UT6fkEfQADB1gf"
},
{
"index": 342,
"jawaban": "Tigreal",
"soal": "https://cdn.filestackcontent.com/KduhF2F7QQeKQ9mMbrbw"
},
{
"index": 343,
"jawaban": "Tigreal",
"soal": "https://cdn.filestackcontent.com/10SxOlGR3a07ZApPKQjQ"
},
{
"index": 344,
"jawaban": "Saber",
"soal": "https://cdn.filestackcontent.com/WBJQZJASLWg2kwvW0hVz"
},
{
"index": 345,
"jawaban": "Saber",
"soal": "https://cdn.filestackcontent.com/VnQY8OQ1QAyE70W1ZDfs"
},
{
"index": 346,
"jawaban": "Saber",
"soal": "https://cdn.filestackcontent.com/KLSpU89BRei5pwzrove6"
},
{
"index": 347,
"jawaban": "Angela",
"soal": "https://cdn.filestackcontent.com/ZgQSO4WScSbfx3bVVT1Q"
},
{
"index": 348,
"jawaban": "Angela",
"soal": "https://cdn.filestackcontent.com/XErGzKiTz6qFOHYsQwQA"
},
{
"index": 349,
"jawaban": "Angela",
"soal": "https://cdn.filestackcontent.com/CA06ej3GSguoco1B9lui"
},
{
"index": 350,
"jawaban": "Diggie",
"soal": "https://cdn.filestackcontent.com/GOddQOK9Sry7lSTwCbON"
},
{
"index": 351,
"jawaban": "Diggie",
"soal": "https://cdn.filestackcontent.com/ky65O8cIQeaiuPncYj11"
},
{
"index": 352,
"jawaban": "Diggie",
"soal": "https://cdn.filestackcontent.com/DdxiR0lXTRKH0Kdut7OQ"
},
{
"index": 353,
"jawaban": "Nana",
"soal": "https://cdn.filestackcontent.com/9uL6PIhYQzFjBELyoEq1"
},
{
"index": 354,
"jawaban": "Nana",
"soal": "https://cdn.filestackcontent.com/3Undf2XpSzyrkYk9PTN3"
},
{
"index": 355,
"jawaban": "Nana",
"soal": "https://cdn.filestackcontent.com/8s7kSedSH67eM3snRhoV"
},
{
"index": 356,
"jawaban": "Nana",
"soal": "https://cdn.filestackcontent.com/1MzDWHtGRrm2H0Iu6I1k"
},
{
"index": 357,
"jawaban": "Nana",
"soal": "https://cdn.filestackcontent.com/w5brfNQQjGiZVkf4338d"
},
{
"index": 358,
"jawaban": "Nana",
"soal": "https://cdn.filestackcontent.com/krtmARBRymlI3Gg2s2WW"
},
{
"index": 359,
"jawaban": "Nana",
"soal": "https://cdn.filestackcontent.com/d2aBe6qHR0mRVA2BjBU5"
},
{
"index": 360,
"jawaban": "Nana",
"soal": "https://cdn.filestackcontent.com/gGaZ95G3RmXGhcRX5kPl"
},
{
"index": 361,
"jawaban": "Nana",
"soal": "https://cdn.filestackcontent.com/WpiaPIQSPu1ScrIDt0Ax"
},
{
"index": 362,
"jawaban": "Nana",
"soal": "https://cdn.filestackcontent.com/DInoMw7XRYSfQvqCJK4n"
},
{
"index": 363,
"jawaban": "Nana",
"soal": "https://cdn.filestackcontent.com/4c9hamkBTjawklbwJyYw"
}
]

module.exports = Games