/*
⚊BUY SCRIPT?
⚊6285864647259 ( Ikyy )
         ⚊TQ TO⚊
Ikyy Not Developer ( Owner & Developer)
Skyzopedia ( Penyedia Base )
Cello Official ( My Support )
Zura Developer ( My Support )
Panzy Hosting ( My Support)
Dilz Hosting ( My Support )
Pino Developer ( My Support )
Pixel Hosting ( My Support )
## Di Larang Keras Hapus Creadit Hargai Developer Nya 🌟
*/
require("../system/data6.js")

process.on('uncaughtException', function (err) {
console.log('Caught exception: ', err)
})

module.exports = async (sock, m, chat, store) => {
try {
const isCmd = m.body ? m.body.startsWith(m.prefix) : false
const command = isCmd ? m.body.slice(m.prefix.length).trim().split(' ').shift().toLowerCase() : ''
const chats = chat
const cmd = m.prefix + command
const args = m.body.trim().split(/ +/).slice(1)
const crypto = require("crypto")
const makeid = crypto.randomBytes(3).toString('hex')
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const text = q = args.join(" ")
const botNumber = await sock.decodeJid(sock.user.id)
const isOwner = m.sender.split("@")[0] == global.owner ? true : m.fromMe ? true : ownplus.includes(m.sender)
const isGrupReseller = premium.includes(m.chat)
const pushname = m.pushName || `${m.sender.split("@")[0]}`
const isBot = botNumber.includes(m.sender)

// >~~~~~~~ Metadata Groups ~~~~~~~~< //

try {
m.isGroup = m.chat.endsWith("g.us");
m.metadata = m.isGroup ? await sock.groupMetadata(m.chat).catch(_ => {}) : {};
const participants = m.metadata?.participants || [];
m.isAdmin = Boolean(participants.find(e => e.admin !== null && e.id === m.sender));
m.isBotAdmin = Boolean(participants.find(e => e.admin !== null && e.id === botNumber));
} catch (error) {
m.metadata = {};
m.isAdmin = false;
m.isBotAdmin = false;
}

// >~~~~~~~~~ Database ~~~~~~~~~~~< //

if (!isCmd) {
let check = list.find(e => e.cmd == m.text.toLowerCase())
if (check) {
await m.reply(check.respon)
}}

// >~~~~~~~~ Fake Quoted ~~~~~~~~~~< //

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `Powered By ${namaowner}`}}}

const qjasajpm = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `Jasa Jpm By ${namaowner}`}}}

const qcmd = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${m.prefix+command}`}}}

// >~~~~~~~~~~ Function ~~~~~~~~~~~< //

const example = async (teks) => {
const commander = `\n*Contoh Command :*\n*${cmd}* ${teks}\n`
return sock.sendMessage(m.chat, {text: commander, contextInfo: {
}}, {quoted: m})
}

if (isCmd) {
console.log(chalk.white.bgBlue.bold("── Command Notification ──"), chalk.blue.bold(`\nSender : `), chalk.blue.bold(`${m.sender.split("@")[0]}`), chalk.blue.bold(`\nCommand :`), chalk.blue.bold(`${cmd}`), "\n")
}

if (isCmd && !isOwner && setbot.gconly && !m.isGroup) return m.reply(`\n*乂 Group Only Mode*

Maaf bot hanya dapat digunakan dalam grup, karna owner telah menyalakan *gconly*\n`)

if (isCmd && !isOwner && setbot.pconly && m.isGroup) return m.reply(`\n*乂 Private Only Mode*

Maaf bot hanya dapat digunakan dalam private chat, karna owner telah menyalakan *pconly*\n`)


if (!isCmd && sock[m.chat] && sock[m.chat].tebakboom && sock[m.chat].tebakboom.idGame) { 
const room = sock[m.chat].tebakboom; 
let num = Number(m.body) - 1;

let boom = sock[m.chat].tebakboom.gameQuestion.map((e, i) => i == num ? "💣" : e).map((e, i) => 
        i === 2 || i === 5 ? e + "\n" : e
    ).join("");
    
if (room.boomIndex === num) {
    let teks = `
*DUARRRRR 💣*

${boom}

@${m.sender.split("@")[0]} telah membuka kotak yang berisi boom! Game telah dihentikan. 
`; 
clearTimeout(room.gameTime); 
delete sock[m.chat].tebakboom;
 await sock.sendMessage(m.chat, { text: teks, mentions: [m.sender] }); 
 delete sock[m.chat]
 return 
 }

if (num >= 0 && num < sock[m.chat].tebakboom.gameQuestion.length) {
    if (sock[m.chat].tebakboom.gameQuestion[num] === "✅") return;
    
    sock[m.chat].tebakboom.gameQuestion[num] = "✅";

    let boom = sock[m.chat].tebakboom.gameQuestion.map((e, i) => 
        i === 2 || i === 5 ? e + "\n" : e
    ).join("");

    let teks = `
*🎮 Game Tebak Boom 🎮*

${boom}

* *Waktu Game (5 menit)*
`; await sock.sendMessage(m.chat, { text: teks, contextInfo: { isForwarded: true, forwardingScore: 9999 } }, { quoted: m }); }
 }


if (setbot.autojoinlinkgc == true) {
  const linkRegex = /https?:\/\/chat\.whatsapp\.com\/([0-9A-Za-z]+)/i;
  const match = m.text.match(linkRegex);
  
  if (match && match[1]) {
    const inviteCode = match[1];
    try {
      await sock.groupAcceptInvite(inviteCode);
    } catch (err) {
    }
  }
}

if (!isCmd && m.text.length > 1 && sock[m.chat] && sock[m.chat].kuis && sock[m.chat].kuis.idGame) {
const gameQuestions = require("../data/game/kuis.js")
const room = sock[m.chat].kuis
if (room.gameAnswer.trim().toLowerCase().includes(m.text.trim().toLowerCase())) {
const { question, answer } = gameQuestions[Math.floor(Math.random()*gameQuestions.length)]
let teks = `
@${m.sender.split("@")[0]} Jawaban Kamu Benar 🥳

*🎮 Next Pertanyaan Berikutnya 🎮*

* *Pertanyaan*
${question}
* *Waktu Game (3 menit)*
`
await sock.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
await clearTimeout(room.gameTime)
delete sock[m.chat].kuis
let msgg = await sock.sendMessage(m.chat, {text: teks, contextInfo: {mentionedJid: [m.sender], isForwarded: true, forwardingScore: 9999 }}, {quoted: m})
const idGame = func.getRandom("")
sock[m.chat] = {}
sock[m.chat].kuis = {
gameQuestion: question, 
gameAnswer: answer, 
gameRoom: m.chat, 
idGame: idGame, 
gameMessage: msgg, 
gameTime: setTimeout(() => {
if (sock[m.chat].kuis.idGame == idGame) {
sock.sendMessage(sock[m.chat].kuis.gameRoom, {text: `
*Waktu Game Telah Habis ❌*

*Jawabannya Adalah :*
* ${sock[m.chat].kuis.gameAnswer}
`}, {quoted: sock[m.chat].kuis.gameMessage})
delete sock[m.chat]
}
}, 180000)
}
await sock.sendMessage(global.owner+"@s.whatsapp.net", {text: `
*Jawaban Game Kuis*
* ${sock[m.chat].kuis.gameAnswer}
`}, {quoted: sock[m.chat].kuis.gameMessage})
} 
}

if (!isCmd && m.text.length > 1 && sock[m.chat] && sock[m.chat].siapakahaku && sock[m.chat].siapakahaku.idGame) {
const gameQuestions = require("../data/game/siapakahaku.js")
const room = sock[m.chat].siapakahaku
if (room.gameAnswer.trim().toLowerCase().includes(m.text.trim().toLowerCase())) {
const { question, answer } = gameQuestions[Math.floor(Math.random()*gameQuestions.length)]
let teks = `
@${m.sender.split("@")[0]} Jawaban Kamu Benar 🥳

*🎮 Next Pertanyaan Berikutnya 🎮*

* *Pertanyaan*
${question}
* *Waktu Game (3 menit)*
`
await sock.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
await clearTimeout(room.gameTime)
delete sock[m.chat].siapakahaku
let msgg = await sock.sendMessage(m.chat, {text: teks, contextInfo: {mentionedJid: [m.sender], isForwarded: true, forwardingScore: 9999 }}, {quoted: m})
const idGame = func.getRandom("")
sock[m.chat] = {}
sock[m.chat].siapakahaku = {
gameQuestion: question, 
gameAnswer: answer, 
gameRoom: m.chat, 
idGame: idGame, 
gameMessage: msgg, 
gameTime: setTimeout(() => {
if (sock[m.chat].siapakahaku.idGame == idGame) {
sock.sendMessage(sock[m.chat].siapakahaku.gameRoom, {text: `
*Waktu Game Telah Habis ❌*

*Jawabannya Adalah :*
* ${sock[m.chat].siapakahaku.gameAnswer}
`}, {quoted: sock[m.chat].siapakahaku.gameMessage})
delete sock[m.chat]
}
}, 180000)
}
await sock.sendMessage(global.owner+"@s.whatsapp.net", {text: `
*Jawaban Game Siapakah Aku*
* ${sock[m.chat].siapakahaku.gameAnswer}
`}, {quoted: sock[m.chat].siapakahaku.gameMessage})
} 
}


if (!isCmd && m.text.length > 1 && sock[m.chat] && sock[m.chat].tebakanime && sock[m.chat].tebakanime.idGame) {
const gameQuestions = require("../data/game/tebakanime.js")
const room = sock[m.chat].tebakanime
if (room.gameAnswer.toLowerCase().includes(m.text.trim().toLowerCase())) {
await sock.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
await clearTimeout(room.gameTime)
delete sock[m.chat]
const { image, answer } = gameQuestions[Math.floor(Math.random()*gameQuestions.length)]
let teks = `
@${m.sender.split("@")[0]} Jawaban Kamu Benar 🥳

*🎮 Next Anime Berikutnya 🎮*

* *Waktu Game (3 menit)*
`
let msgg = await sock.sendMessage(m.chat, {image: {url: image}, caption: teks, contextInfo: { mentionedJid: [m.sender], isForwarded: true, forwardingScore: 9999 }}, {quoted: m})
const idGame = func.getRandom("")
sock[m.chat] = {}
sock[m.chat].tebakanime = {
gameQuestion: image, 
gameAnswer: answer, 
gameRoom: m.chat, 
idGame: idGame, 
gameMessage: msgg, 
gameTime: setTimeout(() => {
if (sock[m.chat].tebakanime.idGame == idGame) {
sock.sendMessage(sock[m.chat].tebakanime.gameRoom, {text: `
*Waktu Game Telah Habis ❌*

*Jawabannya Adalah :*
* ${sock[m.chat].tebakanime.gameAnswer}
`}, {quoted: sock[m.chat].tebakanime.gameMessage})
delete sock[m.chat]
}
}, 180000)
}
await sock.sendMessage(global.owner+"@s.whatsapp.net", {text: `
*Jawaban Game Tebak Anime*
* ${sock[m.chat].tebakanime.gameAnswer}
`}, {quoted: sock[m.chat].tebakanime.gameMessage})
} 
}

if (!isCmd && m.text.length > 1 && sock[m.chat] && sock[m.chat].tebakheroml && sock[m.chat].tebakheroml.idGame) {
const gameQuestions = require("../data/game/tebakheroml.js")
const room = sock[m.chat].tebakheroml
if (room.gameAnswer.includes(m.text.trim().toLowerCase())) {
await sock.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
await clearTimeout(room.gameTime)
delete sock[m.chat]
const { soal, jawaban } = gameQuestions[Math.floor(Math.random()*gameQuestions.length)]
let teks = `
@${m.sender.split("@")[0]} Jawaban Kamu Benar 🥳

*🎮 Next Hero Berikutnya 🎮*
`
await sock.sendMessage(m.chat, {text: teks, contextInfo: { mentionedJid: [m.sender], isForwarded: true, forwardingScore: 9999 }}, {quoted: m})
let msgg = await sock.sendMessage(m.chat, {audio: {url: soal}, mimetype: "audio/mpeg", ptt: true, contextInfo: { mentionedJid: [m.sender], isForwarded: true, forwardingScore: 9999, 
externalAdReply: {
title: "🎮 Tebak Hero ML 🎮", 
body: "Waktu Game 3 Menit", 
thumbnailUrl: global.image, 
previewType: "PHOTO"
}
}}, {quoted: m})
const idGame = func.getRandom("")
sock[m.chat] = {}
sock[m.chat].tebakheroml = {
gameQuestion: soal, 
gameAnswer: jawaban.toLowerCase(), 
gameRoom: m.chat, 
idGame: idGame, 
gameMessage: msgg, 
gameTime: setTimeout(() => {
if (sock[m.chat].tebakheroml.idGame == idGame) {
sock.sendMessage(sock[m.chat].tebakheroml.gameRoom, {text: `
*Waktu Game Telah Habis ❌*

*Jawabannya Adalah :*
* ${sock[m.chat].tebakheroml.gameAnswer}
`}, {quoted: sock[m.chat].tebakheroml.gameMessage})
delete sock[m.chat]
}
}, 180000)
}
await sock.sendMessage(global.owner+"@s.whatsapp.net", {text: `
*Jawaban Game Tebak Heroml*
* ${sock[m.chat].tebakheroml.gameAnswer}
`}, {quoted: sock[m.chat].tebakheroml.gameMessage})
} 
}


if (!isCmd && m.text.length > 1 && sock[m.chat] && sock[m.chat].tebakgambar && sock[m.chat].tebakgambar.idGame) {
const gameQuestions = require("../data/game/tebakgambar.js")
const room = sock[m.chat].tebakgambar
if (room.gameAnswer.includes(m.text.trim().toLowerCase())) {
await sock.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
await clearTimeout(room.gameTime)
delete sock[m.chat]
const { img, jawaban, deskripsi } = gameQuestions[Math.floor(Math.random()*gameQuestions.length)]
let teks = `
@${m.sender.split("@")[0]} Jawaban Kamu Benar 🥳

*🎮 Next Soal Berikutnya 🎮*

* *Deskripsi*
${deskripsi}
* *Waktu Game (3 menit)*
`
let msgg = await sock.sendMessage(m.chat, {image: {url: img}, caption: teks, contextInfo: { mentionedJid: [m.sender], isForwarded: true, forwardingScore: 9999 }}, {quoted: m})
const idGame = func.getRandom("")
sock[m.chat] = {}
sock[m.chat].tebakgambar = {
gameQuestion: deskripsi, 
gameAnswer: jawaban, 
gameRoom: m.chat, 
idGame: idGame, 
gameMessage: msgg, 
gameTime: setTimeout(() => {
if (sock[m.chat].tebakgambar.idGame == idGame) {
sock.sendMessage(sock[m.chat].tebakgambar.gameRoom, {text: `
*Waktu Game Telah Habis ❌*

*Jawabannya Adalah :*
* ${sock[m.chat].tebakgambar.gameAnswer}
`}, {quoted: sock[m.chat].tebakgambar.gameMessage})
delete sock[m.chat]
}
}, 180000)
}
await sock.sendMessage(global.owner+"@s.whatsapp.net", {text: `
*Jawaban Game Tebak Gambar*
* ${sock[m.chat].tebakgambar.gameAnswer}
`}, {quoted: sock[m.chat].tebakgambar.gameMessage})
} 
}


if (!isCmd && m.text.length > 1 && sock[m.chat] && sock[m.chat].family100 && sock[m.chat].family100.idGame) {
const room = sock[m.chat].family100
if (room.gameAnswer.includes(m.text.trim().toLowerCase())) {
const question = room.gameQuestion
const answer = room.gameAnswer
sock[m.chat].family100.gameAnswer = sock[m.chat].family100.gameAnswer.filter(ii => !ii.includes(m.text.trim().toLowerCase()))
sock[m.chat].family100.users.push({ user: m.sender, jawaban: m.text.trim() })
if (sock[m.chat].family100.gameAnswer.length == 0) {
let users = ""
for (let i of sock[m.chat].family100.users) {
users += `@${i.user.split("@")[0]} => ${i.jawaban}\n`
}
let teks = `
*Game Family100 Telah Terselaikan 🥳*

* *Pertanyaan*
${room.gameQuestion}

*Daftar User Berhasil Menjawab :*
${users}
`
await sock.sendMessage(m.chat, {text: teks, contextInfo: {mentionedJid: sock[m.chat].family100.users.map(e => e.user), isForwarded: true, forwardingScore: 9999 }}, {quoted: m})
await clearTimeout(sock[m.chat].family100.gameTime)
delete sock[m.chat]
return 
}
let teks = `
*🎮 Game Family100 🎮*

* *Pertanyaan*
${question}

*Jawaban Terjawab :*
`
for (let i of sock[m.chat].family100.users) {
teks += `@${i.user.split("@")[0]} => ${i.jawaban}\n`
}
await sock.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
sock[m.chat].family100.gameMessage = await sock.sendMessage(m.chat, {text: teks, contextInfo: {mentionedJid: sock[m.chat].family100.users.map(e => e.user), isForwarded: true, forwardingScore: 9999 }}, {quoted: m})
} 
}


if (m.isGroup && antilink.some(i => i.id === m.chat)) {
    const linkRegex = /chat\.whatsapp\.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi;

    if (linkRegex.test(chats) && !isOwner && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
        try {
            const gclink = `https://chat.whatsapp.com/${await sock.groupInviteCode(m.chat)}`;
            const isLinkThisGc = new RegExp(gclink, 'i');

            if (isLinkThisGc.test(m.text)) return;

            const room = antilink.find(i => i.id === m.chat);
            const { participant, id } = m.key;

            await sock.sendMessage(m.chat, {
                text: `\n*乂 Link Grup Terdeteksi*\n\nMaaf, ${room.kick ? "Kamu akan saya kick" : "pesan kamu saya hapus"}, karena admin/owner bot telah mengaktifkan fitur *Antilink Grup*\n`,
                mentions: [m.sender]
            }, { quoted: m });

            await sock.sendMessage(m.chat, {
                delete: { remoteJid: m.chat, fromMe: false, id, participant }
            });

            if (room.kick) {
                await func.sleep(1000);
                await sock.groupParticipantsUpdate(m.chat, [m.sender], "remove");
            }
        } catch (error) {
            console.error("Error saat memproses antilink:", error);
        }
    }
}

if (m.isGroup && antilinkch.some(i => i.id === m.chat)) {
    const linkRegex = /https?:\/\/whatsapp\.com\/channel\/[a-zA-Z0-9]+/gi;
    if (linkRegex.test(chats) && !isOwner && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
        try {
            const room = antilinkch.find(i => i.id === m.chat);
            const { participant, id } = m.key;

            await sock.sendMessage(m.chat, {
                text: `\n*乂 Link Channel Terdeteksi*\n\nMaaf, ${room.kick ? "Kamu akan saya kick" : "pesan kamu saya hapus"}, karena admin/owner bot telah mengaktifkan fitur *Antilink Channel*\n`,
                mentions: [m.sender]
            }, { quoted: m });

            await sock.sendMessage(m.chat, {
                delete: { remoteJid: m.chat, fromMe: false, id, participant }
            });

            if (room.kick) {
                await func.sleep(1000);
                await sock.groupParticipantsUpdate(m.chat, [m.sender], "remove");
            }
        } catch (error) {
            console.error("Error saat memproses antilink:", error);
        }
    }
}

// >~~~~~~~~~ Command ~~~~~~~~~~< //

switch (command) {
case "menu": case "kyy": case "allmenu": {
const textnya = `  
 ╭─❑ *⚊ INFORMATION BOT*
 │ ▢ ☓ʙᴏᴛɴᴀᴍᴇ : *${namabot}*
 │ ▢ ☓ᴍᴏᴅᴇ : *${sock.public ? "Public" : "Self"}*
 │ ▢ ☓ᴠᴇʀsɪᴏɴ : *v1.0.0*
 │ ▢ ☓ᴅᴇᴠᴇʟᴏᴘᴇʀ : *IkyyNotDeveloper*
 ╰─────────────────────❒
 ╭─❑ *⚊☓ MAIN MENU* 🎯
 │  空 .qc
 │  空 .ai
 │  空 .gpt
 │  空 .brat
 │  空 .bratvid
 │  空 .sticker
 │  空 .swm
 │  空 .ssweb
 │  空 .readqr
 │  空 .rvo
 │  空 .tourl
 │  空 .ttstalk
 │  空 .ffstalk
 │  空 .igstalk
 │  空 .wastalk
 │  空 .removebg
 │  空 .remini
 │  空 .tohd
 │  空 .infocrypto
 ╰─❒
 
 ╭─❑ *⚊☓ SHOOP MENU* 🛍
 │  空 .buypanel
 │  空 .buyadp
 │  空 .buyreseller
 │  空 .buyjasajpm
 │  空 .buyscript
 │  空 .buydigitalocean
 │  空 .buyvps
 │  空 .buypulsa
 │  空 .buykuota
 │  空 .buysaldo
 │  空 .topupml
 │  空 .topupff
 │  空 .topuppubg
 ╰─❒
 
 ╭─❑ *⚊☓ DOWNLOAD MENU* 🔄
 │  空 .tiktok
 │  空 .ytplay
 │  空 .ytmp3
 │  空 .ytmp4
 │  空 .gitclone
 │  空 .instagram
 │  空 .xnxx
 │  空 .videy
 │  空 .facebook
 ╰─❒
 
 ╭─❑ *⚊☓ SEARCH MENU* 🔍
 │  空 .pinterest
 │  空 .yts
 │  空 .gimage
 │  空 .xnxxs
 │  空 .tiktoks
 │  空 .npm
 ╰─❒
   
 ╭─❑ *⚊☓ GAME MENU* 🎮
 │  空 .kuis
 │  空 .family100
 │  空 .siapakahaku
 │  空 .tebakanime
 │  空 .tebakgambar
 │  空 .tebakheroml
 │  空 .tebakbom
 ╰─❒
  
 ╭─❑ *⚊☓ GROUP MENU* 👥
 │  空 .antilink
 │  空 .antilinkch
 │  空 .bljpm
 │  空 .welcome
 │  空 .buatgc
 │  空 .kick
 │  空 .promote
 │  空 .demote
 │  空 .hidetag
 │  空 .close/open
 │  空 .resetlink
 │  空 .joingc
 │  空 .leave
 │  空 .tagall
 ╰─❒
 
 ╭─❑ *⚊☓ CHANNEL MENU* 🗣️
 │  空 .cekidch
 │  空 .reactch
 │  空 .addidch
 │  空 .listidch
 │  空 .delidch
 │  空 .jpmch
 │  空 .joinch
 ╰─❒
 
 ╭─❑ *⚊☓ STORE MENU* 🛒
 │  空 .tfdana
 │  空 .pushkontak
 │  空 .pushkontak2
 │  空 .savekontak
 │  空 .savekontak2  
 │  空 .listgc
 │  空 .addrespon
 │  空 .delrespon
 │  空 .listrespon
 │  空 .done
 │  空 .proses
 │  空 .jpmtesti
 │  空 .jpm
 │  空 .jpmht
 │  空 .createvps
 │  空 .gantipwvps
 │  空 .installpanel
 │  空 .startwings
 │  空 .subdomain
 ╰─❒
 
 ╭─❑ *⚊☓ PANEL MENU* 📦
 │  空 .addakses
 │  空 .delakses
 │  空 .listakses
 │  空 .1gb - unlimited
 │  空 .cadmin
 │  空 .listpanel
 │  空 .listadmin
 │  空 .delpanel
 │  空 .deladmin
 │  空 .clearserver
 ╰─❒
  
 ╭─❑ *⚊☓ CLOUDFLARE MENU* 🌐
 │  空 .adddomaincf
 │  空 .listdomaincf
 │  空 .deldomaincf
 │  空 .clearallsubdo
 ╰─❒
 
 ╭─❐ *⚊☓ OWNER MENU* 👤
 │  空 .addpendapatan
 │  空 .rekappendapatan
 │  空 .resetpendapatan
 │  空 .addstokdo
 │  空 .delstokdo
 │  空 .liststokdo
 │  空 .addscript
 │  空 .delscript
 │  空 .getscript
 │  空 .listscript
 │  空 .adddomain
 │  空 .deldomain
 │  空 .listdomain
 │  空 .addowner
 │  空 .delowner
 │  空 .listowner
 │  空 .setppbot
 │  空 .delppbot
 │  空 .restart
 │  空 .delsampah
 │  空 .clearsession
 │  空 .addcase
 │  空 .delcase
 │  空 .getcase
 │  空 .getip
 │  空 .upswtag  
 │  空 .backupsc
 ╰─❒
  
 ╭─❑ *⚊☓ SETBOT MENU* 🤖
 │  空 .autoread
 │  空 .autoreadsw
 │  空 .autotyping
 │  空 .autorecording
 │  空 .anticall
 │  空 .pconly
 │  空 .ɢᴄᴏɴʟʏ
 ╰─❒
> ☓ɪᴋʏʏɴᴏᴛᴅᴇᴠᴇʟᴏᴘᴇʀ
`
await sock.sendMessage(m.chat, {
text: textnya,
contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idsaluran,
   newsletterName: global.namasaluran, 
   serverId: 200
   }
}}, {quoted: qtext})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "buatgc": {
if (!isOwner) return m.reply(msg.owner)
if (!q) return m.reply(`
Masukan nama grupnya!\nContoh *.buatgc* marketplace
`)
let res = await sock.groupCreate(q, [])
const urlGrup = "https://chat.whatsapp.com/" + await sock.groupInviteCode(res.id)
let teks = `
*Grup Berhasil Dibuat ✅*

* ${text}
* ${urlGrup}
`
return m.reply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addpendapatan": {
  if (!isOwner) return m.reply(msg.owner)

  if (!text || !text.includes("|")) {
    return m.reply(`
*Format Salah!*

Contoh :
*.addpendapatan* nama produk|harga
`)
  }

  const [produk, harga] = text.split("|").map(v => v.trim())

  if (!produk || !harga || isNaN(harga)) {
    return m.reply(`
*Format Salah!*

Pastikan format seperti ini:
.addpendapatan nama produk|harga

Contoh :
*.addpendapatan* Kopi Hitam|10000
`)
  }

  const obj = {
    produk,
    harga,
    tanggal: func.tanggal(Date.now())
  }

  pendapatan.push(obj)
  fs.writeFileSync("./data/pendapatan.json", JSON.stringify(pendapatan, null, 2))

  const teks = `
*Berhasil menambah pendapatan ✅*

📅 *Tanggal:* ${obj.tanggal}
📦 *Produk:* ${produk}
💰 *Harga:* Rp${func.toRupiah(harga)}
  `.trim()

  m.reply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "rekappendapatan": case "rekapendapatan": case "pendapatan": {
if (!isOwner) return m.reply(msg.owner)
if (pendapatan.length < 1) return m.reply("Tidak ada pendapatan")
let teks = `\n*📊 Rekap Pendapatan :*\n`
let total = 0
for (let i of pendapatan) {
total += Number(i.harga)
teks += `\n*📅 Tanggal :* ${i.tanggal}
*📦 Produk :* ${i.produk}
*💰 Harga :* Rp${func.toRupiah(i.harga)}\n`
}
teks += `\n*Total Pendapatan :* Rp${func.toRupiah(total)}\n`
return m.reply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addakses": case "addaksesgc": {
if (!isOwner) return m.reply(msg.owner)
if (!m.isGroup) return m.reply(msg.group)
const input = m.chat
if (premium.includes(input)) return m.reply(`Grup ini sudah di beri akses reseller panel!`)
premium.push(input)
await fs.writeFileSync("./data/premium.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menambah grup reseller panel ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "resetpendapatan": case "rstpendapatan": {
if (!isOwner) return m.reply(msg.owner)
if (pendapatan.length < 1) return m.reply("Tidak ada pendapatan.")
pendapatan.length = 0
await fs.writeFileSync("./data/pendapatan.json", JSON.stringify(pendapatan, null, 2))
m.reply(`Berhasil menghapus semua data rekap pendapatan ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delakses":
case "delaksesgc": {
  if (!isOwner) return m.reply(msg.owner)
  if (!m.isGroup) return m.reply(msg.group)
  if (premium.length === 0) return m.reply("Tidak ada grup reseller panel.")

  const input = text ? text.trim() : m.chat

  if (input.toLowerCase() === "all") {
    premium.length = 0
    fs.writeFileSync("./data/premium.json", JSON.stringify(premium, null, 2))
    return m.reply("Berhasil menghapus *semua grup reseller panel ✅")
  }

  if (!premium.includes(input)) {
    return m.reply("Grup ini bukan grup reseller panel")
  }

  // Hapus grup dari list
  const index = premium.indexOf(input)
  premium.splice(index, 1)
  fs.writeFileSync("./data/premium.json", JSON.stringify(premium, null, 2))

  return m.reply("Berhasil menghapus grup reseller panel ✅")
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listakses": {
if (!isOwner) return m.reply(msg.owner)
if (premium.length < 1) return m.reply("Tidak ada grup reseller panel")
const datagc = await sock.groupFetchAllParticipating()
let teks = ""
for (let i of premium) {
let nama = datagc[i].subject || "Grup tidak ditemukan"
teks += `\n* ${i}
* ${nama}\n`
}
return m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "welcome":
case "welcom": {
  if (!isOwner) return m.reply(msg.owner)
  if (!m.isGroup) return m.reply(msg.group)

  if (!text || !/^(on|off)$/i.test(text.trim())) {
    const status = welcome.includes(m.chat) ? "Aktif ✅" : "Tidak Aktif ❌"
    return m.reply(`
Contoh penggunaan : 
ketik *.${command}* on/off

Status welcome di grup ini :
* *${status}*
`)
  }

  const input = text.toLowerCase().trim()

  if (input === "on") {
    if (welcome.includes(m.chat)) {
      return m.reply("Welcome di grup ini sudah aktif sebelumnya.")
    }
    welcome.push(m.chat)
    fs.writeFileSync("./data/welcome.json", JSON.stringify(welcome, null, 2))
    return m.reply("Welcome berhasil diaktifkan untuk grup ini ✅")
  }

  if (input === "off") {
    if (!welcome.includes(m.chat)) {
      return m.reply("Welcome di grup ini sudah nonaktif sebelumnya.")
    }
    const index = welcome.indexOf(m.chat)
    welcome.splice(index, 1)
    fs.writeFileSync("./data/welcome.json", JSON.stringify(welcome, null, 2))
    return m.reply("Welcome berhasil dimatikan untuk grup ini ✅")
  }
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "antilinkch": case "antich": {
  if (!isOwner) return m.reply(msg.owner);
  if (!m.isGroup) return m.reply(msg.group);

  let room = antilinkch.find((i) => i.id == m.chat);

  if (!args[0] || !args[1]) return m.reply(`
Contoh penggunaan : 
ketik *.${command}* kik/nokik on/off

Status antilinkch di grup ini :
* *${room ? `Aktif ✅ (${room.kick ? "kick" : "nokik"})` : "Tidak Aktif ❌"}*
`)

  let mode = args[0].toLowerCase();
  let state = args[1].toLowerCase();
  let isOn = /on/g.test(state);
  let isOff = /off/g.test(state);

  if (!["kick", "nokick", "kik", "nokik"].includes(mode))
    return m.reply(`
Contoh penggunaan : 
ketik *.${command}* kik/nokik on/off

Status antilinkch di grup ini :
* *${room ? `Aktif ✅ (${room.kick ? "kick" : "nokik"})` : "Tidak Aktif ❌"}*
`)

  if (!isOn && !isOff) return m.reply(`
Contoh penggunaan : 
ketik *.${command}* kik/nokik on/off

Status antilinkch di grup ini :
* *${room ? `Aktif ✅ (${room.kick ? "kick" : "nokik"})` : "Tidak Aktif ❌"}*
`)

  let shouldKick = mode === "kick" || mode === "kik";

  if (isOn) {
    if (room && room.kick === shouldKick)
      return m.reply(
        `*Antilink channel ${shouldKick ? "kick" : "no kick"}* di grup ini sudah aktif!`
      );

    if (room) {
      let ind = antilinkch.indexOf(room);
      antilinkch.splice(ind, 1);
    }

    antilinkch.push({ id: m.chat, kick: shouldKick });
    fs.writeFileSync("./data/antilinkch.json", JSON.stringify(antilinkch, null, 2));
    return m.reply(
      `*Antilink channel ${shouldKick ? "kick" : "no kick"}* berhasil diaktifkan ✅`
    );
  } else if (isOff) {
    if (!room || room.kick !== shouldKick)
      return m.reply(
        `*Antilink channel ${shouldKick ? "kick" : "no kick"}* di grup ini sudah tidak aktif!`
      );

    let ind = antilinkch.indexOf(room);
    antilinkch.splice(ind, 1);
    fs.writeFileSync("./data/antilinkch.json", JSON.stringify(antilinkch, null, 2));
    return m.reply(
      `*Antilink channel ${shouldKick ? "kick" : "no kick"}* berhasil dimatikan ✅`
    );
  }
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "autoread": case "autoreadsw": case "anticall": case "autotyping": case "autorecording": case "pconly": case "gconly": case "autojoinlinkgc": {
if (!isOwner) return m.reply(msg.owner)
const getStatus = () => {
let teks = ""
for (let i of Object.keys(setbot)) {
teks += `* *${func.capital(i)} :* ${setbot[i] ? "aktif ✅" : "tidak aktif ❌"}
`
}
return teks
}
if (!text || !/on|off/.test(text)) return m.reply(`\nContoh : *${cmd}* on/off\n\n${getStatus()}`)
const input = text.toLowerCase()
if (/on/.test(input)) {
if (setbot[command.toLowerCase()] == true) return m.reply(`*${func.capital(command)}* sudah aktif!`)
if (command == "autotyping" && setbot.autorecording == true) setbot.autorecording = false
if (command == "autorecording" && setbot.autotyping == true) setbot.autotyping = false
setbot[command.toLowerCase()] = true
await fs.writeFileSync("./data/bot.json", JSON.stringify(setbot, null, 2))
return m.reply(`
Berhasil menyalakan *${func.capital(command)}* ✅

${getStatus()}`)
} 
if (/off/.test(input)) {
if (setbot[command.toLowerCase()] == false) return m.reply(`${func.capital(command)} sudah tidak aktif!`)
setbot[command.toLowerCase()] = false
await fs.writeFileSync("./data/bot.json", JSON.stringify(setbot, null, 2))
return m.reply(`
Berhasil mematikan *${func.capital(command)}* ✅

${getStatus()}`)
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "bljpm": case "blgcjpm": {
if (!isOwner) return m.reply(msg.owner)
if (!m.isGroup) return m.reply(msg.group)
if (!text || !/on|off/.test(text)) return example(`on/off\n\n*Status Bljpm :* ${bljpm.includes(m.chat) ? "Aktif ✅" : "Tidak Aktif ❌"}`)
const input = text.toLowerCase()
if (/on/.test(input)) {
if (bljpm.includes(m.chat)) return m.reply(`Blacklist jpm di grup ini sudah aktif!`)
bljpm.push(m.chat)
await fs.writeFileSync("./data/bljpm.json", JSON.stringify(bljpm, null, 2))
return m.reply(`Berhasil menghidupkan blacklist jpm di grup ini ✅`)
} 
if (/off/.test(input)) {
if (!bljpm.includes(m.chat)) return m.reply(`Blacklist jpm di grup ini sudah tidak aktif!`)
let posi = bljpm.indexOf(m.chat)
await bljpm.splice(posi, 1)
await fs.writeFileSync("./data/bljpm.json", JSON.stringify(bljpm, null, 2))
return m.reply(`Berhasil mematikan blacklist jpm di grup ini ✅`)
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "idgc": {
if (!m.isGroup) return m.reply(msg.group)
return m.reply(m.chat)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "leave": {
if (!isOwner) return m.reply(msg.owner)
if (!m.isGroup) return m.reply(msg.group)
await func.sleep(4000)
await sock.groupLeave(m.chat)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "resetlinkgc": case "resetlink": {
if (!isOwner) return m.reply(msg.owner)
if (!m.isGroup) return m.reply(msg.group)
if (!m.isBotAdmin) return m.reply(msg.botadmin)
await sock.groupRevokeInvite(m.chat)
m.reply("Sukses mereset ling grup ini ✅")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "readqr": {
if (!/image/.test(mime)) return example("dengan reply qris")
const Jimp = require("jimp");
const QrCode = require("qrcode-reader");
async function readQRISFromBuffer(buffer) {
    return new Promise(async (resolve, reject) => {
        try {
            const image = await Jimp.read(buffer);
            const qr = new QrCode();
            qr.callback = (err, value) => {
                if (err) return reject(err);
                resolve(value ? value.result : null);
            };
            qr.decode(image.bitmap);
        } catch (error) {
            return m.reply("error : " + error)
        }
    });
}

let aa = m.quoted ? await m.quoted.download() : await m.download()
let dd = await readQRISFromBuffer(aa)
await sock.sendMessage(m.chat, {text: `${dd}`}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "enchard": case "encrypthard": {
if (!/javascript/g.test(mime)) return example("dengan kirim file .js")
let media = m.quoted ? await m.quoted.download() : await m.download()
let filename = m.quoted ? m.quoted.fakeObj.message.documentMessage.fileName : m.fakeObj.message.documentMessage.fileName
await m.reply("Memproses encrypt hard code . . .")
await JsConfuser.obfuscate(media.toString(), {
  target: "node",
    preset: "high",
    compact: true,
    minify: true,
    flatten: true,

    identifierGenerator: function() {
        const originalString = `素晴座素晴ikyystore`

        function hapusKarakterTidakDiinginkan(input) {
            return input.replace(
                /[^a-zA-Z/*ᨒZenn/*^/*($break)*/]/g, ''
            );
        }

        function stringAcak(panjang) {
            let hasil = '';
            const karakter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            const panjangKarakter = karakter.length;

            for (let i = 0; i < panjang; i++) {
                hasil += karakter.charAt(
                    Math.floor(Math.random() * panjangKarakter)
                );
            }
            return hasil;
        }

        return hapusKarakterTidakDiinginkan(originalString) + stringAcak(2);
    },

    renameVariables: true,
    renameGlobals: true,

    // Kurangi encoding dan pemisahan string untuk mengoptimalkan ukuran
    stringEncoding: 0.01, 
    stringSplitting: 0.1, 
    stringConcealing: true,
    stringCompression: true,
    duplicateLiteralsRemoval: true,

    shuffle: {
        hash: false,
        true: false
    },
    controlFlowFlattening: false, 
    opaquePredicates: false, 
    deadCode: false, 
    dispatcher: false,
    rgf: false,
    calculator: false,
    hexadecimalNumbers: false,
    movedDeclarations: true,
    objectExtraction: true,
    globalConcealing: true
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@hardenc${filename}`, obfuscated.code)
  await sock.sendMessage(m.chat, {document: await fs.readFileSync(`./@hardenc${filename}`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File JS Sukses! Type:\nString"}, {quoted: m})
}).catch(e => m.reply("Error :" + e))
await fs.unlinkSync(`./@hardenc${filename}`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "getcase": {
if (!isOwner) return
if (!text) return example("menu")
const getcase = (cases) => {
return "case "+`\"${cases}\"`+fs.readFileSync('./commands/case.js').toString().split('case \"'+cases+'\"')[1].split("break")[0]+"break"
}
try {
m.reply(`${getcase(q)}`)
} catch (e) {
return m.reply(`Case *${text}* tidak ditemukan`)
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delcase": {
    if (!isOwner) return;
    if (!text) return example("menu");

    const getcase = async (cases) => {
        try {
            const script = await fs.readFileSync('./commands/case.js', 'utf8');
            const match = script.match(new RegExp(`case "${cases}".*?break`, "s"));
            return match ? match[0] : null;
        } catch (err) {
            return null;
        }
    };

    try {
        let dell = await getcase(text);
        if (!dell) return m.reply(`Case *${text}* tidak ditemukan`);

        const konn = await fs.readFileSync("./commands/case.js", "utf8");
        const databaru = konn.replace(dell, '').trim();

        await fs.writeFileSync("./commands/case.js", databaru, "utf8");
        return m.reply(`Berhasil menghapus case *${text}*`);
    } catch (e) {
        return m.reply(`Terjadi kesalahan: ${e.message}`);
    }
}
break;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addcase": {
    if (!isOwner) return m.reply(msg.owner);
    if (!text) return m.reply(`
*Contoh penggunaan:*
Ketik:
\`\`\`
.addcase 
case "menu": {
    m.reply("Hello")
}
break
\`\`\`
`);

    // Pastikan format case yang diberikan benar
    if (!/^case\s+\".*\"\s*{[\s\S]*}[\s]*break$/i.test(text.trim())) {
        return m.reply("Format case tidak valid!");
    }

    try {
        const filePath = "./commands/case.js";
        const fill = await fs.readFileSync(filePath, "utf8");

        if (!fill.includes("default:")) return m.reply("Error: Tidak ditemukan `default:` di dalam file!");

        // Sisipkan case baru sebelum `default:`
        const newcase = fill.replace(/default:/, `\n${text.trim()}\n\ndefault:`);

        await fs.writeFileSync(filePath, newcase, "utf8");
        return m.reply("Berhasil menambahkan case ✅");
    } catch (e) {
        return m.reply(`Terjadi kesalahan: ${e.message}`);
    }
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "pushkontak": case "puskontak": {
if (!isOwner) return m.reply(msg.owner)
if (!m.isGroup) return m.reply(msg.group)
if (!text) return example("pesannya")
const teks = text
const jidawal = m.chat
const data = await sock.groupMetadata(m.chat)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await m.reply(`Memproses pushkontak ke *${halls.length}* member grup`)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
await sock.sendMessage(mem, {text: teks}, {quoted: qtext})
await func.sleep(4000)
}}

await sock.sendMessage(jidawal, {text: `*Pushkontak Berhasil ✅*\nTotal member : ${halls.length}`}, {quoted: m})
}
break


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "upswtag": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("text & bisa dengan kirim foto")
if (/image/.test(mime)) global.imgsw = qmsg
const meta = await sock.groupFetchAllParticipating()
let dom = await Object.keys(meta)
global.textupsw = text
let list = []
for (let i of dom) {
await list.push({
title: meta[i].subject, 
id: `.create-storywa ${i}|${meta[i].subject}`, 
description: `${meta[i].participants.length} Member`
})
}
return sock.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: 'List Grup Chat',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Target Grup Tag\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: null}) 
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "create-storywa": {
    if (!isOwner) return m.reply(msg.owner);
    if (!global.textupsw) return m.reply("Tidak ada teks yang tersedia untuk status.");

    async function mentionStatus(jids, content) {
        try {
            let colors = ['#7ACAA7', '#6E257E', '#5796FF', '#7E90A4', '#736769', '#57C9FF', '#25C3DC', '#FF7B6C', '#55C265', '#FF898B', '#8C6991', '#C69FCC', '#B8B226', '#EFB32F', '#AD8774', '#792139', '#C1A03F', '#8FA842', '#A52C71', '#8394CA', '#243640'];
            let fonts = [0];
            let user = await sock.groupMetadata(jids);
            let users = user.participants.map(v => v.id);

            let message = await sock.sendMessage("status@broadcast", content, {
                backgroundColor: colors[Math.floor(Math.random() * colors.length)],
                font: fonts[Math.floor(Math.random() * fonts.length)],
                statusJidList: users,
                additionalNodes: [{
                    tag: "meta",
                    attrs: {},
                    content: [{
                        tag: "mentioned_users",
                        attrs: {},
                        content: [{
                            tag: "to",
                            attrs: { jid: jids },
                            content: undefined,
                        }]
                    }],
                }],
            });

            await sock.relayMessage(jids, {
                groupStatusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: message.key,
                            type: 25,
                        },
                    },
                },
            }, {
                userJid: sock.user.jid,
                additionalNodes: [{
                    tag: "meta",
                    attrs: { is_status_mention: "true" },
                    content: undefined,
                }],
            });
        } catch (error) {
            console.error("Error creating status mention:", error);
        }
    }

    let [jid, nama] = text.split("|");
    const teks = global.textupsw;

    if (global.imgsw) {
        try {
            let media = await sock.downloadAndSaveMediaMessage(global.imgsw);
            await mentionStatus(jid, {
                image: { url: media },
                caption: teks
            });
            await fs.promises.unlink(media); // Menghapus file secara asinkron
        } catch (error) {
            console.error("Error processing media:", error);
        }
    } else {
        await mentionStatus(jid, { text: teks });
    }

    return m.reply(`Berhasil membuat status tag grup ${nama}`);
}
break;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "savekontak2": {
if (!isOwner) return m.reply(msg.owner)
const meta = await sock.groupFetchAllParticipating()
global.statussv = true
let dom = await Object.keys(meta)
let list = []
for (let i of dom) {
await list.push({
title: meta[i].subject, 
id: `.ressavekontak ${i}`, 
description: `${meta[i].participants.length} Member`
})
}
return sock.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Target Grup Savekontak\n",
  contextInfo: {
   mentionedJid: [m.sender], 
  },
}, {quoted: m}) 
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ressavekontak": {
  if (!isOwner) return m.reply(msg.owner)
  if (global.statussv == undefined) return m.reply("ID Grup tidak ditemukan.")
  if (!text) return m.reply("ID Grup tidak ditemukan.")

  try {
    const res = await sock.groupMetadata(text.trim())
    const halls = res.participants
      .filter(v => v.id.endsWith('.net'))
      .map(v => v.id)
      .filter(id => id !== botNumber && id.split("@")[0] !== global.owner)

    if (!halls.length) return m.reply("Tidak ada kontak yang bisa disimpan.")
    if (text !== m.chat) await m.reply(`Memroses savekontak dari grup ${res.subject} dengan total ${halls.length} member`)
    const existingContacts = JSON.parse(fs.readFileSync('./data/contacts.json', 'utf8') || '[]')
    const newContacts = [...new Set([...existingContacts, ...halls])]

    fs.writeFileSync('./data/contacts.json', JSON.stringify(newContacts, null, 2))

    // Buat file .vcf
    const vcardContent = newContacts.map(contact => {
      const phone = contact.split("@")[0]
      return [
        "BEGIN:VCARD",
        "VERSION:3.0",
        `FN:Contact - ${phone}`,
        `TEL;type=CELL;type=VOICE;waid=${phone}:+${phone}`,
        "END:VCARD",
        ""
      ].join("\n")
    }).join("")

    fs.writeFileSync("./data/contacts.vcf", vcardContent, "utf8")

    // Kirim ke private chat
    if (m.chat !== m.sender) {
      await m.reply(`*Berhasil membuat file kontak ✅*\n\nFile kontak telah dikirim ke private chat\nTotal *${halls.length}* kontak`)
    }

    await sock.sendMessage(
      m.sender,
      {
        document: fs.readFileSync("./data/contacts.vcf"),
        fileName: "contacts.vcf",
        caption: `File kontak berhasil dibuat ✅\nTotal *${halls.length}* kontak`,
        mimetype: "text/vcard",
      },
      { quoted: m }
    )

    // Reset file setelah dikirim
    fs.writeFileSync("./data/contacts.json", "[]")
    fs.writeFileSync("./data/contacts.vcf", "")
    delete global.statussv

  } catch (err) {
    m.reply("Terjadi kesalahan saat menyimpan kontak:\n" + err.toString())
  }
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "savekontak": {
  if (!isOwner) return m.reply(msg.owner)
  if (!m.isGroup) return m.reply(msg.group)

  try {
    const res = await m.metadata
    const halls = res.participants
      .filter(v => v.id.endsWith('.net'))
      .map(v => v.id)
      .filter(id => id !== botNumber && id.split("@")[0] !== global.owner)

    if (!halls.length) return m.reply("Tidak ada kontak yang bisa disimpan.")

    const existingContacts = JSON.parse(fs.readFileSync('./data/contacts.json', 'utf8') || '[]')
    const newContacts = [...new Set([...existingContacts, ...halls])]

    fs.writeFileSync('./data/contacts.json', JSON.stringify(newContacts, null, 2))

    // Buat file .vcf
    const vcardContent = newContacts.map(contact => {
      const phone = contact.split("@")[0]
      return [
        "BEGIN:VCARD",
        "VERSION:3.0",
        `FN:Contact - ${phone}`,
        `TEL;type=CELL;type=VOICE;waid=${phone}:+${phone}`,
        "END:VCARD",
        ""
      ].join("\n")
    }).join("")

    fs.writeFileSync("./data/contacts.vcf", vcardContent, "utf8")

    // Kirim ke private chat
    if (m.chat !== m.sender) {
      await m.reply(`*Berhasil membuat file kontak ✅*\n\nFile kontak telah dikirim ke private chat\nTotal *${halls.length}* kontak`)
    }

    await sock.sendMessage(
      m.sender,
      {
        document: fs.readFileSync("./data/contacts.vcf"),
        fileName: "contacts.vcf",
        caption: `File kontak berhasil dibuat ✅\nTotal *${halls.length}* kontak`,
        mimetype: "text/vcard",
      },
      { quoted: m }
    )

    // Reset file setelah dikirim
    fs.writeFileSync("./data/contacts.json", "[]")
    fs.writeFileSync("./data/contacts.vcf", "")

  } catch (err) {
    m.reply("Terjadi kesalahan saat menyimpan kontak:\n" + err.toString())
  }
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "pushkontak2": case "puskontak2": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("pesannya")
const meta = await sock.groupFetchAllParticipating()
let dom = await Object.keys(meta)
global.textpushkontak = text
let list = []
for (let i of dom) {
await list.push({
title: meta[i].subject, 
id: `.respushkontak ${i}`, 
description: `${meta[i].participants.length} Member`
})
}
return sock.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Target Grup Pushkontak\n",
  contextInfo: {
   mentionedJid: [m.sender], 
  },
}, {quoted: m}) 
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "respushkontak": {
if (!isOwner) return 
if (!text) return 
if (!global.textpushkontak) return
const idgc = text
const teks = global.textpushkontak
const jidawal = m.chat
const data = await sock.groupMetadata(idgc)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await m.reply(`Memproses *pushkontak* ke dalam grup *${data.subject}*`)

for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
await sock.sendMessage(mem, {text: teks}, {quoted: qtext})
await func.sleep(4000)
}}

delete global.textpushkontak
await sock.sendMessage(jidawal, {text: `*Pushkontak Berhasil ✅*\nTotal member : ${halls.length}`}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "addown": case "addowner": {
if (!isOwner) return m.reply(msg.owner)
if (!text && !m.quoted) return example("6285XX atau @tag")
let input = m.quoted ? m.quoted.sender : m.mentionedJid ? m.mentionedJid[0] : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
if (!input) return example("6285XX atau @tag")
if (ownplus.includes(input)) return m.reply(`Nomor ${input.split("@")[0]} sudah terdaftar sebagai owner!`)
if (input == botNumber) return m.reply(`Nomor ${input.split("@")[0]} sudah terdaftar sebagai owner!`)
if (input.split("@")[0] == global.owner) return m.reply(`Nomor ${input.split("@")[0]} sudah terdaftar sebagai owner!`)
await ownplus.push(input)
await fs.writeFileSync("./data/owner.json", JSON.stringify(ownplus, null, 2))
return m.reply(`Sukses menjadikan ${input.split("@")[0]} sebagai *owner*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "delown": case "delowner": {
if (!isOwner) return m.reply(msg.owner)
if (!text && !m.quoted) return example("6285XX atau @tag")
if (text == "all") {
ownplus.length = 0
await fs.writeFileSync("./data/owner.json", JSON.stringify(ownplus, null, 2))
return m.reply("Berhasil menghapus semua owner ✅")
}
let input = m.quoted ? m.quoted.sender : m.mentionedJid ? m.mentionedJid[0] : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
if (!input) return example("6285XX atau @tag")
if (!ownplus.includes(input)) return m.reply(`Nomor ${input.split("@")[0]} tidak terdaftar sebagai owner!`)
if (input == botNumber) return m.reply(`Nomor ${input.split("@")[0]} tidak terdaftar sebagai owner!`)
if (input.split("@")[0] == global.owner) return m.reply(`Nomor ${input.split("@")[0]} tidak terdaftar sebagai owner!`)
const posi = ownplus.indexOf(input)
await ownplus.splice(posi, 1)
await fs.writeFileSync("./data/owner.json", JSON.stringify(ownplus, null, 2))
return m.reply(`Sukses menghapus ${input.split("@")[0]} sebagai *owner*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "delppbot": case "delpp": {
if (!isOwner) return m.reply(msg.owner)
await sock.removeProfilePicture(botNumber)
m.reply("Berhasil menghapus profile bot ✅")
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "unblok": {
if (!isOwner) return
if (m.isGroup && !m.quoted && !text) return example("@tag/nomornya")
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await sock.updateBlockStatus(mem, "unblock");
if (m.isGroup) sock.sendMessage(m.chat, {text: `Berhasil membuka blokiran @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "block": case "blok": {
if (!isOwner) return
if (m.isGroup && !m.quoted && !text) return example("@tag/nomornya")
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await sock.updateBlockStatus(mem, "block")
if (m.isGroup) sock.sendMessage(m.chat, {text: `Berhasil memblokir @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "boost": case "delsampah": {
if (!isOwner) return m.reply(msg.owner)
let sampah = await fs.readdirSync('./server/tmp').filter(e => e !== "akses.txt")
if (sampah.length < 1) return m.reply("Tidak ada sampah")
const total = sampah.length
sampah.forEach((i) => {
fs.unlinkSync('./server/tmp/' + i)
})
m.reply(`Berhasil membersihkan ${total} sampah tmp`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "setppbot": case "setpp": {
if (!isOwner) return m.reply(msg.owner)
if (!/image/.test(mime)) return example("dengan mengirim foto")
const { S_WHATSAPP_NET } = require("baileys");

const buffer = await sock.downloadAndSaveMediaMessage(qmsg)
var { img } = await func.generateProfilePicture(buffer)
await sock.query({
tag: 'iq',
attrs: {
to: S_WHATSAPP_NET,
type: 'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
m.reply("Berhasil mengganti profile bot ✅")
fs.unlinkSync(buffer)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "joinch": case "joinchannel": {
if (!isOwner) return m.reply(msg.owner)
if (!text && !m.quoted) return example("linkchnya")
if (!text.includes("https://whatsapp.com/channel/") && !m.quoted.text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = m.quoted ? m.quoted.text.split('https://whatsapp.com/channel/')[1] : text.split('https://whatsapp.com/channel/')[1]
let res = await sock.newsletterMetadata("invite", result)
await sock.newsletterFollow(res.id)
m.reply(`*Berhasil join channel whatsapp ✅*

* Nama channel : *${res.name}*
* Total pengikut : *${res.subscribers + 1}*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "joingc": case "join": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("linkgcnya")
if (!text.includes("chat.whatsapp.com")) return m.reply("Link tautan tidak valid")
let result = text.split('https://chat.whatsapp.com/')[1]
try {
let id = await sock.groupAcceptInvite(result)
await m.reply(`Berhasil bergabung ke dalam grup ${id}`)
} catch (err) {
return m.reply(err.toString())
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "reactch": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("linkpesan 😂")
if (!args[0] || !args[1]) return example("linkpesan 😂")
if (!args[0].includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = args[0].split('/')[4]
let serverId = args[0].split('/')[5]
let res = await sock.newsletterMetadata("invite", result)
await sock.newsletterReactMessage(res.id, serverId, args[1])
m.reply(`Berhasil mengirim reaction ${args[1]} ke dalam channel ${res.name}`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "cekidch": case "idch": {
if (!text) return example("linkchnya")
if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await sock.newsletterMetadata("invite", result)
let teks = `${res.id}

* ${res.name}
* ${res.subscribers} Pengikut`
return m.reply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "sendtesti":
case "testi":
case "uptesti": {
    if (!isOwner) return m.reply(msg.owner)
    if (!text) return example("Teks dengan mengirim foto")

    let mediaPath
    const mimeType = mime

    // Unduh media jika ada dan bertipe gambar
    if (/image/.test(mimeType)) {
        mediaPath = await sock.downloadAndSaveMediaMessage(qmsg)
    }

    const allGroups = await sock.groupFetchAllParticipating()
    const groupIds = Object.keys(allGroups)
    let successCount = 0
    const messageText = text
    const senderChat = m.chat

    await m.reply(`Memproses jpm testimoni ke saluran & ${groupIds.length} grup...`)

    // Kirim ke saluran utama
    try {
        const messageContent = mediaPath
            ? { image: await fs.readFileSync(mediaPath), caption: messageText }
            : { text: messageText }

        await sock.sendMessage(global.idsaluran, messageContent)
    } catch (err) {
        console.error("Gagal mengirim ke saluran:", err)
    }

    // Siapkan konten untuk dikirim ke grup
    const groupMessage = mediaPath
        ? { image: await fs.readFileSync(mediaPath), caption: messageText }
        : { text: messageText }

    // Kirim ke semua grup kecuali yang diblacklist
    for (const groupId of groupIds) {
        if (bljpm.includes(groupId)) continue

        try {
            await sock.sendMessage(groupId, {
                ...groupMessage,
                contextInfo: {
                    isForwarded: true,
                    mentionedJid: [m.sender],
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: global.idsaluran,
                        newsletterName: global.namasaluran
                    }
                }
            }, { quoted: m })

            successCount++
        } catch (err) {
            console.error(`Gagal mengirim ke grup ${groupId}:`, err)
        }

        // Delay 5 detik agar tidak spam
        await func.sleep(5000)
    }

    // Hapus file media jika ada
    if (mediaPath) {
        await fs.unlinkSync(mediaPath)
    }

    // Kirim notifikasi sukses ke pengirim
    await sock.sendMessage(senderChat, {
        text: `Testimoni berhasil dikirim ke saluran & ${successCount} grup.`,
    }, { quoted: m })

}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "jpm": {
    if (!isOwner) return m.reply(msg.owner)
    if (!text) return example("Teksnya & foto (opsional)")

    let mediaPath
    const mimeType = mime

    // Unduh gambar jika tersedia
    if (/image/.test(mimeType)) {
        mediaPath = await sock.downloadAndSaveMediaMessage(qmsg)
    }

    const allGroups = await sock.groupFetchAllParticipating()
    const groupIds = Object.keys(allGroups)
    let successCount = 0
    const messageContent = mediaPath
        ? { image: await fs.readFileSync(mediaPath), caption: text }
        : { text }

    const senderChat = m.chat

    await m.reply(`Memproses ${mediaPath ? "JPM teks & foto" : "JPM teks"} ke ${groupIds.length} grup chat...`)

    for (const groupId of groupIds) {
        if (bljpm.includes(groupId)) continue

        try {
            await sock.sendMessage(groupId, messageContent, { quoted: qtext })
            successCount++
        } catch (err) {
            console.error(`Gagal kirim ke grup ${groupId}:`, err)
        }

        await func.sleep(5000) // Delay antar grup
    }

    // Hapus file jika ada
    if (mediaPath) await fs.unlinkSync(mediaPath)

    await sock.sendMessage(senderChat, {
        text: `JPM ${mediaPath ? "teks & foto" : "teks"} berhasil dikirim ke ${successCount} grup.`,
    }, { quoted: m })

}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpmht": {
    if (!isOwner) return m.reply(msg.owner)
    if (!text) return example("Teksnya & foto (opsional)")

    let mediaPath
    const mimeType = mime

    // Download gambar jika ada
    if (/image/.test(mimeType)) {
        mediaPath = await sock.downloadAndSaveMediaMessage(qmsg)
    }

    const allGroups = await sock.groupFetchAllParticipating()
    const groupIds = Object.keys(allGroups)
    let successCount = 0
    const senderChat = m.chat
    const messageType = mediaPath ? "teks & foto ht" : "teks ht"

    await m.reply(`Memproses JPM *${messageType}* ke ${groupIds.length} grup chat...`)

    for (const groupId of groupIds) {
        // Lewati grup yang diblacklist dari JPM
        const isBlacklisted = global.db.groups[groupId]?.blacklistjpm === true
        if (isBlacklisted) continue

        try {
            const participants = allGroups[groupId].participants.map(p => p.id)
            const messageContent = mediaPath
                ? { image: await fs.readFileSync(mediaPath), caption: text, mentions: participants }
                : { text, mentions: participants }

            await sock.sendMessage(groupId, messageContent, { quoted: qtext })
            successCount++
        } catch (err) {
            console.error(`Gagal kirim ke grup ${groupId}:`, err)
        }

        await func.sleep(5000) // Delay antar grup
    }

    // Hapus file jika ada
    if (mediaPath) await fs.unlinkSync(mediaPath)

    // Balas ke pengirim sebagai konfirmasi
    await sock.sendMessage(senderChat, {
        text: `JPM *${messageType}* berhasil dikirim ke ${successCount} grup.`,
    }, { quoted: m })
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpmch": {
    if (!isOwner) return m.reply(msg.owner)
    if (!channel || channel.length < 1) return m.reply("Tidak ada ID channel di dalam database `idch`.")
    if (!text) return example("Teksnya & foto (opsional)")

    let mediaPath
    const mimeType = mime

    // Download media jika ada
    if (/image/.test(mimeType)) {
        mediaPath = await sock.downloadAndSaveMediaMessage(qmsg)
    }

    const channelList = channel
    let successCount = 0
    const messageType = mediaPath ? "teks & foto" : "teks"
    const senderChat = m.chat

    const messageContent = mediaPath
        ? { image: await fs.readFileSync(mediaPath), caption: text }
        : { text }

    await m.reply(`Memproses JPM ${messageType} ke ${channelList.length} Channel WhatsApp...`)

    for (const chId of channelList) {
        try {
            await sock.sendMessage(chId, messageContent)
            successCount++
        } catch (err) {
            console.error(`Gagal kirim ke channel ${chId}:`, err)
        }

        await func.sleep(5000)
    }

    // Hapus file jika perlu
    if (mediaPath) await fs.unlinkSync(mediaPath)

    await sock.sendMessage(senderChat, {
        text: `JPM ${messageType} berhasil dikirim ke ${successCount} Channel WhatsApp.`,
    }, { quoted: m })
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addidch":
case "addid": {
    if (!isOwner) return m.reply(msg.owner)
    let ids
    if (text.includes("https://whatsapp.com/channel")) {
    let result = text.split('https://whatsapp.com/channel/')[1]
    let res = await sock.newsletterMetadata("invite", result)
    ids = [res.id]
    } else if (text.includes("@newsletter")) {
    ids = text.split(",").map(i => i.trim()) 
    if (ids.some(id => !id.endsWith("@newsletter"))) {
        return example("idch1,idch2 (bisa berapapun)")
    }
    } else {
    return example("idch1, idch2 (bisa berapapun) bisa pake linkchnya juga)")
    }

    let newIds = ids.filter(id => !channel.includes(id)) // Hindari duplikasi

    if (newIds.length === 0) {
        return m.reply("Semua ID yang dimasukkan sudah ada dalam daftar ❌")
    }

    channel.push(...newIds) // Tambahkan ID baru

    try {
        await fs.writeFileSync("./data/channel.json", JSON.stringify(channel, null, 2))
        m.reply(`Berhasil menambah ${newIds.length} ID channel ✅`)
    } catch (err) {
        console.error("Error menyimpan file:", err)
        m.reply("Terjadi kesalahan saat menyimpan data ❌")
    }
    }
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listidch": case "listid": {
if (channel.length < 1) return m.reply("Tidak ada id ch didalam database idch")
let teks = `\n *Total ID Channel :* ${channel.length}\n`
for (let i of channel) {
let res = await sock.newsletterMetadata("jid", i)
teks += `\n* ${i}
* ${res.name}\n`
}
sock.sendMessage(m.chat, {text: teks, mentions: []}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delidch":
case "delid": {
    if (!isOwner) return m.reply(msg.owner)
    if (!channel || channel.length < 1) return m.reply("Tidak ada ID Channel di dalam database `idch`.")
    if (!text) return example("ID Channel yang ingin dihapus atau ketik `all` untuk menghapus semuanya.")

    const input = text.trim()

    // Hapus semua channel
    if (input.toLowerCase() === "all") {
        channel.length = 0
        await fs.writeFileSync("./data/channel.json", JSON.stringify(channel, null, 2))
        return m.reply("Berhasil menghapus *semua* ID Channel ✅")
    }

    // Cek apakah ID Channel tersedia
    if (!channel.includes(input)) {
        return m.reply(`ID Channel \`${input}\` tidak ditemukan dalam database.`)
    }

    // Hapus satu ID Channel
    const index = channel.indexOf(input)
    channel.splice(index, 1)
    await fs.writeFileSync("./data/channel.json", JSON.stringify(channel, null, 2))
    m.reply(`Berhasil menghapus ID Channel: *${input}* ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "subdo": case "subdomain": case "domain": { if (!isOwner) return m.reply(msg.owner);

if (!text) {
    const obj = Object.keys(domains);
    let teks = `\n`;
    obj.forEach((domain, index) => {
        teks += `* ${index + 1}. ${domain}\n`;
    });
    teks += `\nContoh Penggunaan :\n *.domain* 2 host|ipvps\n`;
    return m.reply(teks);
}

if (!args[0] || isNaN(args[0])) return m.reply("Domain tidak ditemukan!");

const dom = Object.keys(domains);
const domainIndex = Number(args[0]) - 1;
if (domainIndex >= dom.length || domainIndex < 0) return m.reply("Domain tidak ditemukan!");

if (!args[1] || !args[1].includes("|")) return m.reply("Hostname/IP Tidak ditemukan!");

let tldnya = dom[domainIndex];
const [host, ip] = args[1].split("|").map(str => str.trim());

async function subDomain1(host, ip) {
    return new Promise((resolve) => {
        axios.post(
            `https://api.cloudflare.com/client/v4/zones/${domains[tldnya].zone}/dns_records`,
            {
                type: "A",
                name: `${host.replace(/[^a-z0-9.-]/gi, "")}.${tldnya}`,
                content: ip.replace(/[^0-9.]/gi, ""),
                ttl: 3600,
                priority: 10,
                proxied: false,
            },
            {
                headers: {
                    Authorization: `Bearer ${domains[tldnya].apitoken}`,
                    "Content-Type": "application/json",
                },
            }
        ).then(response => {
            let res = response.data;
            if (res.success) {
                resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
            } else {
                resolve({ success: false, error: "Gagal membuat subdomain." });
            }
        }).catch(error => {
            let errorMsg = error.response?.data?.errors?.[0]?.message || error.message || "Terjadi kesalahan!";
            resolve({ success: false, error: errorMsg });
        });
    });
}

let teks = `*Berhasil membuat subdomain ✅*\n\n*🚀 IP Address :* ${ip}\n`;
const domnode = `node${func.getRandom("")}.${host}`;

for (let i = 0; i < 2; i++) {
    let subHost = i === 0 ? host.toLowerCase() : domnode;
    try {
        let result = await subDomain1(subHost, ip);
        if (result.success) {
            teks += `*🌐 ${result.name}*\n`;
        } else {
            return m.reply(result.error);
        }
    } catch (err) {
        return m.reply("Error: " + err.message);
    }
}

await m.reply(teks);

}
break;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "adddomain":
case "adddom": {
    if (!isOwner) return m.reply(msg.owner)
    if (!text) return example("domain|zoneid|apitoken")

    let [dom, zone, api] = text.split("|").map(i => i.trim())

    // Validasi input
    if (!dom || !zone || !api) {
        return example("domain|zoneid|apitoken")
    }

    dom = dom.toLowerCase()

    // Cek apakah domain sudah terdaftar
    if (domains[dom]) {
        return m.reply(`Domain *${dom}* sudah terdaftar di dalam database subdomain.`)
    }

    // Simpan ke database
    domains[dom] = {
        zone: zone,
        apitoken: api
    }

    try {
        await fs.writeFileSync("./data/domain.json", JSON.stringify(domains, null, 2))
        m.reply(`Berhasil menambahkan domain *${dom}* ✅`)
    } catch (err) {
        console.error("Gagal menulis file domain:", err)
        m.reply("Terjadi kesalahan saat menyimpan domain. Coba lagi nanti.")
    }

    break
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "deldomain":
case "deldom": {
    if (!isOwner) return m.reply(msg.owner)
    
    if (!domains || Object.keys(domains).length === 0) {
        return m.reply("Tidak ada domain yang terdaftar di dalam database subdomain.")
    }

    if (!text) return example("domain yang ingin dihapus atau ketik `all` untuk menghapus semuanya.")

    const dom = text.trim().toLowerCase()

    if (dom === "all") {
        domains = {}
        try {
            await fs.writeFileSync("./data/domain.json", JSON.stringify(domains, null, 2))
            return m.reply("Berhasil menghapus *semua* domain ✅")
        } catch (err) {
            console.error("Gagal menulis file domain:", err)
            return m.reply("Terjadi kesalahan saat menghapus semua domain.")
        }
    }

    if (!domains[dom]) {
        return m.reply(`Domain *${dom}* tidak ditemukan dalam database subdomain.`)
    }

    delete domains[dom]

    try {
        await fs.writeFileSync("./data/domain.json", JSON.stringify(domains, null, 2))
        m.reply(`Berhasil menghapus domain *${dom}* ✅`)
    } catch (err) {
        console.error("Gagal menyimpan perubahan:", err)
        m.reply("Terjadi kesalahan saat menyimpan perubahan.")
    }

    break
}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listdomain": case "listdom": {
if (!isOwner) return m.reply(msg.owner)
if (Object.keys(domains).length < 1) return m.reply("Tidak ada domain di database subdomain")
let teks = "\n"
for (let i of Object.keys(domains)) {
teks += `* ${i}\n`
}
teks += `\nContoh Penggunaan :\n *.domain* 2 host|ipvps\n`
return m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "addscript":
case "addsc": {
    if (!isOwner) return m.reply(msg.owner)

    if (!text || !m.quoted) {
        return example("namasc|harga (contoh: mybot|30000) dengan reply file script (.zip)")
    }

    const mimeType = mime
    if (!/zip/.test(mimeType)) {
        return m.reply("File harus berformat *.zip*")
    }

    let [namasc, harga] = text.split("|").map(v => v.trim())
    if (!namasc || !harga || isNaN(harga)) {
        return example("namasc|harga (contoh: mybot|30000)")
    }

    harga = Number(harga)
    const scriptPath = `./data/script/${namasc}.zip`

    // Tambahkan ke database script
    script.push({
        nama: namasc,
        path: scriptPath,
        harga: harga.toString()
    })

    try {
        await fs.writeFileSync("./data/script.json", JSON.stringify(script, null, 2))
        const buffer = await m.quoted.download()
        await fs.writeFileSync(scriptPath, buffer)
        return m.reply(`Berhasil menambahkan script *${namasc}* ✅`)
    } catch (err) {
        console.error("Gagal menyimpan script:", err)
        return m.reply("Terjadi kesalahan saat menyimpan script.")
    }

    break
}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listscript": case "listsc": {
if (!isOwner) return m.reply(msg.owner)
if (script.length < 1) return m.reply("Tidak ada Script Bot.")
let teks = ""
let id = 0
for (let i of script) {
id += 1
teks += `
* *ID :* ${id}
* *Nama :* ${i.nama}
* *Harga :* Rp${func.toRupiah(i.harga)}
`
}
return m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "delscript":
case "delsc": {
    if (!isOwner) return m.reply(msg.owner)

    if (!script || script.length === 0) {
        return m.reply("Tidak ada Script Bot yang tersimpan.")
    }

    if (!text) return example("idscript atau `all`")

    const isDeleteAll = text.trim().toLowerCase() === "all"

    if (isDeleteAll) {
        try {
            const files = fs.readdirSync("./data/script").filter(file => file.endsWith(".zip"))
            for (const file of files) {
                const filePath = `./data/script/${file}`
                if (fs.existsSync(filePath)) fs.unlinkSync(filePath)
            }

            script.length = 0
            await fs.writeFileSync("./data/script.json", JSON.stringify(script, null, 2))
            return m.reply("Berhasil menghapus *semua* Script ✅")
        } catch (err) {
            console.error("Gagal menghapus semua script:", err)
            return m.reply("Terjadi kesalahan saat menghapus semua script.")
        }
    }

    // Hapus berdasarkan ID script
    if (isNaN(text)) return example("idscript (angka urutan)")

    const number = Number(text)
    if (number < 1 || number > script.length) {
        return m.reply("ID Script tidak ditemukan.")
    }

    const sc = script[number - 1]
    const namasc = sc.nama

    try {
        if (fs.existsSync(sc.path)) fs.unlinkSync(sc.path)
        script.splice(number - 1, 1)
        await fs.writeFileSync("./data/script.json", JSON.stringify(script, null, 2))
        return m.reply(`Berhasil menghapus script *${namasc}* ✅`)
    } catch (err) {
        console.error("Gagal menghapus script:", err)
        return m.reply("Terjadi kesalahan saat menghapus script.")
    }

    break
}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "getscript":
case "getsc": {
    if (!isOwner) return m.reply(msg.owner)

    if (!script || script.length === 0) {
        return m.reply("Tidak ada Script Bot yang tersimpan.")
    }

    if (!text || isNaN(text)) return example("idscript (angka urutan)")

    const number = Number(text)
    if (number < 1 || number > script.length) {
        return m.reply("ID Script tidak ditemukan.")
    }

    const sc = script[number - 1]
    const filePath = sc.path

    if (!fs.existsSync(filePath)) {
        return m.reply("File script tidak ditemukan di direktori.")
    }

    try {
        const buffer = await fs.readFileSync(filePath)
        await sock.sendMessage(m.chat, {
            document: buffer,
            mimetype: "application/zip",
            fileName: `${sc.nama}.zip`
        }, { quoted: m })
    } catch (err) {
        console.error("Gagal mengirim file script:", err)
        return m.reply("Terjadi kesalahan saat mengirim file script.")
    }

    break
}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "adddo":
case "addstokdo": {
    if (!isOwner) return m.reply(msg.owner)
    if (!text) return example("ikyy@gmail.com|password|kode2fa|kodereferal|drop(contoh 3)|harga(contoh 130000)")
    
    const cek = text.split("|");
    if (cek.length !== 6) return example("ikyy@gmail.com|password|kode2fa|kodereferal|drop(contoh 3)|harga(contoh 130000)")

    let [email, pw, kode2fa, reff, droplet, harga] = cek;
    
    if (isNaN(harga)) return m.reply("Harga harus berupa angka!");

    stokdo.push({
        email: email.trim(), 
        password: pw.trim(), 
        kode2fa: kode2fa.trim(), 
        referall: reff.trim(), 
        droplet: droplet.trim(), 
        harga: Number(harga.trim())
    });

    await fs.writeFileSync("./data/stokdo.json", JSON.stringify(stokdo, null, 2));
    await m.reply("Berhasil menambah data stok digitalocean ✅");
}
break;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delstokdo":
case "deldo": {
    if (!isOwner) return m.reply(msg.owner)
    if (stokdo.length < 1) return m.reply("Tidak ada stok digitalocean.");


    if (text === "all") {
        stokdo.length = 0; // Menghapus semua data
        await fs.writeFileSync("./data/stokdo.json", JSON.stringify(stokdo, null, 2));
        return m.reply(`Berhasil menghapus semua stok data akun DigitalOcean ✅`);
    }

    if (!text || isNaN(text)) return example("ID Stok yang ingin dihapus\n\nKetik *.liststok* untuk melihat daftar stok.")
    
    let inx = Number(text) - 1;
    if (inx < 0 || inx >= stokdo.length) return m.reply("ID stok tidak ditemukan.");

    stokdo.splice(inx, 1);
    await fs.writeFileSync("./data/stokdo.json", JSON.stringify(stokdo, null, 2));
    await m.reply("Berhasil menghapus data stok DigitalOcean ✅");
}
break;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "liststokdo":
case "listdo": {
    if (!isOwner) return m.reply(msg.owner)
    if (m.isGroup) return m.reply(msg.private)
    if (stokdo.length < 1) return m.reply("Tidak ada stok digitalocean.");

    let messageText = "";
    stokdo.forEach((res, index) => {
        messageText += `\n* *ID Stok :* ${index + 1}\n`;
        messageText += `* *Email :* ${res.email}\n`;
        messageText += `* *Password :* ${res.password}\n`;
        messageText += `* *Kode 2FA :* ${res.kode2fa}\n`;
        messageText += `* *Referall :* ${res.referall}\n`;
        messageText += `* *Harga :* Rp${func.toRupiah(res.harga.toString())}\n`;
        messageText += `* *Droplet :* ${res.droplet}\n`;
    });

    return m.reply(messageText);
}
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "uninstallpanel": { 
if (!isOwner) return m.reply(msg.owner); 
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps")); 
var vpsnya = text.split("|"); 
if (vpsnya.length < 2) return m.reply(example("ipvps|pwvps|domain"));
let ipvps = vpsnya[0]; 
let passwd = vpsnya[1]; 
const connSettings = { host: ipvps, port: '22', username: 'root', password: passwd }; 
const boostmysql = `\n`; 
const command = `bash <(curl -s https://pterodactyl-installer.se)`; 
const ress = new ssh2.Client();

ress.on('ready', async () => {
    await m.reply("Memproses *uninstall* server panel\nTunggu 1-10 menit hingga proses selesai");

    ress.exec(command, async (err, stream) => {
        if (err) throw err;
        stream.on('close', async (code, signal) => {
            await ress.exec(boostmysql, async (err, stream) => {
                if (err) throw err;
                stream.on('close', async (code, signal) => {
                    await m.reply("Berhasil *uninstall* server panel ✅");

                    // Hapus database yang berhubungan dengan Pterodactyl setelah uninstall panel
                    const conn2 = new ssh2.Client();
                    conn2.on('ready', () => {
                        const dropPterodactylDatabasesCommand = `mysql -u root -p -e "SELECT schema_name FROM information_schema.schemata WHERE schema_name LIKE '%pterodactyl%'" | tail -n +2 | xargs -I {} mysql -u root -p -e 'DROP DATABASE IF EXISTS {};';`;
                        
                        conn2.exec(dropPterodactylDatabasesCommand, (err, stream) => {
                            if (err) throw err;
                            
                            let result = '';
                            
                            stream.on('data', (data) => {
                                result += data;
                            }).stderr.on('data', (data) => {
                                result += 'STDERR: ' + data;
                            });
                            
                            stream.on('close', (code, signal) => {
                                console.log(`Pterodactyl database deletion exited with code ${code}`);
                                console.log('Pterodactyl Database Deletion Output:', result);
                                conn2.end();
                            });
                        });
                    }).connect(connSettings);
                }).on('data', async (data) => {
                    await console.log(data.toString());
                    if (data.toString().includes(`Remove all MariaDB databases? [yes/no]`)) {
                        await stream.write("\x09\n");
                    }
                }).stderr.on('data', (data) => {
                    m.reply('Berhasil Uninstall Server Panel ✅');
                });
            });
        }).on('data', async (data) => {
            await console.log(data.toString());
            if (data.toString().includes(`Input 0-6`)) {
                await stream.write("6\n");
            }
            if (data.toString().includes(`(y/N)`)) {
                await stream.write("y\n");
            }
            if (data.toString().includes(`* Choose the panel user (to skip don\'t input anything):`)) {
                await stream.write("\n");
            }
            if (data.toString().includes(`* Choose the panel database (to skip don\'t input anything):`)) {
                await stream.write("\n");
            }
        }).stderr.on('data', (data) => {
            m.reply('STDERR: ' + data);
        });
    });
}).on('error', (err) => {
    m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);

}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "installpanel": {
    if (!isOwner) return m.reply(msg.owner);
    if (!text) return example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*");
    
    let vii = text.split("|");
    if (vii.length < 5) return example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*");
    
    const ress = new ssh2.Client();
    const connSettings = {
        host: vii[0],
        port: '22',
        username: 'root',
        password: vii[1]
    };
    
    const jids = m.chat
    const pass = "admin1";
    let passwordPanel = pass;
    const domainpanel = vii[2];
    const domainnode = vii[3];
    const ramserver = vii[4];
    const deletemysql = `\n`;
    const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`;
    
    async function instalWings() {
    ress.exec(commandPanel, async (err, stream) => {
        if (err) {
            console.error('Wings installation error:', err);
            m.reply(`Gagal memulai instalasi Wings: ${err.message}`);
            return ress.end();
        }
        
        stream.on('close', async (code, signal) => {
            await InstallNodes()            
        }).on('data', async (data) => {
            const dataStr = data.toString();
            console.log('Wings Install: ' + dataStr);
            
            if (dataStr.includes('Input 0-6')) {
                stream.write('1\n');
            }
            else if (dataStr.includes('(y/N)')) {
                stream.write('y\n');
            }
            else if (dataStr.includes('Enter the panel address (blank for any address)')) {
                stream.write(`${domainpanel}\n`);
            }
            else if (dataStr.includes('Database host username (pterodactyluser)')) {
                stream.write('admin\n');
            }
            else if (dataStr.includes('Database host password')) {
                stream.write('admin\n');
            }
            else if (dataStr.includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
                stream.write(`${domainnode}\n`);
            }
            else if (dataStr.includes('Enter email address for Let\'s Encrypt')) {
                stream.write('admin@gmail.com\n');
            }
        }).stderr.on('data', async (data) => {
            console.error('Wings Install Error: ' + data);
            m.reply(`Error pada instalasi Wings:\n${data}`);
        });
    });
}

    async function InstallNodes() {
        ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
            if (err) throw err;
            
            stream.on('close', async (code, signal) => {
                let teks = `
*Install Panel Telah Berhasil ✅*

*Berikut Detail Akun Panel Kamu 📦*

*👤 Username :* admin
*🔐 Password :* ${passwordPanel}
*🌐 ${domainpanel}*

Silahkan setting alocation & ambil token node di node yang sudah di buat oleh bot

*Cara menjalankan wings :*
*.startwings* ipvps|pwvps|tokennode
`;
                await sock.sendMessage(jids, {text: teks}, {quoted: m})
                ress.end();
            }).on('data', async (data) => {
                await console.log(data.toString());
                if (data.toString().includes("Masukkan nama lokasi: ")) {
                    stream.write('Singapore\n');
                }
                if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
                    stream.write('Node By Ikyy\n');
                }
                if (data.toString().includes("Masukkan domain: ")) {
                    stream.write(`${domainnode}\n`);
                }
                if (data.toString().includes("Masukkan nama node: ")) {
                    stream.write('Skyzopedia\n');
                }
                if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
                    stream.write(`${ramserver}\n`);
                }
                if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
                    stream.write(`${ramserver}\n`);
                }
                if (data.toString().includes("Masukkan Locid: ")) {
                    stream.write('1\n');
                }
            }).stderr.on('data', async (data) => {
                console.log('Stderr : ' + data);
                m.reply(`Error pada instalasi Wings: ${data}`);
            });
        });
    }

    async function instalPanel() {
        ress.exec(commandPanel, (err, stream) => {
            if (err) throw err;
            
            stream.on('close', async (code, signal) => {
                await instalWings();
            }).on('data', async (data) => {
                if (data.toString().includes('Input 0-6')) {
                    stream.write('0\n');
                } 
                if (data.toString().includes('(y/N)')) {
                    stream.write('y\n');
                } 
                if (data.toString().includes('Database name (panel)')) {
                    stream.write('\n');
                }
                if (data.toString().includes('Database username (pterodactyl)')) {
                    stream.write('admin\n');
                }
                if (data.toString().includes('Password (press enter to use randomly generated password)')) {
                    stream.write('admin\n');
                } 
                if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
                    stream.write('Asia/Jakarta\n');
                } 
                if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
                    stream.write('admin@gmail.com\n');
                } 
                if (data.toString().includes('Email address for the initial admin account')) {
                    stream.write('admin@gmail.com\n');
                } 
                if (data.toString().includes('Username for the initial admin account')) {
                    stream.write('admin\n');
                } 
                if (data.toString().includes('First name for the initial admin account')) {
                    stream.write('admin\n');
                } 
                if (data.toString().includes('Last name for the initial admin account')) {
                    stream.write('admin\n');
                } 
                if (data.toString().includes('Password for the initial admin account')) {
                    stream.write(`${passwordPanel}\n`);
                } 
                if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
                    stream.write(`${domainpanel}\n`);
                } 
                if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
                    stream.write('y\n')
                } 
                if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
                    stream.write('y\n');
                } 
                if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
                    stream.write('1\n');
                } 
                if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
                    stream.write('y\n');
                }
                if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
                    stream.write('y\n');
                } 
                if (data.toString().includes('(yes/no)')) {
                    stream.write('y\n');
                } 
                if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
                    stream.write('y\n');
                } 
                if (data.toString().includes('Still assume SSL? (y/N)')) {
                    stream.write('y\n');
                } 
                if (data.toString().includes('Please read the Terms of Service')) {
                    stream.write('y\n');
                }
                if (data.toString().includes('(A)gree/(C)ancel:')) {
                    stream.write('A\n');
                } 
                console.log('Logger: ' + data.toString());
            }).stderr.on('data', (data) => {
                m.reply(`Error Terjadi kesalahan :\n${data}`);
                console.log('STDERR: ' + data);
            });
        });
    }

    ress.on('ready', async () => {
        await m.reply(`*Memproses install server panel 🚀*\n\n` +
                     `*IP Address:* ${vii[0]}\n` +
                     `*Domain Panel:* ${domainpanel}\n\n` +
                     `Mohon tunggu 10-20 menit hingga proses install selesai`);
        
        ress.exec(deletemysql, async (err, stream) => {
            if (err) throw err;
            
            stream.on('close', async (code, signal) => {
                await instalPanel();
            }).on('data', async (data) => {
                await stream.write('\t');
                await stream.write('\n');
                await console.log(data.toString());
            }).stderr.on('data', async (data) => {
                m.reply(`Error Terjadi kesalahan :\n${data}`);
                console.log('Stderr : ' + data);
            });
        });
    });

    ress.on('error', (err) => {
        console.error('SSH Connection Error:', err);
        m.reply(`Gagal terhubung ke server: ${err.message}`);
    });

    ress.connect(connSettings);
    break;
}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "startwings":
case "configurewings": {
    if (!isOwner) return m.reply(msg.owner);

    let t = text.split('|');
    if (t.length < 3) return example("ipvps|pwvps|token_node");

    let ipvps = t[0].trim();
    let passwd = t[1].trim();
    let token = t[2].trim();

    const connSettings = {
        host: ipvps,
        port: 22,
        username: 'root',
        password: passwd
    };

    const command = `${token} && systemctl start wings`;

    const ress = new ssh2.Client();

    ress.on('ready', () => {
        ress.exec(command, (err, stream) => {
            if (err) {
                m.reply('Gagal menjalankan perintah di VPS');
                ress.end();
                return;
            }

            stream.on('close', async (code, signal) => {
                await m.reply("*Berhasil menjalankan wings ✅*");
                ress.end();
            }).on('data', (data) => {
                console.log("STDOUT:", data.toString());
            }).stderr.on('data', (data) => {
                console.log("STDERR:", data.toString());
                // Opsi jika perlu input interaktif
                stream.write("y\n");
                stream.write("systemctl start wings\n");
                m.reply('Terjadi error saat eksekusi:\n' + data.toString());
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error:', err.message);
        m.reply('Gagal terhubung ke VPS: IP atau password salah.');
    }).connect(connSettings);
}
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "gantipw":
case "gantipwvps": {
    if (!isOwner) return m.reply(msg.owner);

    let t = text.split('|');
    if (t.length < 3) return example("ipvps|pwvps|pwbaru");

    let ipvps = t[0].trim();
    let oldPass = t[1].trim();
    let newPass = t[2].trim();

    const connSettings = {
        host: ipvps,
        port: 22,
        username: 'root',
        password: oldPass
    };

    const command = `passwd`;
    const ssh = new ssh2.Client();

    ssh.on('ready', () => {
        ssh.exec(command, (err, stream) => {
            if (err) {
                m.reply("Gagal menjalankan perintah `passwd`.");
                ssh.end();
                return;
            }

            let output = "";

            stream.on('data', (data) => {
                output += data.toString();
                console.log("STDOUT:", output);

                // Cek prompt dan kirim input password
                if (output.toLowerCase().includes("new password")) {
                    stream.write(`${newPass}\n`);
                } else if (output.toLowerCase().includes("retype new password")) {
                    stream.write(`${newPass}\n`);
                }
            });

            stream.stderr.on('data', (data) => {
                console.error("STDERR:", data.toString());
            });

            stream.on('close', async () => {
                if (output.toLowerCase().includes("password updated successfully")) {
                    await m.reply(`
*Berhasil mengubah password VPS ✅*

* *Password lama:* ${oldPass}
* *Password baru:* ${newPass}
`);
                } else {
                    await m.reply("Gagal mengubah password. Pastikan VPS menerima perintah dengan benar.");
                }
                ssh.end();
            });
        });
    }).on('error', (err) => {
        console.error('Connection Error:', err.message);
        m.reply('Gagal terhubung ke VPS: IP atau password salah.');
    }).connect(connSettings);
}
break;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listgc": case "listgrup": {
if (!isOwner) return
let teks = `\n`
let a = await sock.groupFetchAllParticipating()
let gc = Object.values(a)
teks += `\n* *Total group :* ${gc.length}\n`
for (const u of gc) {
teks += `\n* *ID :* ${u.id}
* *Nama :* ${u.subject}
* *Member :* ${u.participants.length}
* *Status :* ${u.announce == false ? "Terbuka": "Hanya Admin"}
* *Pembuat :* ${u?.subjectOwner ? u?.subjectOwner.split("@")[0] : "Sudah Keluar"}\n`
}
return m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "done": case "proses": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("jasa install panel")
let teks = `
*Dana Masuk ✅*
* ${text}
* ${func.tanggal(Date.now())}
`
await sock.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, "0@s.whatsapp.net", global.owner+"@s.whatsapp.net"], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idsaluran,
   newsletterName: global.namasaluran
   }
  },}, {quoted: null})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "dana": {
let tekspay = `
*Dana :* ${global.dana}
`
return sock.sendText(m.chat, tekspay, qtext)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ovo": {
let tekspay = `
*Ovo :* ${global.ovo}
`
return sock.sendText(m.chat, tekspay, qtext)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "gopay": {
let tekspay = `
*Gopay :* ${global.gopay}
`
return sock.sendText(m.chat, tekspay, qtext)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "qris": {
return sock.sendMessage(m.chat, {image: {url: global.qris}}, {quoted: qtext})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listown": case "listowner": {
if (ownplus.length < 1) return m.reply("Tidak ada owner tambahan!")
var teks = ""
teks += `\n @${global.owner}\n`
for (let i of ownplus) {
teks += `\n * @${i.split("@")[0]}\n`
}
await sock.sendMessage(m.chat, {text: teks, mentions: ownplus}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "play": {
    if (!text) return example("one of the girls");

    m.reply("🔎 Sedang mencari lagu, mohon tunggu...");

    try {
        let ytsSearch = await yts(text);
        if (!ytsSearch?.all?.length) {
            return m.reply("Lagu tidak ditemukan, coba kata kunci lain.");
        }

        const res = ytsSearch.all[0];
        const anu = await func.fetchJson(`https://api-simplebot.vercel.app/download/ytmp3?apikey=${global.ApikeyRestApi}&url=`+res.url);

        if (anu?.result) {
            let urlMp3 = anu.result.media

            await sock.sendMessage(m.chat, {
                audio: { url: urlMp3 },
                mimetype: "audio/mpeg",
                contextInfo: {
                    externalAdReply: {
                        thumbnailUrl: res.thumbnail,
                        title: res.title,
                        body: `Author: ${res.author.name} | Duration: ${res.timestamp}`,
                        sourceUrl: res.url,
                        renderLargerThumbnail: true,
                        mediaType: 1
                    }
                }
            }, { quoted: m });
        } else {
            m.reply("Gagal mendapatkan audio dari video tersebut.");
        }
    } catch (err) {
        console.error("Error play:", err);
        m.reply("Terjadi kesalahan saat memproses permintaan.");
    }
}
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "yts": {
if (!q) return example("lagu tiktok viral")
let data = await yts(q)
if (data.all.length < 1) return m.reply("Result tidak ditemukan!")
let anuan = data.all
let teks = ""
for (let res of anuan) {
teks += `\n* *Title :* ${res.title}
* *Durasi :* ${res.timestamp}
* *Upload :* ${res.ago}
* *Views :* ${await func.toRupiah(res.views) || "Unknown"}
* *Author :* ${res?.author?.name || "Unknown"}
* *Source :* ${res.url}\n`
}
await m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "xnxxs": case "xnxxsearch": {
if (!q) return example("step sister")
let data = await func.fetchJson(`https://api-simplebot.vercel.app/search/xnxx?apikey=${global.ApikeyRestApi}&q=${q}`)
if (data.result.length < 1) return m.reply("Result tidak ditemukan!")
let anuan = data.result
let teks = ""
for (let res of anuan) {
teks += `\n* *Title :* ${res.title}
* *Info :* ${res.info.trim()}
* *Link :* ${res.link}\n`
}
await m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "npm": case "npmsearch": {
if (!q) return example("axios")
let data = await func.fetchJson(`https://api-simplebot.vercel.app/search/npm?apikey=${global.ApikeyRestApi}&q=${q}`)
if (data.result.length < 1) return m.reply("Result tidak ditemukan!")
let anuan = data.result
let teks = ""
for (let res of anuan) {
teks += `\n* *${res.title}*
* *Update :* ${res.update.split("T").join(" ").split("Z")[0]}
* *Link :* ${res.links.npm}
* *Github :* ${res.links.repository}\n`
}
await m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "tiktoksearch": case "tiktoks": {
if (!q) return example("axios")
let data = await func.fetchJson(`https://api-simplebot.vercel.app/search/tiktok?apikey=${global.ApikeyRestApi}&q=${q}`)
if (data.result.length < 1) return m.reply("Result tidak ditemukan!")
let anuan = data.result
let teks = ""
for (let res of anuan) {
teks += `
* *Title :* ${res.title}
* *Views :* ${await func.toRupiah(res.play_count)}
* *Author :* ${res.author.nickname}
* *Upload :* ${func.tanggal(res.create_time)}
* *Vidio :* ${res.play}
* *Audio :* ${res.music_info.play}
`
}
await m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "xnxx": case "xnxxdl": {
if (!q) return example("linknya")
let data = await func.fetchJson(`https://api-simplebot.vercel.app/download/xnxx?apikey=${global.ApikeyRestApi}&url=${q}`)
if (!data.result) return m.reply("Result tidak ditemukan!")
await sock.sendMessage(m.chat, {video: {url: data.result.files.high || data.result.files.low}, caption: "XNXX Download Done ✅", mimetype: "video/mp4"}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ytmp3": {
if (!text) return example("linknya")
m.reply("📥 Memproses youtube downloader . .")
const anu = await func.fetchJson(`https://api-simplebot.vercel.app/download/ytmp3?apikey=${global.ApikeyRestApi}&url=`+text);
if (anu.result) {
let urlMp3 = anu.result.media
await sock.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg"}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "tiktok":
case "tt": {
    if (!text) return example("linknya");

    m.reply("📥 Sedang memproses video TikTok...");

    try {
        const anu = await func.fetchJson(`https://api-simplebot.vercel.app/download/tiktok?apikey=${global.ApikeyRestApi}&url=${encodeURIComponent(text)}`);

        if (!anu?.status || !anu?.result) {
            return m.reply("Gagal mengambil data TikTok. Pastikan link valid.");
        }

        const { video_nowm, audio_url, slides } = anu.result;

        if (slides && slides.length > 1) {
            for (const i of slides) {
                await sock.sendFileUrl(m.chat, i.url, "Tiktok Slide ✅", m);
            }
        } else if (video_nowm) {
            await sock.sendMessage(m.chat, {
                video: { url: video_nowm },
                caption: "Tiktok Video ✅",
                mimetype: "video/mp4"
            }, { quoted: m });
        }

        if (audio_url) {
            await sock.sendMessage(m.chat, {
                audio: { url: audio_url },
                mimetype: "audio/mpeg"
            }, { quoted: m });
        }

    } catch (err) {
        console.error("Error TikTok Downloader:", err);
        m.reply("Terjadi kesalahan saat mengunduh video TikTok.");
    }
}
break;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "gitclone": {
    if (!text) return example("https://github.com/Skyzodev/Simplebot");

    try {
        const res = await func.fetchJson(`https://api-simplebot.vercel.app/download/github?apikey=${global.ApikeyRestApi}&url=${encodeURIComponent(text)}`);

        if (!res?.status || !res?.result?.download) {
            return m.reply("Gagal mendapatkan data dari repositori. Pastikan URL valid.");
        }

        const { filename, download: url } = res.result;

        await sock.sendMessage(m.chat, {
            document: { url },
            mimetype: 'application/zip',
            fileName: filename
        }, { quoted: m });

    } catch (e) {
        console.error("GitClone Error:", e);
        m.reply("Terjadi kesalahan saat mengunduh repositori.");
    }
}
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "instagram":
case "ig": {
    if (!text) return example("linknya");

    m.reply("📥 Sedang memproses tautan Instagram...");

    try {
        const anu = await func.fetchJson(`https://api-simplebot.vercel.app/download/instagram?apikey=${global.ApikeyRestApi}&url=${encodeURIComponent(text)}`);

        if (!anu?.status || !anu?.result?.downloadUrls?.length) {
            return m.reply("Gagal mengambil media Instagram. Coba periksa link-nya.");
        }

        for (const url of anu.result.downloadUrls) {
            await sock.sendFileUrl(m.chat, url, "Instagram Download ✅", m);
        }
    } catch (err) {
        console.error("Instagram Downloader Error:", err);
        m.reply("Terjadi kesalahan saat mengunduh media dari Instagram.");
    }
}
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "facebook":
case "fb": {
    if (!text) return example("linknya");

    m.reply("📥 Memproses video Facebook...");

    try {
        const anu = await func.fetchJson(`https://api-simplebot.vercel.app/download/facebook?apikey=${global.ApikeyRestApi}&url=${encodeURIComponent(text)}`);

        if (!anu?.status || !anu?.result?.media) {
            return m.reply("Gagal mengambil video dari Facebook. Pastikan link valid.");
        }

        await sock.sendMessage(m.chat, {
            video: { url: anu.result.media },
            caption: "Facebook Download ✅"
        }, { quoted: m });

    } catch (err) {
        console.error("Facebook Downloader Error:", err);
        m.reply("Terjadi kesalahan saat mengunduh dari Facebook.");
    }
}
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "videy": {
    if (!text) return example("linknya");

    m.reply("📥 Sedang memproses video dari Videy...");

    try {
        const anu = await func.fetchJson(`https://api-simplebot.vercel.app/download/videy?apikey=${global.ApikeyRestApi}&url=${encodeURIComponent(text)}`);

        if (!anu?.status || !anu?.result) {
            return m.reply("Gagal mengambil video dari Videy.");
        }

        await sock.sendMessage(m.chat, {
            video: { url: anu.result },
            caption: "Videy Download ✅"
        }, { quoted: m });

    } catch (err) {
        console.error("Videy Downloader Error:", err);
        m.reply("Terjadi kesalahan saat mengunduh dari Videy.");
    }
}
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ytmp4": {
    if (!text) return example("linknya");

    m.reply("📥 Sedang memproses YouTube MP4...");

    try {
        const anu = await func.fetchJson(`https://api-simplebot.vercel.app/download/ytmp4?apikey=${global.ApikeyRestApi}&url=`+text);

        if (!anu?.result) {
            return m.reply("Gagal mendapatkan video dari YouTube.");
        }

        await sock.sendMessage(m.chat, {
            video: { url: anu.result.media },
            mimetype: "video/mp4"
        }, { quoted: m });

    } catch (err) {
        console.error("YTMP4 Error:", err);
        m.reply("Terjadi kesalahan saat mengunduh video YouTube.");
    }
}
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "tourl": {
    if (!/image|video|audio|application/.test(mime)) return example("dengan kirim/reply media");

    const FormData = require('form-data');
    const { fromBuffer } = require('file-type');
    const fs = require('fs');

    async function uploadToCatbox(buffer) {
        try {
            let { ext } = await fromBuffer(buffer);
            let form = new FormData();
            form.append("fileToUpload", buffer, "file." + ext);
            form.append("reqtype", "fileupload");

            let res = await fetch("https://catbox.moe/user/api.php", {
                method: "POST",
                body: form,
            });

            return await res.text();
        } catch (err) {
            console.error("Upload Error:", err);
            return null;
        }
    }

    try {
        let mediaPath = await sock.downloadAndSaveMediaMessage(qmsg);
        let buffer = fs.readFileSync(mediaPath);
        let url = await uploadToCatbox(buffer);

        if (!url || !url.startsWith("https://")) {
            throw new Error("Gagal mengunggah ke Catbox");
        }

        await sock.sendMessage(m.chat, { text: url }, { quoted: m });
        fs.unlinkSync(mediaPath); // bersihkan file lokal
    } catch (err) {
        console.error("Tourl Error:", err);
        m.reply("Terjadi kesalahan saat mengubah media menjadi URL.");
    }
}
break;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "tiktokstalk": case "ttstalk": {
if (!text) return example("username")
try {
const res = await func.fetchJson(`https://api-simplebot.vercel.app/stalk/tiktok?apikey=${global.ApikeyRestApi}&user=${text}`)
if (!res.status) return m.reply("Error nama pengguna tidak ditemukan")
const teks = `
* *Nama :* ${res.result.nickname}
* *Username :* ${res.result.uniqueId}
* *Bio :* ${res?.result?.signature || ""}
* *Followers :* ${res.result.followerCount}
* *Following :* ${res.result.followingCount}
* *Private :* ${res.result.privateAccount == true ? "Ya" : "Tidak"}
`
await sock.sendMessage(m.chat, {image: {url: res.result.avatarMedium}, caption: teks}, {quoted: m})
} catch (err) {
return m.reply("Error : "+err)
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "igstalk": {
if (!text) return example("username")
try {
let res = await func.fetchJson(`https://api-simplebot.vercel.app/stalk/instagram?apikey=${global.ApikeyRestApi}&user=${q}`)
const teks = `
* *Nama :* ${res.result.name}
* *Username :* ${res.result.username}
* *Bio :* ${res.result.bio}
* *Total Postingan :* ${res.result.posts}
* *Followers :* ${res.result.followers}
* *Following :* ${res.result.following}
`
await sock.sendMessage(m.chat, {image: {url: res.result.avatar}, caption: teks}, {quoted: m})
} catch (err) {
return m.reply("Error : "+err)
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ffstalk": {
if (!text) return example("id")
try {
let res = await func.fetchJson(`https://api-simplebot.vercel.app/stalk/ff?apikey=${global.ApikeyRestApi}&id=${q}`)
const teks = `
* *Nickname :* ${res.result.nickname}
* *Region :* ${res.result.region}
`
await sock.sendMessage(m.chat, {text: teks}, {quoted: m})
} catch (err) {
return m.reply("Error : "+err)
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "remini":
case "tohd":
case "hd": {
    if (!/image/.test(mime)) return example("dengan kirim/reply foto");

    m.reply(`🚀 Memproses *${command.toLowerCase()}*...`);
    const FormData = require('form-data');
    const { fromBuffer } = require('file-type');
    const fs = require('fs');

    async function uploadToCatbox(buffer) {
        try {
            let { ext } = await fromBuffer(buffer);
            let form = new FormData();
            form.append("fileToUpload", buffer, "file." + ext);
            form.append("reqtype", "fileupload");

            let res = await fetch("https://catbox.moe/user/api.php", {
                method: "POST",
                body: form,
            });

            return await res.text();
        } catch (err) {
            console.error("Upload Error:", err);
            return null;
        }
    }

    try {
        const mediaPath = await sock.downloadAndSaveMediaMessage(qmsg);
        const buffer = fs.readFileSync(mediaPath);
        const directLink = await uploadToCatbox(buffer);

        if (!directLink || !directLink.startsWith("https://")) {
            throw new Error("Gagal upload gambar ke server");
        }

        const response = await func.fetchJson(`https://api-simplebot.vercel.app/imagecreator/remini?apikey=${global.ApikeyRestApi}&url=${directLink}`);
        if (!response?.result) throw new Error("Gagal meningkatkan kualitas gambar.");

        await sock.sendMessage(m.chat, {
            image: { url: response.result },
            caption: "Berhasil meningkatkan kualitas foto ✅"
        }, { quoted: m });

        fs.unlinkSync(mediaPath);
    } catch (err) {
        console.error("Remini error:", err);
        m.reply("Terjadi kesalahan: " + err.message);
    }
}
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "crypto": case "infocrypto": {
if (text) {
const pair = text.toLowerCase()
const url = `https://indodax.com/api/summaries`;
    const response = await axios.get(url);
    const data = response.data.tickers[pair]
    if (!data) return m.reply("ID Coin tidak ditemukan!")
return m.reply(`
📈 Nama : *${data.name}*
🛒 Harga Buka : *Rp${Number(data.low).toLocaleString('id-ID')}*
🔒 Harga Tutup : *Rp${Number(data.high).toLocaleString('id-ID')}*
💰 Harga Saat Ini : *Rp${Number(data.last).toLocaleString('id-ID')}*
`)
}
try {
    const url = `https://indodax.com/api/summaries`;
    const response = await axios.get(url);
    const data = response.data.tickers;
    let teks = ""

    for (const [pair, info] of Object.entries(data)) {
      teks += `\n📈 Nama : *${info.name}* 
📎 ID : *${pair}*
💰 Harga : *Rp${Number(info.last).toLocaleString('id-ID')}*\n`
    }
    return m.reply(teks)

  } catch (error) {
    console.error('Gagal mengambil semua harga dari Indodax:', error.message);
  }
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "removebg":
case "rbg": {
    if (!/image/.test(mime)) return example("dengan kirim/reply foto");

    m.reply(`🖼️ Memproses penghapusan background...`);
    const FormData = require('form-data');
    const { fromBuffer } = require('file-type');
    const fs = require('fs');

    async function uploadToCatbox(buffer) {
        try {
            let { ext } = await fromBuffer(buffer);
            let form = new FormData();
            form.append("fileToUpload", buffer, "file." + ext);
            form.append("reqtype", "fileupload");

            let res = await fetch("https://catbox.moe/user/api.php", {
                method: "POST",
                body: form,
            });

            return await res.text();
        } catch (err) {
            console.error("Upload Error:", err);
            return null;
        }
    }

    try {
        const mediaPath = await sock.downloadAndSaveMediaMessage(qmsg);
        const buffer = fs.readFileSync(mediaPath);
        const directLink = await uploadToCatbox(buffer);

        if (!directLink || !directLink.startsWith("https://")) {
            throw new Error("Gagal upload gambar ke server");
        }

        const response = await func.fetchJson(`https://api-simplebot.vercel.app/imagecreator/removebg?apikey=${global.ApikeyRestApi}&url=${directLink}`);
        if (!response?.result) throw new Error("Gagal menghapus background.");

        await sock.sendMessage(m.chat, {
            image: { url: response.result },
            caption: "Background berhasil dihapus ✅"
        }, { quoted: m });

        fs.unlinkSync(mediaPath);
    } catch (err) {
        console.error("RemoveBG error:", err);
        m.reply("Terjadi kesalahan: " + err.message);
    }
}
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "qc": {
if (!text) return example('teksnya')
let warna = ["#000000", "#ff2414", "#22b4f2", "#eb13f2"]
let ppuser
try {
ppuser = await sock.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://files.catbox.moe/gqs7oz.jpg'
}
let reswarna = await warna[Math.floor(Math.random()*warna.length)]
const obj = {
      "type": "quote",
      "format": "png",
      "backgroundColor": reswarna,
      "width": 512,
      "height": 768,
      "scale": 2,
      "messages": [{
         "entities": [],
         "avatar": true,
         "from": {
            "id": 1,
            "name": m.pushName,
            "photo": {
               "url": ppuser
            }
         },
         "text": text,
         "replyMessage": {}
      }]
   }
   try {
   const json = await axios.post('https://bot.lyo.su/quote/generate', obj, {
      headers: {
         'Content-Type': 'application/json'
      }
   })
   const buffer = Buffer.from(json.data.result.image, 'base64')
sock.sendStimg(m.chat, buffer, m, { packname: global.packname })
   } catch (error) {
   m.reply(error.toString())
   }
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ai": case "openai": case "gpt": case "chatgpt": {
if (!text) return example("kamu siapa")
await func.fetchJson(`https://api-simplebot.vercel.app/ai/openai?apikey=${global.ApikeyRestApi}&text=${text}`).then((e) => {
if (!e.status) return m.reply(JSON.stringify(e, null, 2))
var teks = `${e.result}`
sock.sendMessage(m.chat, {text: teks, ai: true}, {quoted: m})
})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "closegc": case "close": 
case "opengc": case "open": {
if (!m.isGroup) return m.reply(msg.group)
if (!isOwner && !m.isAdmin) return m.reply(msg.admin)
if (!m.isBotAdmin) return m.reply(msg.botadmin)
if (/open|opengc/.test(command)) {
if (m.metadata.announce == false) return 
await sock.groupSettingUpdate(m.chat, 'not_announcement')
} else if (/closegc|close/.test(command)) {
if (m.metadata.announce == true) return 
await sock.groupSettingUpdate(m.chat, 'announcement')
} else {}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "kick": case "kik": {
if (!isOwner) return m.reply(msg.admin)
if (!m.isGroup) return m.reply(msg.group)
if (!m.isBotAdmin) return m.reply(msg.botadmin)
if (text || m.quoted) {
const input = m.mentionedJid ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await sock.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await sock.groupParticipantsUpdate(m.chat, [input], 'remove')
} else {
return example("@tag/reply")
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "demote":
case "promote": {
if (!isOwner) return m.reply(msg.admin)
if (!m.isGroup) return m.reply(msg.group)
if (!m.isBotAdmin) return m.reply(msg.botadmin)
if (m.quoted || text) {
var action
let target = m.mentionedJid ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await sock.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await sock.sendMessage(m.chat, {text: `Berhasil ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
})
} else {
return example("@tag/6285###")
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ht": case "hidetag": {
if (!m.isGroup) return m.reply(msg.group)
if (!isOwner && !m.isAdmin) return m.reply(msg.admin)
if (!text) return example("pesannya")
let member = m.metadata.participants.map(v => v.id)
await sock.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "sticker": case "stiker": case "sgif": case "s": {
if (!/image|video/.test(mime)) return example("dengan mengirim foto/vidio")
if (/video/.test(mime)) {
if ((qmsg).seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
}
var media = await sock.downloadAndSaveMediaMessage(qmsg)
await sock.sendStimg(m.chat, media, m, {packname: "Whatsapp Bot 2024"})
await fs.unlinkSync(media)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "stickerwm": case "swm": case "wm": {
if (!text) return example("namamu & mengirim foto/vidio")
if (!/image|video/.test(mime)) return example("namamu & mengirim foto/vidio")
if (/video/.test(mime)) {
if ((qmsg).seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
}
var media = await sock.downloadAndSaveMediaMessage(qmsg)
await sock.sendStimg(m.chat, media, m, {packname: text})
await fs.unlinkSync(media)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "brat": {
if (!text) return example("Hello World!")
await sock.sendStimg(m.chat, `https://api-simplebot.vercel.app/imagecreator/brat?apikey=${global.ApikeyRestApi}&text=${text}`, m, {packname: global.namaowner})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "bratvid": {
if (!text) return example("Hello World!")
await sock.sendStvid(m.chat, `https://api-simplebot.vercel.app/imagecreator/bratvideo?apikey=${global.ApikeyRestApi}&text=${text}`, m, {packname: global.namaowner})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "public": {
if (!isOwner) return m.reply(msg.owner)
sock.public = true
m.reply("Berhasil mengganti mode bot menjadi *Public*")
}
break

case "self": {
if (!isOwner) return m.reply(msg.owner)
sock.public = false
m.reply("Berhasil mengganti mode bot menjadi *Self*")
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "get": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return m.reply("linknya")
try {
const data = await axios.get(text, { responseType: 'arraybuffer' });
const mime = data.headers['content-type'] || (await FileType.fromBuffer(data.data)).mime
if (/gif|image|video|audio|pdf/i.test(mime)) {
return m.reply(text)
}
var check = await func.fetchJson(text)
return m.reply(JSON.stringify(check, null, 2))
} catch {
return m.reply(`${e}`)
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "antilink": case "antilinkgc": {
  if (!isOwner) return m.reply(msg.owner);
  if (!m.isGroup) return m.reply(msg.group);

  let room = antilink.find((i) => i.id == m.chat);

  if (!args[0] || !args[1]) return example(`on/off nokik/kik\n\n*Status Antilinkgc :* ${room ? `Aktif ✅ (${room.kick ? "kick" : "nokik"})` : "Tidak Aktif ❌"}`)

  let mode = args[0].toLowerCase();
  let state = args[1].toLowerCase();
  let isOn = /on/g.test(state);
  let isOff = /off/g.test(state);

  if (!["kick", "nokick", "kik", "nokik"].includes(mode)) return example(`on/off nokik/kik\n\n*Status Antilinkgc :* ${room ? `Aktif ✅ (${room.kick ? "kick" : "nokik"})` : "Tidak Aktif ❌"}`)

  if (!isOn && !isOff) return example(`on/off nokik/kik\n\n*Status Antilinkgc :* ${room ? `Aktif ✅ (${room.kick ? "kick" : "nokik"})` : "Tidak Aktif ❌"}`)

  let shouldKick = mode === "kick" || mode === "kik";

  if (isOn) {
    if (room && room.kick === shouldKick)
      return m.reply(
        `*Antilink grup ${shouldKick ? "kick" : "no kick"}* di grup ini sudah aktif!`
      );

    if (room) {
      let ind = antilink.indexOf(room);
      antilink.splice(ind, 1);
    }

    antilink.push({ id: m.chat, kick: shouldKick });
    fs.writeFileSync("./data/antilink.json", JSON.stringify(antilink, null, 2));
    return m.reply(
      `*Antilink grup ${shouldKick ? "kick" : "no kick"}* berhasil diaktifkan ✅`
    );
  } else if (isOff) {
    if (!room || room.kick !== shouldKick)
      return m.reply(
        `*Antilink grup ${shouldKick ? "kick" : "no kick"}* di grup ini sudah tidak aktif!`
      );

    let ind = antilink.indexOf(room);
    antilink.splice(ind, 1);
    fs.writeFileSync("./data/antilink.json", JSON.stringify(antilink, null, 2));
    return m.reply(
      `*Antilink grup ${shouldKick ? "kick" : "no kick"}* berhasil dimatikan ✅`
    );
  }
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "developerbot": case "owner": case "creator": {
await sock.sendContact(m.chat, [global.owner], m)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "backupsc":
case "bck":
case "backup": {
    if (m.sender.split("@")[0] !== global.owner && m.sender !== botNumber)
        return m.reply("Fitur ini hanya untuk owner pemilik bot!");

    try {
        // Bersihkan direktori sementara
        const tmpDir = "./server/tmp";
        if (fs.existsSync(tmpDir)) {
            const files = fs.readdirSync(tmpDir).filter(f => !f.endsWith(".txt"));
            for (let file of files) {
                fs.unlinkSync(`${tmpDir}/${file}`);
            }
        }

        await m.reply("Processing Backup Script . .");

        const tgl = func.getTime().split("T")[0];
        let jam = func.getTime().split("T")[1].split("+")[0].split(":").slice(0, 2).join(":");
        const name = `Backup-${tgl}#${jam.replace(":", ".")}`; // replace ":" to avoid filename issue

        const exclude = ["node_modules", "session", "package-lock.json", "yarn.lock", ".npm", ".cache"];
        const filesToZip = fs.readdirSync(".").filter(f => !exclude.includes(f) && f !== "");

        if (!filesToZip.length) return m.reply("Tidak ada file yang dapat di-backup.");

        execSync(`zip -r ${name}.zip ${filesToZip.join(" ")}`);

        await sock.sendMessage(m.sender, {
            document: fs.readFileSync(`./${name}.zip`),
            fileName: `${name}.zip`,
            mimetype: "application/zip"
        }, { quoted: m });

        fs.unlinkSync(`./${name}.zip`);

        if (m.chat !== m.sender) m.reply("Script bot berhasil dikirim ke private chat.");
    } catch (err) {
        console.error("Backup Error:", err);
        m.reply("Terjadi kesalahan saat melakukan backup.");
    }
}
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": 
case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": 
case "unlimited": case "unli": {
    if (!isOwner && !isGrupReseller) {
        return m.reply(`Fitur ini hanya untuk dalam grup *reseller panel*!\nJoin grup *reseller panel* langsung chat ${global.owner}`);
    }
    if (!text) return example("username,628XXX");

    let nomor, usernem;
    let tek = text.split(",");
    if (tek.length > 1) {
        let [users, nom] = tek.map(t => t.trim());
        if (!users || !nom) return example("username,628XXX");
        nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        usernem = users.toLowerCase();
    } else {
        usernem = text.toLowerCase();
        nomor = m.isGroup ? m.sender : m.chat
    }

    try {
        var onWa = await sock.onWhatsApp(nomor.split("@")[0]);
        if (onWa.length < 1) return m.reply("Nomor target tidak terdaftar di WhatsApp!");
    } catch (err) {
        return m.reply("Terjadi kesalahan saat mengecek nomor WhatsApp: " + err.message);
    }

    // Mapping RAM, Disk, dan CPU
    const resourceMap = {
        "1gb": { ram: "1000", disk: "1000", cpu: "40" },
        "2gb": { ram: "2000", disk: "1000", cpu: "60" },
        "3gb": { ram: "3000", disk: "2000", cpu: "80" },
        "4gb": { ram: "4000", disk: "2000", cpu: "100" },
        "5gb": { ram: "5000", disk: "3000", cpu: "120" },
        "6gb": { ram: "6000", disk: "3000", cpu: "140" },
        "7gb": { ram: "7000", disk: "4000", cpu: "160" },
        "8gb": { ram: "8000", disk: "4000", cpu: "180" },
        "9gb": { ram: "9000", disk: "5000", cpu: "200" },
        "10gb": { ram: "10000", disk: "5000", cpu: "220" },
        "unlimited": { ram: "0", disk: "0", cpu: "0" }
    };
    
    let { ram, disk, cpu } = resourceMap[command] || { ram: "0", disk: "0", cpu: "0" };

    let username = usernem.toLowerCase();
    let email = username + "@gmail.com";
    let name = func.capital(username) + " Server";
    let password = username + "001";

    try {
        let f = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey },
            body: JSON.stringify({ email, username, first_name: name, last_name: "Server", language: "en", password })
        });
        let data = await f.json();
        if (data.errors) return m.reply("Error: " + JSON.stringify(data.errors[0], null, 2));
        let user = data.attributes;

        let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
            method: "GET",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey }
        });
        let data2 = await f1.json();
        let startup_cmd = data2.attributes.startup;

        let f2 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey },
            body: JSON.stringify({
                name,
                description: func.tanggal(Date.now()),
                user: user.id,
                egg: parseInt(egg),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
                startup: startup_cmd,
                environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
                limits: { memory: ram, swap: 0, disk, io: 500, cpu },
                feature_limits: { databases: 5, backups: 5, allocations: 5 },
                deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] },
            })
        });
        let result = await f2.json();
        if (result.errors) return m.reply("Error: " + JSON.stringify(result.errors[0], null, 2));
        
        let server = result.attributes;
        var orang = nomor
        if (orang !== m.chat) {
        await m.reply(`Berhasil membuat akun panel ✅\ndata akun sudah di kirim ke ${nomor.split("@")[0]}`)
        }
        
        let teks = `
*Berikut Detail Akun Panel Kamu 📦*

*📡 ID Server (${server.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password}
*🗓️ ${func.tanggal(Date.now())}*

*🌐 Spesifikasi Server*
* Ram : *${ram == "0" ? "Unlimited" : ram / 1000 + "GB"}*
* Disk : *${disk == "0" ? "Unlimited" : disk / 1000 + "GB"}*
* CPU : *${cpu == "0" ? "Unlimited" : cpu + "%"}*
* ${global.domain}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`;

        await sock.sendMessage(orang, { text: teks }, { quoted: m });
    } catch (err) {
        return m.reply("Terjadi kesalahan: " + err.message);
    }
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listpanel": case "listp": case "listserver": {
if (!isOwner && !isGrupReseller) return m.reply(`Fitur ini hanya untuk dalam grup *reseller panel*!\nJoin grup *reseller panel* langsung chat ${global.owner}`)
let f = await fetch(domain + "/api/application/servers", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak ada server panel!")
let messageText = ""
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n 📡 *${s.id} [ ${s.name} ]*
 *• Ram :* ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}
 *• CPU :* ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}
 *• Disk :* ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}
 *• Created :* ${s.created_at.split("T")[0]}\n`
}
await sock.sendMessage(m.chat, {text: messageText}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "delpanel": {
if (!isOwner && !isGrupReseller) return m.reply(`Fitur ini hanya untuk dalam grup *reseller panel*!\nJoin grup *reseller panel* langsung chat ${global.owner}`)
if (!text) return example("idnya")
let f = await fetch(domain + "/api/application/servers", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Gagal menghapus server!\nID server tidak ditemukan")
await m.reply(`Sukses menghapus server panel *${func.capital(nameSrv)}*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "cadmin": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("username,628XXX")
let nomor
let usernem
let tek = text.split(",")
if (tek.length > 1) {
let [users, nom] = text.split(",")
if (!users || !nom) return example("username,628XXX")
nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
usernem = users.toLowerCase()
} else {
usernem = text.toLowerCase()
nomor = m.isGroup ? m.sender : m.chat
}
var onWa = await sock.onWhatsApp(nomor.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor target tidak terdaftar di whatsapp!")
let username = usernem.toLowerCase()
let email = username+"@gmail.com"
let name = func.capital(args[0])
let password = username+"001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang = nomor
if (nomor !== m.chat) {
await m.reply(`Berhasil membuat akun admin panel ✅\ndata akun sudah di kirim ke ${nomor.split("@")[0]}`)
}
var teks = `
*Berikut Detail Akun Admin Panel 📦*

*📡 ID User (${user.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password.toString()}
*🗓️ ${func.tanggal(Date.now())}*

*🌐* ${global.domain}

*Syarat & Ketentuan :*
* Expired akun 1 bulan
* Simpan data ini sebaik mungkin
* Jangan asal hapus server!
* Ketahuan maling sc, auto delete akun no reff!
`
await sock.sendMessage(orang, {text: teks}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "cvps": 
case "createvps": {
    if (!isOwner) return m.reply(msg.owner)
    if (global.apidigitalocean.length < 1) return m.reply("Apikey Digital Ocean belum di isi!")
    if (!text) return sock.sendMessage(m.chat, {
        buttons: [
            {
                buttonId: 'action',
                buttonText: { displayText: 'ini pesan interactiveMeta' },
                type: 4,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: 'Pilih Vps',
                        sections: [
                            {
                                rows: [
                                    {
                                        header: "RAM 1GB & 1 CPU ✅",
                                        title: "Sgp Ubuntu 20.04",
                                        id: ".cvps vps1g1c ubuntu 20-04 sgp1"
                                    },
                                    {
                                        header: "RAM 2GB & 1 CPU ✅",
                                        title: "Sgp Ubuntu 20.04",
                                        id: ".cvps vps2g1c ubuntu 20-04 sgp1"
                                    },
                                    {
                                        header: "RAM 2GB & 2 CPU ✅",
                                        title: "Sgp Ubuntu 20.04",
                                        id: ".cvps vps2g2c ubuntu 20-04 sgp1"
                                    },
                                    {
                                        header: "RAM 4GB & 2 CPU ✅",
                                        title: "Sgp Ubuntu 20.04",
                                        id: ".cvps vps4g2c ubuntu 20-04 sgp1"
                                    },
                                    {
                                        header: "RAM 8GB & 4 CPU ✅",
                                        title: "Sgp Ubuntu 20.04",
                                        id: ".cvps vps8g4c ubuntu 20-04 sgp1"
                                    },
                                    {
                                        header: "RAM 16GB & 4 CPU",
                                        title: "Sgp Ubuntu 20.04",
                                        id: `.cvps vps16g4c ubuntu 20-04 sgp1`
                                    }
                                ]
                            },
                        ]
                    })
                }
            }
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n Pilih Spesifikasi Vps.\n"
    }, {quoted: m})

    let Obj = {}
    Obj.hostname = `skyzopedia${func.generateRandomNumber(1, 10)}` // Nama host
    Obj.sizeOption = args[0]; // Ukuran VPS
    Obj.osOption = args[1] || "ubuntu"; // Default: Ubuntu
    Obj.osVersionOption = args[2] || "20-04"; // Default: Ubuntu 20.04
    Obj.regionOption = args[3] || "sgp1"; // Default: Singapore
    const passwd = crypto.randomBytes(10).toString("base64").replace(/[^a-zA-Z0-9]/g, "").slice(0, 10);
    Obj.password = passwd

    const osMap = {
        ubuntu: { '20-04': 'ubuntu-20-04-x64', '22-04': 'ubuntu-22-04-x64' },
        debian: { '10': 'debian-10-x64', '11': 'debian-11-x64' },
        centos: { '8': 'centos-8-x64', '7': 'centos-7-x64' },
        fedora: { '34': 'fedora-34-x64', '35': 'fedora-35-x64' },
    };

    if (!osMap[Obj.osOption]) {
        return m.reply(`*OS tidak valid!*\nOS yang tersedia: ubuntu, debian, centos, fedora.`);
    }
    if (!osMap[Obj.osOption][Obj.osVersionOption]) {
        return m.reply(
            `*Versi OS tidak valid!*\nVersi yang tersedia untuk ${Obj.osOption}: ${Object.keys(osMap[Obj.osOption]).join(', ')}`
        );
    }

    // Peta Ukuran
    const sizeMap = {
        vps1g1c: 's-1vcpu-1gb',
        vps2g1c: 's-1vcpu-2gb',
        vps2g2c: 's-2vcpu-2gb',
        vps4g2c: 's-2vcpu-4gb',
        vps8g4c: 's-4vcpu-8gb',
        vps16g4c: 's-4vcpu-16gb-amd',
    };

    if (!sizeMap[Obj.sizeOption]) {
        return m.reply(`*Ukuran VPS tidak valid!*\nUkuran yang tersedia: ${Object.keys(sizeMap).join(', ')}`);
    }

    // Peta Region
    const regionMap = {
        sgp1: 'Singapore (SGP1)',
        nyc3: 'New York (NYC3)',
        ams3: 'Amsterdam (AMS3)',
        lon1: 'London (LON1)',
        fra1: 'Frankfurt (FRA1)',
        sfo1: 'San Francisco (SFO1)',
        blr1: 'Bangalore (BLR1)',
        tor1: 'Toronto (TOR1)',
    };

    if (!regionMap[Obj.regionOption]) {
        return m.reply(`*Region tidak valid!*\nRegion yang tersedia: ${Object.keys(regionMap).join(', ')}`);
    }

    try {
        // Data untuk membuat droplet
        let dropletData = {
            name: Obj.hostname.toLowerCase(),
            region: Obj.regionOption,
            size: sizeMap[Obj.sizeOption],
            image: osMap[Obj.osOption][Obj.osVersionOption],
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: `#cloud-config\npassword: ${Obj.password}\nchpasswd: { expire: False }`,
            private_networking: null,
            volumes: null,
            tags: ['T'],
        };

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + global.apidigitalocean,
            },
            body: JSON.stringify(dropletData),
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletConfig = responseData.droplet;
            let dropletId = dropletConfig.id;
            await m.reply(`Memproses pembuatan vps`)
            await new Promise(resolve => setTimeout(resolve, 15000));

            // Mengambil informasi VPS
            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: 'Bearer ' + global.apidigitalocean,
                },
            })

            let dropletDetails = await dropletResponse.json();
            let ipVPS =
                dropletDetails.droplet.networks.v4 && dropletDetails.droplet.networks.v4.length > 0
                    ? dropletDetails.droplet.networks.v4[0].ip_address
                    : 'Tidak ada alamat IP yang tersedia';

            let messageText = `
*Berhasil membuat Vps ✅*
            
* *ID :* ${dropletId}
* *IP Vps :* ${ipVPS}
* *Username :* root
* *Password :* ${Obj.password}
`
            return m.reply(messageText)
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`);
        }
    } catch (err) {
        return m.reply(`Gagal membuat VPS: ${err.message}`);
    }
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listadmin": {
if (!isOwner) return m.reply(msg.owner)
let cek = await fetch(domain + "/api/application/users", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = ""
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n 📡 *${i.attributes.id} [ ${i.attributes.first_name} ]*
 *• Nama :* ${i.attributes.first_name}
 *• Created :* ${i.attributes.created_at.split("T")[0]}\n`
})
await sock.sendMessage(m.chat, {text: teks}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "deladmin": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("idnya")
let cek = await fetch(domain + "/api/application/users", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Gagal menghapus akun!\nID user tidak ditemukan")
await m.reply(`Sukses menghapus akun admin panel *${func.capital(getid)}*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "clearserver": {
if (!isOwner) return m.reply(msg.owner)
await m.reply(`Memproses penghapusan semua user & server panel yang bukan admin`)
try {
const PTERO_URL = global.domain
// Ganti dengan URL panel Pterodactyl
const API_KEY = global.apikey// API Key dengan akses admin

// Konfigurasi headers
const headers = {
  "Authorization": "Bearer " + API_KEY,
  "Content-Type": "application/json",
  "Accept": "application/json",
};

// Fungsi untuk mendapatkan semua user
async function getUsers() {
  try {
    const res = await axios.get(`${PTERO_URL}/api/application/users`, { headers });
    return res.data.data;
  } catch (error) {
    m.reply(JSON.stringify(error.response?.data || error.message, null, 2))
    
    return [];
  }
}

// Fungsi untuk mendapatkan semua server
async function getServers() {
  try {
    const res = await axios.get(`${PTERO_URL}/api/application/servers`, { headers });
    return res.data.data;
  } catch (error) {
    m.reply(JSON.stringify(error.response?.data || error.message, null, 2))
    return [];
  }
}

// Fungsi untuk menghapus server berdasarkan UUID
async function deleteServer(serverUUID) {
  try {
    await axios.delete(`${PTERO_URL}/api/application/servers/${serverUUID}`, { headers });
    console.log(`Server ${serverUUID} berhasil dihapus.`);
  } catch (error) {
    console.error(`Gagal menghapus server ${serverUUID}:`, error.response?.data || error.message);
  }
}

// Fungsi untuk menghapus user berdasarkan ID
async function deleteUser(userID) {
  try {
    await axios.delete(`${PTERO_URL}/api/application/users/${userID}`, { headers });
    console.log(`User ${userID} berhasil dihapus.`);
  } catch (error) {
    console.error(`Gagal menghapus user ${userID}:`, error.response?.data || error.message);
  }
}

// Fungsi utama untuk menghapus semua user & server yang bukan admin
async function deleteNonAdminUsersAndServers() {
  const users = await getUsers();
  const servers = await getServers();
  let totalSrv = 0

  for (const user of users) {
    if (user.attributes.root_admin) {
      console.log(`Lewati admin: ${user.attributes.username}`);
      continue; // Lewati admin
    }

    const userID = user.attributes.id;
    const userEmail = user.attributes.email;

    console.log(`Menghapus user: ${user.attributes.username} (${userEmail})`);

    // Cari server yang dimiliki user ini
    const userServers = servers.filter(srv => srv.attributes.user === userID);

    // Hapus semua server user ini
    for (const server of userServers) {
      await deleteServer(server.attributes.id);
      totalSrv += 1
    }

    // Hapus user setelah semua servernya terhapus
    await deleteUser(userID);
  }
await m.reply(`Berhasil menghapus ${totalSrv} user & server panel yang bukan admin.`)
}

// Jalankan fungsi
return deleteNonAdminUsersAndServers();
} catch (err) {
return m.reply(`${JSON.stringify(err, null, 2)}`)
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ambilq": case "q": {
if (!m.quoted) return
let jsonData = JSON.stringify(m.quoted, null, 2)
m.reply(jsonData)
} 
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addrespon": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("cmd|responnya")
if (!text.split("|")) return example("cmd|responnya")
let result = text.split("|")
if (result.length < 2) return example("cmd|responnya")
const [ cmd, respon ] = result
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (res) return m.reply("Cmd respon sudah ada")
let obj = {
cmd: cmd.toLowerCase(), 
respon: respon
}
list.push(obj)
fs.writeFileSync("./data/list.json", JSON.stringify(list, null, 2))
m.reply(`Berhasil menambah cmd respon *${cmd.toLowerCase()}* kedalam database respon`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delrespon": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return ("cmd\n\n ketik *.listrespon* untuk melihat semua cmd")
const cmd = text.toLowerCase()
if (cmd == "all") {
list.splice(0, list.length)
await fs.writeFileSync("./data/list.json", JSON.stringify(list, null, 2))
return m.reply("Berhasil menghapus semua respon ✅")
}
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (!res) return m.reply("Cmd respon tidak ditemukan\nketik *.listrespon* untuk melihat semua cmd respon")
let position = list.indexOf(res)
await list.splice(position, 1)
fs.writeFileSync("./data/list.json", JSON.stringify(list, null, 2))
m.reply(`Berhasil menghapus cmd respon *${cmd.toLowerCase()}* dari database respon`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listrespon": {
if (!isOwner) return m.reply(msg.owner)
if (list.length < 1) return m.reply("Tidak ada cmd respon")
let teks = ""
await list.forEach(e => teks += `\n* *Cmd :* ${e.cmd}\n`)
m.reply(`${teks}`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "batalbeli": {
if (m.isGroup) return
if (!sock[m.sender]) return 
await sock.sendMessage(m.chat, {text: "Berhasil membatalkan pembelian ✅"}, {quoted: sock[m.sender].msg})
await sock.sendMessage(m.chat, { delete: sock[m.sender].msg.key })
await clearTimeout(sock[m.sender].exp)
delete sock[m.sender];
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "tfdana": {
    if (!isOwner) return m.reply(msg.owner);
    if (!text) return example("0838XXX");

    const nomorTujuan = text.replace(/[^0-9]/g, "").trim();

    if (!text.includes("|")) {
        try {
            const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
            const produkDana = data.filter(item => /DANA/g.test(item.produk) && item.harga > 0);

            if (!produkDana.length) return m.reply("Produk DANA tidak tersedia.");

            const daftarPilihan = produkDana.map(item => ({
                title: item.keterangan,            
                id: `.tfdana ${nomorTujuan}|${item.kode}|${item.keterangan}`
            }));

            return sock.sendMessage(m.chat, {
                buttons: [{
                    buttonId: "action",
                    buttonText: { displayText: "Pilih Jumlah" },
                    type: 4,
                    nativeFlowInfo: {
                        name: "single_select",
                        paramsJson: JSON.stringify({
                            title: "Pilih Jumlah",
                            sections: [{ rows: daftarPilihan }]
                        })
                    }
                }],
                headerType: 1,
                viewOnce: true,
                text: "\n *Pilih Jumlah Transfer*\n",
                contextInfo: {
                    isForwarded: true,
                    mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
                }
            }, { quoted: m });

        } catch (error) {
            console.error(error);
            return m.reply("Gagal mengambil daftar harga DANA.");
        }
    }

    try {
        const [noTujuan, kodeProduk, nominalTransfer] = text.split("|").map(a => a.trim());
        if (!noTujuan || !kodeProduk || !nominalTransfer) return m.reply("Format salah! Contoh: 0838xxx|KODE|Nominal");

        const idTransaksi = "sock" + Date.now();

        // Kirim request transaksi
        await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${kodeProduk}&dest=${noTujuan}&refID=${idTransaksi}&pin=${global.pinH2H}&password=${global.passwordH2H}`);
        
        await func.sleep(2000); // Tunggu 5 detik

        // Cek status transaksi
        const hasilTransaksi = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${kodeProduk}&dest=${noTujuan}&refID=${idTransaksi}&pin=${global.pinH2H}&password=${global.passwordH2H}`);

        if (/status Sukses/i.test(JSON.stringify(hasilTransaksi))) {
            await sock.sendMessage(m.chat, {
                text: `
*Sukses Mengirim Saldo ✅*

*• Nomor Tujuan :* ${noTujuan}
*• Nominal :* ${nominalTransfer}
                `.trim(),
                contextInfo: { isForwarded: true }
            }, { quoted: m });
        } else {
            await sock.sendMessage(m.chat, {
                text: `Gagal:\n${JSON.stringify(hasilTransaksi)}`,
                contextInfo: { isForwarded: true }
            }, { quoted: m });
        }

    } catch (error) {
        console.error(error);
        return m.reply("Terjadi kesalahan saat memproses transaksi.");
    }
}
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //


case "buysaldo": {
  if (m.isGroup) return m.reply("Pembelian Saldo hanya bisa di dalam private chat.");
  
  // Check if there's an ongoing transaction
  if (sock[m.sender]) {
    return m.reply(`Masih ada transaksi yang belum diselesaikan.\n\nketik *.batalbeli* untuk membatalkan transaksi sebelumnya`);
  }
  
  // Validate input
  if (!text || !args[0]) return example("nomor/id");

  // Process without a specific Ewallet selected
  if (!text.includes("|")) {
    let nodana = text.trim();
    try {
      const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
      let dana = data.filter(item => /DOMPET DIGITAL/i.test(item.kategori) && item.harga > 0);
      let sections = dana.map(item => ({
        title: `${item.keterangan}`,
        header: `${item.produk} ✅`,
        description: `Rp${item.harga}`,
        id: `.buysaldo ${nodana}|${item.kode}|${item.harga}|${item.keterangan}`
      }));

      return sock.sendMessage(m.chat, {
        buttons: [{
          buttonId: "action",
          buttonText: { displayText: "Pilih Ewallet" },
          type: 4,
          nativeFlowInfo: {
            name: "single_select",
            paramsJson: JSON.stringify({
              title: "Pilih Jumlah & Ewallet 🛍️",
              sections: [{ rows: sections }]
            })
          }
        }],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Jumlah & Ewallet 🛍️*\n",
        contextInfo: {
          isForwarded: true,
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        }
      }, { quoted: null });
    } catch (err) {
      return m.reply("Terjadi kesalahan saat memuat data harga.");
    }
  }

  // Process the transaction when specific Ewallet is selected
  let Obj = {};
  Obj.harga = text.split("|")[2];
  Obj.nominal = text.split("|")[3];
  Obj.kode = text.split("|")[1];
  Obj.nodana = text.split("|")[0];

  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(`https://api-simplebot.vercel.app/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);
    const paymentInfo = get.data.result;

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${paymentInfo.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(paymentInfo.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• Nomor Tujuan :* ${Obj.nodana}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`;

    let msgQr = await sock.sendMessage(m.chat, {
      buttons: [{
        buttonId: `.batalbeli`,
        buttonText: { displayText: 'Batalkan Pembelian' },
        type: 1
      }],
      headerType: 1,
      viewOnce: true,
      image: { url: paymentInfo.imageqris.url },
      caption: teks3,
      contextInfo: { mentionedJid: [m.sender], isForwarded: true }
    }, { quoted: m });

    // Store the transaction in memory
    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: paymentInfo.idtransaksi,
      amount: paymentInfo.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
          delete sock[m.sender];
        }
      }, 250000) // 5 minutes timeout
    };

    // Monitor payment status
    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);

      const resultcek = await axios.get(`https://api-simplebot.vercel.app/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* ${Obj.nominal}
`,
        }, { quoted: sock[m.sender].msg });

        const idtrx = "sock" + `${Date.now()}`;
        await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`);
        await func.sleep(5000);

        let dt = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`);
        if (/status Sukses/.test(dt)) {
          await sock.sendMessage(sock[m.sender].chat, {
            text: `
*Transaksi Telah Berhasil ✅*

 *• Nomor Tujuan :* ${Obj.nodana}
 *• Barang :* ${Obj.nominal}
 *• Status :* Sukses
          `, contextInfo: { isForwarded: true }
          }, { quoted: null });
        } else {
          await sock.sendMessage(sock[m.sender].chat, { text: dt, contextInfo: { isForwarded: true } }, { quoted: null });
        }

        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
    m.reply("Terjadi kesalahan saat memproses pembayaran.");
  }
}
break;

case "topupml": {
  if (m.isGroup) {
    return m.reply("Pembelian Diamond Mobile Legends hanya bisa di dalam private chat.");
  }

  // Check for ongoing transactions
  if (sock[m.sender]) {
    return m.reply(`Masih ada transaksi yang belum diselesaikan.\n\nketik *.batalbeli* untuk membatalkan transaksi sebelumnya`);
  }

  // Validate input (game ID and server ID)
  if (!text || !text.includes("|")) return example("id dan sambungkan dengan serverid");

  const idgame = text.split("|");

  // Check if the first part is a valid game ID
  if (isNaN(idgame[0])) return example("id dan sambungkan dengan serverid");

  // If no specific top-up option is selected, offer available options
  if (!args[0] || !args[0].includes("|")) {
    let nodana = idgame[0].replace(/[^0-9]/g, "").trim();
    try {
      const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
      let dana = data.filter(item => /TPG Diamond Mobile Legends/i.test(item.produk) && item.harga > 0);
      
      let sections = dana.map((item) => ({
        title: `${item.keterangan}`,
        header: `${item.produk} ✅`,
        description: `Rp${item.harga}`,
        id: `.topupml ${nodana}|${item.kode}|${item.harga}|${item.keterangan}`
      }));

      return sock.sendMessage(m.chat, {
        buttons: [{
          buttonId: "action",
          buttonText: { displayText: "Pilih Diamond" },
          type: 4,
          nativeFlowInfo: {
            name: "single_select",
            paramsJson: JSON.stringify({
              title: "Pilih Diamond",
              sections: [{ rows: sections }]
            })
          }
        }],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Jumlah Diamond 🛍️*\n",
        contextInfo: {
          isForwarded: true,
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        }
      }, { quoted: null });

    } catch (err) {
      return m.reply("Terjadi kesalahan saat memuat data harga.");
    }
  }

  // Extract top-up details from the input
  let Obj = {
    harga: text.split("|")[2],
    nominal: text.split("|")[3],
    kode: text.split("|")[1],
    nodana: text.split("|")[0]
  };

  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    // Generate payment request
    const get = await axios.get(
      `https://api-simplebot.vercel.app/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const paymentInfo = get.data.result;
    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${paymentInfo.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(paymentInfo.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• ID Game :* ${Obj.nodana}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`;

    // Send the QR code message
    let msgQr = await sock.sendMessage(m.chat, {
      buttons: [{
        buttonId: `.batalbeli`,
        buttonText: { displayText: 'Batalkan Pembelian' },
        type: 1
      }],
      headerType: 1,
      viewOnce: true,
      image: { url: paymentInfo.imageqris.url },
      caption: teks3,
      contextInfo: { mentionedJid: [m.sender], isForwarded: true }
    }, { quoted: m });

    // Store the transaction details in memory
    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: paymentInfo.idtransaksi,
      amount: paymentInfo.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
          delete sock[m.sender];
        }
      }, 250000) // 5 minutes timeout
    };

    // Polling payment status
    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);

      const resultcek = await axios.get(`https://api-simplebot.vercel.app/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* ${Obj.nominal}
`,
        }, { quoted: sock[m.sender].msg });

        const idtrx = "sock" + `${Date.now()}`;
        await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`);
        await func.sleep(5000);

        let dt = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`);
        if (/status Sukses/.test(dt)) {
          await sock.sendMessage(sock[m.sender].chat, {
            text: `
*Transaksi Telah Berhasil ✅*

 *• ID Game :* ${Obj.nodana}
 *• Barang :* ${Obj.nominal}
 *• Status :* Sukses
          `, contextInfo: { isForwarded: true }
          }, { quoted: null });
        } else {
          await sock.sendMessage(sock[m.sender].chat, { text: dt, contextInfo: { isForwarded: true } }, { quoted: null });
        }

        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
        delete sock[m.sender];
      }
    }

  } catch (err) {
    console.error("Terjadi kesalahan:", err);
    m.reply("Terjadi kesalahan saat memproses pembayaran.");
  }
}
break;

case "topupff": {
  if (m.isGroup) {
    return m.reply("Pembelian Diamond Free Fire hanya bisa di dalam private chat.");
  }

  // Check if there is an ongoing transaction
  if (sock[m.sender]) {
    return m.reply(`Masih ada transaksi yang belum diselesaikan.\n\nketik *.batalbeli* untuk membatalkan transaksi sebelumnya`);
  }

  // Validate input (game ID)
  if (!text) return example("idnya");
  
  let idgame = text.split("|");

  // Check if the first part is a valid game ID
  if (isNaN(idgame[0])) return example("id dan sambungkan dengan serverid");

  // If no specific top-up option is selected, offer available options
  if (!args[0] || !args[0].includes("|")) {
    let nodana = idgame[0].replace(/[^0-9]/g, "").trim();
    
    try {
      const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
      let dana = data.filter(item => /TPG Diamond Free Fire/i.test(item.produk) && item.harga > 0);

      let sections = dana.map((item) => ({
        title: `${item.keterangan}`,
        header: `${item.produk} ✅`,
        description: `Rp${item.harga}`,
        id: `.topupff ${nodana}|${item.kode}|${item.harga}|${item.keterangan}`
      }));

      return sock.sendMessage(m.chat, {
        buttons: [{
          buttonId: "action",
          buttonText: { displayText: "Pilih Diamond" },
          type: 4,
          nativeFlowInfo: {
            name: "single_select",
            paramsJson: JSON.stringify({
              title: "Pilih Diamond",
              sections: [{ rows: sections }]
            })
          }
        }],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Jumlah Diamond 🛍️*\n",
        contextInfo: {
          isForwarded: true,
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        }
      }, { quoted: null });

    } catch (err) {
      return m.reply("Terjadi kesalahan saat memuat data harga.");
    }
  }

  // Extract top-up details from the input
  let Obj = {
    harga: text.split("|")[2],
    nominal: text.split("|")[3],
    kode: text.split("|")[1],
    nodana: text.split("|")[0]
  };

  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    // Generate payment request
    const get = await axios.get(
      `https://api-simplebot.vercel.app/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const paymentInfo = get.data.result;
    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${paymentInfo.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(paymentInfo.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• ID Game :* ${Obj.nodana}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`;

    // Send the QR code message
    let msgQr = await sock.sendMessage(m.chat, {
      buttons: [{
        buttonId: `.batalbeli`,
        buttonText: { displayText: 'Batalkan Pembelian' },
        type: 1
      }],
      headerType: 1,
      viewOnce: true,
      image: { url: paymentInfo.imageqris.url },
      caption: teks3,
      contextInfo: { mentionedJid: [m.sender], isForwarded: true }
    }, { quoted: m });

    // Store the transaction details in memory
    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: paymentInfo.idtransaksi,
      amount: paymentInfo.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
          delete sock[m.sender];
        }
      }, 250000) // 5 minutes timeout
    };

    // Polling payment status
    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);

      const resultcek = await axios.get(`https://api-simplebot.vercel.app/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* ${Obj.nominal}
`,
        }, { quoted: sock[m.sender].msg });

        const idtrx = "sock" + `${Date.now()}`;
        await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`);
        await func.sleep(5000)

        let dt = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`);
        if (/status Sukses/.test(dt)) {
          await sock.sendMessage(sock[m.sender].chat, {
            text: `
*Transaksi Telah Berhasil ✅*

 *• ID Game :* ${Obj.nodana}
 *• Barang :* ${Obj.nominal}
 *• Status :* Sukses
          `, contextInfo: { isForwarded: true }
          }, { quoted: null })
        } else {
          await sock.sendMessage(sock[m.sender].chat, { text: dt, contextInfo: { isForwarded: true } }, { quoted: null });
        }

        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
        delete sock[m.sender];
      }
    }

  } catch (err) {
    console.error("Terjadi kesalahan:", err);
    m.reply("Terjadi kesalahan saat memproses pembayaran.");
  }
}
break;

case "topuppubg":
case "topuppapji": {
  if (m.isGroup) {
    return m.reply("Pembelian UC Mobile PUBG hanya bisa di dalam private chat.");
  }

  // Check if there is an ongoing transaction
  if (sock[m.sender]) {
    return m.reply(`Masih ada transaksi yang belum diselesaikan.\n\nKetik *.batalbeli* untuk membatalkan transaksi sebelumnya.`);
  }

  // Validate input
  if (!text) return example("idnya");
  let idgame = text.split("|");

  // Check if the first part is a valid game ID
  if (isNaN(idgame[0])) return example("id dan sambungkan dengan serverid");

  // If no specific top-up option is selected, offer available options
  if (!args[0] || !args[0].includes("|")) {
    let nodana = idgame[0].replace(/[^0-9]/g, "").trim();
    
    try {
      const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
      let dana = data.filter(item => /TPG Game Mobile PUBG/i.test(item.produk) && item.harga > 0);

      let sections = dana.map((item) => ({
        title: `${item.keterangan}`,
        header: `${item.produk} ✅`,
        description: `Rp${item.harga}`,
        id: `.topuppubg ${nodana}|${item.kode}|${item.harga}|${item.keterangan}`
      }));

      return sock.sendMessage(m.chat, {
        buttons: [{
          buttonId: "action",
          buttonText: { displayText: "Pilih UC" },
          type: 4,
          nativeFlowInfo: {
            name: "single_select",
            paramsJson: JSON.stringify({
              title: "Pilih UC",
              sections: [{ rows: sections }]
            })
          }
        }],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Jumlah UC 🛍️*\n",
        contextInfo: {
          isForwarded: true,
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        }
      }, { quoted: null });

    } catch (err) {
      return m.reply("Terjadi kesalahan saat memuat data harga.");
    }
  }

  // Extract top-up details from the input
  let Obj = {
    harga: text.split("|")[2],
    nominal: text.split("|")[3],
    kode: text.split("|")[1],
    nodana: text.split("|")[0]
  };

  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    // Generate payment request
    const get = await axios.get(
      `https://api-simplebot.vercel.app/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const paymentInfo = get.data.result;
    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${paymentInfo.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(paymentInfo.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• ID Game :* ${Obj.nodana}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`;

    // Send the QR code message
    let msgQr = await sock.sendMessage(m.chat, {
      buttons: [{
        buttonId: `.batalbeli`,
        buttonText: { displayText: 'Batalkan Pembelian' },
        type: 1
      }],
      headerType: 1,
      viewOnce: true,
      image: { url: paymentInfo.imageqris.url },
      caption: teks3,
      contextInfo: { mentionedJid: [m.sender], isForwarded: true }
    }, { quoted: m });

    // Store the transaction details in memory
    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: paymentInfo.idtransaksi,
      amount: paymentInfo.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
          delete sock[m.sender];
        }
      }, 250000) // 5 minutes timeout
    };

    // Polling payment status
    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);

      const resultcek = await axios.get(`https://api-simplebot.vercel.app/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* ${Obj.nominal}
`,
        }, { quoted: sock[m.sender].msg });

        const idtrx = "sock" + `${Date.now()}`;
        await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`);
        await func.sleep(5000);

        let dt = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`);
        if (/status Sukses/.test(dt)) {
          await sock.sendMessage(sock[m.sender].chat, {
            text: `
*Transaksi Telah Berhasil ✅*

 *• ID Game :* ${Obj.nodana}
 *• Barang :* ${Obj.nominal}
 *• Status :* Sukses
          `, contextInfo: { isForwarded: true }
          }, { quoted: null });
        } else {
          await sock.sendMessage(sock[m.sender].chat, { text: dt, contextInfo: { isForwarded: true } }, { quoted: null });
        }

        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
        delete sock[m.sender];
      }
    }

  } catch (err) {
    console.error("Terjadi kesalahan:", err);
    m.reply("Terjadi kesalahan saat memproses pembayaran.");
  }
}
break;

case "buypulsa": {
  if (m.isGroup) {
    return m.reply("Pembelian Pulsa hanya bisa di dalam private chat.");
  }

  // Check if there is an ongoing transaction
  if (sock[m.sender]) {
    return m.reply(`Masih ada transaksi yang belum diselesaikan.\n\nKetik *.batalbeli* untuk membatalkan transaksi sebelumnya.`);
  }

  // Validate input format (must start with '08')
  if (!text || !args[0].startsWith("08")) {
    return example("nomornya (contoh: 0838XXX)");
  }

  // If no specific product is selected, show available options
  if (!text.includes("|")) {
    let nodana = text.replace(/[^0-9]/g, "").trim();

    try {
      const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
      let pulsaOptions = data.filter(item => /PULSA/i.test(item.kategori) && item.harga > 0);
      
      // Prepare options for selection
      let sections = pulsaOptions.map((item) => ({
        title: `${item.keterangan}`,
        header: `${item.produk} ✅`,
        description: `Rp${item.harga}`,
        id: `.buypulsa ${nodana}|${item.kode}|${item.harga}|${item.keterangan}`
      }));

      return sock.sendMessage(m.chat, {
        buttons: [{
          buttonId: "action",
          buttonText: { displayText: "Pilih Pulsa" },
          type: 4,
          nativeFlowInfo: {
            name: "single_select",
            paramsJson: JSON.stringify({
              title: "Pilih Pulsa",
              sections: [{ rows: sections }]
            })
          }
        }],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Jumlah & Operator 🛍️*\n",
        contextInfo: {
          isForwarded: true,
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      }, { quoted: null });

    } catch (err) {
      return m.reply("Terjadi kesalahan saat memuat data pulsa.");
    }
  }

  // Extract selected pulsa details
  let Obj = {
    harga: text.split("|")[2],
    nominal: text.split("|")[3],
    kode: text.split("|")[1],
    nodana: text.split("|")[0]
  };

  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);  // Add random fee

  try {
    // Create payment request for QR code
    const get = await axios.get(
      `https://api-simplebot.vercel.app/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const paymentInfo = get.data.result;
    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${paymentInfo.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(paymentInfo.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• Nomor Tujuan :* ${Obj.nodana}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`;

    // Send QR code and payment info
    let msgQr = await sock.sendMessage(m.chat, {
      buttons: [{
        buttonId: `.batalbeli`,
        buttonText: { displayText: 'Batalkan Pembelian' },
        type: 1
      }],
      headerType: 1,
      viewOnce: true,
      image: { url: paymentInfo.imageqris.url },
      caption: teks3,
      contextInfo: { mentionedJid: [m.sender], isForwarded: true }
    }, { quoted: m });

    // Store the transaction details
    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: paymentInfo.idtransaksi,
      amount: paymentInfo.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
          delete sock[m.sender];
        }
      }, 250000)  // 5 minutes timeout
    };

    // Poll payment status every 5 seconds
    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://api-simplebot.vercel.app/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* ${Obj.nominal}
`,
        }, { quoted: sock[m.sender].msg });

        // Final transaction handling
        const idtrx = "sock" + `${Date.now()}`;
        await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`);
        await func.sleep(4000);

        let dt = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`);
        if (/status Sukses/.test(dt)) {
          await sock.sendMessage(sock[m.sender].chat, {
            text: `
*Transaksi Telah Berhasil ✅*

 *• Nomor Tujuan :* ${Obj.nodana}
 *• Barang :* ${Obj.nominal}
 *• Status :* Sukses
          `, contextInfo: { isForwarded: true }
          }, { quoted: null });
        } else {
          await sock.sendMessage(sock[m.sender].chat, { text: dt, contextInfo: { isForwarded: true } }, { quoted: null });
        }

        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
        delete sock[m.sender];
      }
    }

  } catch (err) {
    console.error("Terjadi kesalahan:", err);
    m.reply("Terjadi kesalahan saat memproses pembayaran.");
  }
}
break;

case "buykuota": {
  if (m.isGroup) {
    return m.reply("Pembelian Kuota hanya bisa di dalam private chat.");
  }

  // Check if there's an ongoing transaction
  if (sock[m.sender]) {
    return m.reply(`Masih ada transaksi yang belum diselesaikan.\n\nKetik *.batalbeli* untuk membatalkan transaksi sebelumnya.`);
  }

  // Validate phone number format
  if (!text || !args[0].startsWith("08")) {
    return example("nomornya (contoh: 0838XXX)");
  }

  // If the input doesn't contain a '|' (meaning no specific product selected), show available options
  if (!text.includes("|")) {
    let nodana = text.replace(/[^0-9]/g, "").trim();

    try {
      const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
      let kuotaOptions = data.filter(item => /KUOTA/i.test(item.kategori) && !item.keterangan.includes("Vcr") && !item.keterangan.includes("Voucher") && item.harga > 0);

      // Prepare options for user to select
      let sections = kuotaOptions.map((item) => ({
        title: `${item.keterangan}`,
        header: `${item.produk} ✅`,
        description: `Rp${item.harga}`,
        id: `.buykuota ${nodana}|${item.kode}|${item.harga}|${item.keterangan}`
      }));

      return sock.sendMessage(m.chat, {
        buttons: [{
          buttonId: "action",
          buttonText: { displayText: "Pilih Kuota" },
          type: 4,
          nativeFlowInfo: {
            name: "single_select",
            paramsJson: JSON.stringify({
              title: "Pilih Kuota",
              sections: [{ rows: sections }]
            })
          }
        }],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Kuota & Operator 🛍️*\n",
        contextInfo: {
          isForwarded: true,
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      }, { quoted: null });
    } catch (err) {
      return m.reply("Terjadi kesalahan saat memuat data kuota.");
    }
  }

  // Extract selected kuota details
  let Obj = {
    harga: text.split("|")[2],
    nominal: text.split("|")[3],
    kode: text.split("|")[1],
    nodana: text.split("|")[0]
  };

  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);  // Add random fee

  try {
    // Create payment request for QR code
    const get = await axios.get(
      `https://api-simplebot.vercel.app/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const paymentInfo = get.data.result;
    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${paymentInfo.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(paymentInfo.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• Nomor Tujuan :* ${Obj.nodana}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`;

    // Send QR code and payment info
    let msgQr = await sock.sendMessage(m.chat, {
      buttons: [{
        buttonId: `.batalbeli`,
        buttonText: { displayText: 'Batalkan Pembelian' },
        type: 1
      }],
      headerType: 1,
      viewOnce: true,
      image: { url: paymentInfo.imageqris.url },
      caption: teks3,
      contextInfo: { mentionedJid: [m.sender], isForwarded: true }
    }, { quoted: m });

    // Store transaction details
    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: paymentInfo.idtransaksi,
      amount: paymentInfo.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
          delete sock[m.sender];
        }
      }, 250000)  // 5 minutes timeout
    };

    // Poll payment status every 5 seconds
    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://api-simplebot.vercel.app/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      // If payment is successful, finalize the transaction
      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* ${Obj.nominal}
`,
        }, { quoted: sock[m.sender].msg });

        // Finalize transaction with H2H
        const idtrx = "sock" + `${Date.now()}`;
        await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`);
        await func.sleep(5000);

        let dt = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`);
        if (/status Sukses/.test(dt)) {
          await sock.sendMessage(sock[m.sender].chat, {
            text: `
*Transaksi Telah Berhasil ✅*

 *• Nomor Tujuan :* ${Obj.nodana}
 *• Barang :* ${Obj.nominal}
 *• Status :* Sukses
          `, contextInfo: { isForwarded: true }
          }, { quoted: null });
        } else {
          await sock.sendMessage(sock[m.sender].chat, { text: dt, contextInfo: { isForwarded: true } }, { quoted: null });
        }

        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
        delete sock[m.sender];
      }
    }

  } catch (err) {
    console.error("Terjadi kesalahan:", err);
    m.reply("Terjadi kesalahan saat memproses pembayaran.");
  }
}
break;

case "buypanel": {
  if (m.isGroup)
    return m.reply(
      "Pembelian Panel Pterodactyl hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
if (!text) return example("username")
if (args.length > 1) return m.reply("Username dilarang menggunakan spasi.")
  if (!text.includes("|")) {
    let usn = text.toLowerCase()
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Ram Server",
                sections: [
                  {
                    highlight_label: "Hight Quality",
                    rows: [
    { title: "Ram Unlimited ✅", description: "Rp11.000", id: `.buypanel unlimited|${usn}` },
    { title: "Ram 1GB ✅", description: "Rp1000", id: `.buypanel 1gb|${usn}` },
    { title: "Ram 2GB ✅", description: "Rp2000", id: `.buypanel 2gb|${usn}` },
    { title: "Ram 3GB ✅", description: "Rp3000", id: `.buypanel 3gb|${usn}` },
    { title: "Ram 4GB ✅", description: "Rp4000", id: `.buypanel 4gb|${usn}` },
    { title: "Ram 5GB ✅", description: "Rp5000", id: `.buypanel 5gb|${usn}` },
    { title: "Ram 6GB ✅", description: "Rp6000", id: `.buypanel 6gb|${usn}` },
    { title: "Ram 7GB ✅", description: "Rp7000", id: `.buypanel 7gb|${usn}` },
    { title: "Ram 8GB ✅", description: "Rp8000", id: `.buypanel 8gb|${usn}` },
    { title: "Ram 9GB ✅", description: "Rp9000", id: `.buypanel 9gb|${usn}` },
    { title: "Ram 10GB ✅", description: "Rp10.000", id: `.buypanel 10gb|${usn}` },
],
                  },
                ],
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Ram Server Panel 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }

  let Obj = {};
  let cmd = text.split("|")[0].toLowerCase()
  const ramOptions = {
    "1gb": { ram: "1000", disk: "1000", cpu: "40", harga: "1000" },
    "2gb": { ram: "2000", disk: "1000", cpu: "60", harga: "2000" },
    "3gb": { ram: "3000", disk: "2000", cpu: "80", harga: "3000" },
    "4gb": { ram: "4000", disk: "2000", cpu: "100", harga: "4000" },
    "5gb": { ram: "5000", disk: "3000", cpu: "120", harga: "5000" },
    "6gb": { ram: "6000", disk: "3000", cpu: "140", harga: "6000" },
    "7gb": { ram: "7000", disk: "4000", cpu: "160", harga: "7000" },
    "8gb": { ram: "8000", disk: "4000", cpu: "180", harga: "8000" },
    "9gb": { ram: "9000", disk: "5000", cpu: "200", harga: "9000" },
    "10gb": { ram: "10000", disk: "5000", cpu: "220", harga: "10000" },
    "unli": { ram: "0", disk: "0", cpu: "0", harga: "11000" },
    "unlimited": { ram: "0", disk: "0", cpu: "0", harga: "11000" },
  };

  if (!ramOptions[cmd]) return m.reply("Pilihan RAM tidak valid!");
  dts = ramOptions[cmd];
  Obj.username = text.split("|")[1]
  Obj.harga = dts.harga
  Obj.ram = dts.ram
  Obj.disk = dts.disk
  Obj.cpu = dts.cpu
  
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://api-simplebot.vercel.app/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://api-simplebot.vercel.app/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Panel Pterodactyl
`,
        }, { quoted: sock[m.sender].msg });

        let username = Obj.username
        let email = username + "@gmail.com";
        let name = func.capital(username) + " Server";
        let password = username + "001"
        let f = await fetch(domain + "/api/application/users", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + apikey,
          },
          body: JSON.stringify({
            email: email,
            username: username.toLowerCase(),
            first_name: name,
            last_name: "Server",
            language: "en",
            password: password.toString(),
          }),
        });
        let data = await f.json();
        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
        let user = data.attributes;
        let desc = func.tanggal(Date.now());
        let usr_id = user.id;
        let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
          method: "GET",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + apikey,
          },
        });
        let data2 = await f1.json();
        let startup_cmd = data2.attributes.startup;
        let f2 = await fetch(domain + "/api/application/servers", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + apikey,
          },
          body: JSON.stringify({
            name: name,
            description: desc,
            user: usr_id,
            egg: parseInt(egg),
            docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
            startup: startup_cmd,
            environment: {
              INST: "npm",
              USER_UPLOAD: "0",
              AUTO_UPDATE: "0",
              CMD_RUN: "npm start",
            },
            limits: {
              memory: Obj.ram,
              swap: 0,
              disk: Obj.disk,
              io: 500,
              cpu: Obj.cpu,
            },
            feature_limits: {
              databases: 5,
              backups: 5,
              allocations: 5,
            },
            deploy: {
              locations: [parseInt(loc)],
              dedicated_ip: false,
              port_range: [],
            },
          }),
        });
        let result = await f2.json();
        if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2));
        let server = result.attributes;
        var orang = sock[m.sender].chat;
        var tekspanel = `
*Data Akun Panel Kamu 📦*

*📡 ID Server (${server.id})*
*👤 Username :* ${user.username}
*🔐 Password :* ${password}
*🗓️ Created :* ${user.created_at.split("T")[0]}

*🌐 Spesifikasi Server*
* Ram : *${Obj.ram == "0" ? "Unlimited" : Obj.ram.split("").length > 4 ? Obj.ram.split("").slice(0, 2).join("") + "GB" : Obj.ram.charAt(0) + "GB"}*
* Disk : *${Obj.disk == "0" ? "Unlimited" : Obj.disk.split("").length > 4 ? Obj.disk.split("").slice(0, 2).join("") + "GB" : Obj.disk.charAt(0) + "GB"}*
* CPU : *${Obj.cpu == "0" ? "Unlimited" : Obj.cpu + "%"}*
* ${global.domain}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`;

        await sock.sendMessage(
          orang,
          {
            text: tekspanel,
            contextInfo: {
            isForwarded: true
            }
          },
          { quoted: null }
        );
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
    m.reply("Terjadi kesalahan saat memproses pembayaran.");
 }
 }
break

case "buyadp": case "buyadminpanel": {
  if (m.isGroup)
    return m.reply(
      "Pembelian admin panel Pterodactyl hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
if (!text) return example("username")
if (args.length > 1) return m.reply("Username dilarang menggunakan spasi.")
  let Obj = {}
  Obj.harga = 20000 //harga
  Obj.username = text.toLowerCase()

  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://api-simplebot.vercel.app/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Admin Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://api-simplebot.vercel.app/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Admin Panel Pterodactyl
`,
        }, { quoted: sock[m.sender].msg });
let username = Obj.username
let email = username+"@gmail.com"
let name = func.capital(args[0])
let password = username+"001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang = sock[m.sender].chat
var teks = `
*Berikut Detail Akun Admin Panel 📦*

*📡 ID User (${user.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password.toString()}
*🗓️ ${func.tanggal(Date.now())}*

*🌐* ${global.domain}

*Syarat & Ketentuan :*
* Expired akun 1 bulan
* Simpan data ini sebaik mungkin
* Jangan asal hapus server!
* Ketahuan maling sc, auto delete akun no reff!
`

        await sock.sendMessage(
          orang,
          {
            text: teks,
            contextInfo: {
            isForwarded: true
            }
          },
          { quoted: null }
        );
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
        delete sock[m.sender]
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
    m.reply("Terjadi kesalahan saat memproses pembayaran.");
 }
 }
break

case "buyreseller": case "buyresellerpanel": {
if (global.linkgrupresellerpanel.length == 0) return m.reply("Maaf grup reseller panel tidak sedang tidak tersedia")
  if (m.isGroup)
    return m.reply(
      "Pembelian Reseller Panel Pterodactyl hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
  let Obj = {}
  Obj.harga = 20000 // harga

  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://api-simplebot.vercel.app/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Reseller Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://api-simplebot.vercel.app/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Reseller Panel Pterodactyl
`,
        }, { quoted: sock[m.sender].msg });
       
 
let teks = `
*Join Grup Reseller Panel :*
`
teks += `* ${global.linkgrupresellerpanel}\n`


        await sock.sendMessage(
          sock[m.sender].chat,
          {
            text: teks,
            contextInfo: {
            isForwarded: true
            }
          },
          { quoted: null }
        );
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
        delete sock[m.sender]
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
    m.reply("Terjadi kesalahan saat memproses pembayaran.");
 }
 }
break

case "buyjasajpm": case "buyjasashare": {
  if (m.isGroup)
    return m.reply(
      "Pembelian Jasa Jpm hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
const groups = await sock.groupFetchAllParticipating()
if (!text) return m.reply(`Contoh : *${cmd}* pesannya & bisa dengan foto juga\n\nTotal grup : ${(Object.keys(groups)).length}`)
  let Obj = {}
if (/image/i.test(mime)) {
Obj.image = m.quoted ? await m.quoted.download() : await m.download()
}
  Obj.teksjpm = text
  Obj.grup = await Object.keys(groups)
  Obj.harga = 1 // harga

  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://api-simplebot.vercel.app/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Jasa Jpm
 *• Target :* ${Obj.grup.length} Grup
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://api-simplebot.vercel.app/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Jasa Jpm
 *• Target : ${Obj.grup.length} Grup
`,
        }, { quoted: sock[m.sender].msg });

await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
const gcnya = Obj.grup
await sock.sendMessage(sock[m.sender].chat,
{text: `Memproses Jpm pesan *${Obj.image !== undefined ? "teks & foto" : "teks"}* ke ${gcnya.length} grup`, contextInfo: {isForwarded: true}}, { quoted: null });
let messages = Obj.image !== undefined ? { image: Obj.image, caption: Obj.teksjpm } : { text: Obj.teksjpm }
for (let id of gcnya) {
if (bljpm.includes(id)) continue
try {
await sock.sendMessage(id, messages, { quoted: qjasajpm })
await func.sleep(4000)
} catch {}
}
await sock.sendMessage(sock[m.sender].chat,
{text: `Berhasil Jpm pesan *${Obj.image !== undefined ? "teks & foto" : "teks"}* ke ${gcnya.length} grup`, contextInfo: {isForwarded: true}}, { quoted: null })
delete sock[m.sender]
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
    m.reply("Terjadi kesalahan saat memproses pembayaran.");
 }
 }
break


case "buyvps": {
if (global.apidigitalocean.length < 1) return m.reply("Maaf vps sedang tidak tersedia.")
  if (m.isGroup)
    return m.reply(
      "Pembelian Reseller Panel Pterodactyl hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);

if (args.length < 4) return sock.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Vps',
                sections: [
                  {
                    rows: [
                {
                    header: "RAM 1GB & 1 CPU ✅",
                    title: "Sgp Ubuntu 20.04",
                    description: "Rp20.000",
                    id: ".buyvps vps1g1c ubuntu 20-04 sgp1 20000"
                },
                {
                    header: "RAM 2GB & 1 CPU ✅",
                    title: "Sgp Ubuntu 20.04",
                    description: "Rp25.000",
                    id: ".buyvps vps2g1c ubuntu 20-04 sgp1 25000"
                },
                {
                    header: "RAM 2GB & 2 CPU ✅",
                    title: "Sgp Ubuntu 20.04",
                    description: "Rp30.000",
                    id: ".buyvps vps2g2c ubuntu 20-04 sgp1 30000"
                },
                {
                    header: "RAM 4GB & 2 CPU ✅",
                    title: "Sgp Ubuntu 20.04",
                    description: "Rp35.000",
                    id: ".buyvps vps4g2c ubuntu 20-04 sgp1 35000"
                },
                {
                    header: "RAM 8GB & 4 CPU ✅",
                    title: "Sgp Ubuntu 20.04",
                    description: "Rp50.000",
                    id: ".buyvps vps8g4c ubuntu 20-04 sgp1 50000"
                },
                {
                    header: "RAM 16GB & 4 CPU ✅",
                    title: "Sgp Ubuntu 20.04",
                    description: "Rp60.000",
                    id: `.buyvps vps16g4c ubuntu 20-04 sgp1 60000`
                }
            ]
                  },
                ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: "\n Pilih Spesifikasi Vps 🛍️\n",
  contextInfo: {
   isForwarded: true
  },
}, {quoted: null})

let Obj = {}
Obj.hostname = `skyzopedia${func.generateRandomNumber(1, 10)}` // Nama host
Obj.sizeOption = args[0]; // Ukuran VPS
Obj.osOption = args[1] || "ubuntu"; // Default: Ubuntu
Obj.osVersionOption = args[2] || "20-04"; // Default: Ubuntu 20.04
Obj.regionOption = args[3] || "sgp1"; // Default: Singapore
Obj.harga = args[4]
const passwd = crypto.randomBytes(10).toString("base64").replace(/[^a-zA-Z0-9]/g, "").slice(0, 10);
Obj.password = passwd

  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://api-simplebot.vercel.app/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Virtual Private Server (Vps)
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://api-simplebot.vercel.app/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Virtual Private Server (Vps)
`,
        }, { quoted: sock[m.sender].msg });

  // Peta OS dan Versi
  const osMap = {
    ubuntu: { '20-04': 'ubuntu-20-04-x64', '22-04': 'ubuntu-22-04-x64' },
    debian: { '10': 'debian-10-x64', '11': 'debian-11-x64' },
    centos: { '8': 'centos-8-x64', '7': 'centos-7-x64' },
    fedora: { '34': 'fedora-34-x64', '35': 'fedora-35-x64' },
  };

  if (!osMap[osOption]) {
    return m.reply(`*OS tidak valid!*\nOS yang tersedia: ubuntu, debian, centos, fedora.`);
  }
  if (!osMap[osOption][osVersionOption]) {
    return m.reply(
      `*Versi OS tidak valid!*\nVersi yang tersedia untuk ${osOption}: ${Object.keys(osMap[osOption]).join(', ')}`
    );
  }

  // Peta Ukuran
  const sizeMap = {
    vps1g1c: 's-1vcpu-1gb',
    vps2g1c: 's-1vcpu-2gb',
    vps2g2c: 's-2vcpu-2gb',
    vps4g2c: 's-2vcpu-4gb',
    vps8g4c: 's-4vcpu-8gb',
    vps16g4c: 's-4vcpu-16gb-amd',
  };

  if (!sizeMap[sizeOption]) {
    return m.reply(`*Ukuran VPS tidak valid!*\nUkuran yang tersedia: ${Object.keys(sizeMap).join(', ')}`);
  }

  // Peta Region
  const regionMap = {
    sgp1: 'Singapore (SGP1)',
    nyc3: 'New York (NYC3)',
    ams3: 'Amsterdam (AMS3)',
    lon1: 'London (LON1)',
    fra1: 'Frankfurt (FRA1)',
    sfo1: 'San Francisco (SFO1)',
    blr1: 'Bangalore (BLR1)',
    tor1: 'Toronto (TOR1)',
  };

  if (!regionMap[regionOption]) {
    return m.reply(`*Region tidak valid!*\nRegion yang tersedia: ${Object.keys(regionMap).join(', ')}`);
  }

  try {
    // Data untuk membuat droplet
    let dropletData = {
      name: hostname.toLowerCase(),
      region: regionOption,
      size: sizeMap[sizeOption],
      image: osMap[osOption][osVersionOption],
      ssh_keys: null,
      backups: false,
      ipv6: true,
      user_data: null,
      private_networking: null,
      volumes: null,
      tags: ['T'],
    };
    let password = Obj.password
    dropletData.user_data = `#cloud-config\npassword: ${password}\nchpasswd: { expire: False }`;

    let response = await fetch('https://api.digitalocean.com/v2/droplets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + global.apidigitalocean,
      },
      body: JSON.stringify(dropletData),
    });

    let responseData = await response.json();

    if (response.ok) {
      let dropletConfig = responseData.droplet;
      let dropletId = dropletConfig.id;
      await new Promise(resolve => setTimeout(resolve, 15000))

      // Mengambil informasi VPS
      let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + global.apidigitalocean,
        },
      });

      let dropletDetails = await dropletResponse.json();
      let ipVPS =
        dropletDetails.droplet.networks.v4 && dropletDetails.droplet.networks.v4.length > 0
          ? dropletDetails.droplet.networks.v4[0].ip_address
          : 'Tidak ada alamat IP yang tersedia';

 let messageText = `
*Berhasil membuat Vps ✅*
      
* *ID :* ${dropletId}
* *IP Vps :* ${ipVPS}
* *Username :* root
* *Password :* ${password}
`

      await sock.sendMessage(
          sock[m.sender].chat,
          {
            text: messageText,
            contextInfo: {
            isForwarded: true
            }
          },
          { quoted: null }
        );
    } else {
      throw new Error(`Gagal membuat VPS: ${responseData.message}`);
    }
    
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
        delete sock[m.sender]
  } catch (err) {
    console.error(err);
    m.reply(`Terjadi kesalahan saat membuat VPS: ${err.message}`);
  }
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
    m.reply("Terjadi kesalahan saat memproses pembayaran.");
 }
 }
break


case "buydo": case "buydigitalocean": {
if (stokdo.length < 1) return m.reply("Maaf stok akun Digital Ocean sedang tidak tersedia.")
  if (m.isGroup)
    return m.reply(
      "Pembelian Digital Ocean hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);

  if (!text) {
    let butnya = []
    let urutt = 0
    for (let gg of stokdo) {
    butnya.push({
    title: `${gg.droplet} Droplet ✅`, 
    description: `Rp${await func.toRupiah(gg.harga)}`, 
    id: `.buydo ${urutt += 1}`
    })
    }
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Droplet",
                sections: [
                  {
                    highlight_label: "Hight Quality",
                    rows: butnya, 
                    }
                 ], 
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Droplet Digital Ocean 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }
 const donya = stokdo[Number(text) - 1]
let us = crypto.randomBytes(4).toString('hex')
let Obj = {}
Obj.harga = donya.harga
Obj.akun = donya
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://api-simplebot.vercel.app/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Akun Digital Ocean
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://api-simplebot.vercel.app/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Akun Digital Ocean
`,
        }, { quoted: sock[m.sender].msg });

var teks = `
*Data Akun Digitalocean 📦*

*💌 Email :* ${Obj.akun.email}
*🔐 Password :* ${Obj.akun.password}
*Kode 2FA :* ${Obj.akun.kode2fa}
*Droplet :* ${Obj.akun.droplet}

*Syarat & Ketentuan :*
* Simpan data ini sebaik mungkin
* Seller hanya mengirim 1 kali!
* Garansi akun aktif 30 day
`
await sock.sendMessage(sock[m.sender].chat, {text: teks, contextInfo: { isForwarded: true }}, {quoted: null})
const position = stokdo.indexOf(Obj.akun)
stokdo.splice(position, 1)
await fs.writeFileSync("./data/stokdo.json", JSON.stringify(stokdo, null, 2))
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
    m.reply("Terjadi kesalahan saat memproses pembayaran.");
 }
 }
break

case "buysc": case "buyscript": {
if (script.length < 1) return m.reply("Maaf Script Bot sedang tidak tersedia.")
  if (m.isGroup)
    return m.reply(
      "Pembelian Script Bot hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);

  if (!text) {
    let butnya = []
    let urutt = 0
    for (let gg of script) {
    butnya.push({
    title: `${gg.nama} ✅`, 
    description: `Rp${await func.toRupiah(gg.harga)}`, 
    id: `.buyscript ${urutt += 1}`
    })
    }
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Script",
                sections: [
                  {
                    rows: butnya, 
                    }
                 ], 
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Script Bot WhatsApp 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }
 const scnya = script[Number(text) - 1]
let Obj = {}
Obj.harga = scnya.harga
Obj.namasc = scnya.nama
Obj.path = scnya.path
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://api-simplebot.vercel.app/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Script ${Obj.namasc}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://api-simplebot.vercel.app/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Script ${Obj.namasc}
`,
        }, { quoted: sock[m.sender].msg });
await sock.sendMessage(sock[m.sender].chat, {document: await fs.readFileSync(Obj.path), mimetype: "application/zip", fileName: Obj.namasc + ".zip", contextInfo: { isForwarded: true }}, {quoted: null})
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
    m.reply("Terjadi kesalahan saat memproses pembayaran.");
 }
 }
break

case "siapakahaku": {
if (!m.isGroup) return m.reply(msg.group)
if (sock[m.chat] && sock[m.chat].siapakahaku) return sock.sendMessage(m.chat, {text: "Masih ada sesi game *siapakahaku* yang belum terselesaikan di grup ini!"}, {quoted: sock[m.chat].siapakahaku.gameMessage})
const gameQuestions = require("../data/game/siapakahaku.js")
const { question, answer } = gameQuestions[Math.floor(Math.random() * gameQuestions.length)]
let teks = `
*🎮 Game Siapakahaku 🎮*

* *Pertanyaan*
${question}
* *Waktu Game (3 menit)*
`
let msgg = await sock.sendMessage(m.chat, {text: teks, contextInfo: { isForwarded: true, forwardingScore: 9999 }}, {quoted: m})
const idGame = func.getRandom("")
sock[m.chat] = {}
sock[m.chat].siapakahaku = {
gameQuestion: question, 
gameAnswer: answer, 
gameRoom: m.chat, 
idGame: idGame, 
gameMessage: msgg, 
gameTime: setTimeout(() => {
if (sock[m.chat].siapakahaku.idGame == idGame) {
sock.sendMessage(sock[m.chat].siapakahaku.gameRoom, {text: `
*Waktu Game Telah Habis ❌*

*Jawabannya Adalah :*
* ${sock[m.chat].siapakahaku.gameAnswer}
`}, {quoted: sock[m.chat].siapakahaku.gameMessage})
delete sock[m.chat]
}
}, 180000)
}
await sock.sendMessage(global.owner+"@s.whatsapp.net", {text: `
*Jawaban Game Siapakah Aku*
* ${sock[m.chat].siapakahaku.gameAnswer}
`}, {quoted: sock[m.chat].siapakahaku.gameMessage})
}
break


case "kuis": {
if (!m.isGroup) return m.reply(msg.group)
if (sock[m.chat] && sock[m.chat].kuis) return sock.sendMessage(m.chat, {text: "Masih ada sesi game *kuis* yang belum terselesaikan di grup ini!"}, {quoted: sock[m.chat].kuis.gameMessage})
const gameQuestions = require("../data/game/kuis.js")
const { question, answer } = gameQuestions[Math.floor(Math.random() * gameQuestions.length)]
let teks = `
*🎮 Game Kuis 🎮*

* *Pertanyaan*
${question}
* *Waktu Game (3 menit)*
`
let msgg = await sock.sendMessage(m.chat, {text: teks, contextInfo: { isForwarded: true, forwardingScore: 9999 }}, {quoted: m})
const idGame = func.getRandom("")
sock[m.chat] = {}
sock[m.chat].kuis = {
gameQuestion: question, 
gameAnswer: answer, 
gameRoom: m.chat, 
idGame: idGame, 
gameMessage: msgg, 
gameTime: setTimeout(() => {
if (sock[m.chat].kuis.idGame == idGame) {
sock.sendMessage(sock[m.chat].kuis.gameRoom, {text: `
*Waktu Game Telah Habis ❌*

*Jawabannya Adalah :*
* ${sock[m.chat].kuis.gameAnswer}
`}, {quoted: sock[m.chat].kuis.gameMessage})
delete sock[m.chat]
}
}, 180000)
}
await sock.sendMessage(global.owner+"@s.whatsapp.net", {text: `
*Jawaban Game Kuis*
* ${sock[m.chat].kuis.gameAnswer}
`}, {quoted: sock[m.chat].kuis.gameMessage})
}
break

case "family100": {
if (!m.isGroup) return m.reply(msg.group)
if (sock[m.chat] && sock[m.chat].family100) return sock.sendMessage(m.chat, {text: "Masih ada sesi game *family100* yang belum terselesaikan di grup ini!"}, {quoted: sock[m.chat].family100.gameMessage})
const gameQuestions = require("../data/game/family100.js")
const { question, answer } = gameQuestions[Math.floor(Math.random() * gameQuestions.length)]
let teks = `
*🎮 Game Family100 🎮*

* *Pertanyaan*
${question}
* *Waktu Game (3 menit)*
`
let msgg = await sock.sendMessage(m.chat, {text: teks, contextInfo: { isForwarded: true, forwardingScore: 9999 }}, {quoted: m})
const idGame = func.getRandom("")
sock[m.chat] = {}
sock[m.chat].family100 = {
gameQuestion: question, 
gameAnswer: answer, 
gameRoom: m.chat, 
users: [], 
idGame: idGame, 
gameMessage: msgg, 
gameTime: setTimeout(() => {
if (sock[m.chat].family100.idGame == idGame) {
sock.sendMessage(sock[m.chat].family100.gameRoom, {text: `
*Game Family100 Telah Habis ❌*

*Daftar User Berhasil Menjawab :*
${sock[m.chat].family100.users.length > 1 ? sock[m.chat].family100.users.map(e => "@" + e.user.split("@")[0]).join("\n") : "Tidak Ada"}
`, mentions: sock[m.chat].family100.users.map(e => e?.user)}, {quoted: sock[m.chat].family100.gameMessage})
delete sock[m.chat]
}
}, 180000)
}
await sock.sendMessage(global.owner+"@s.whatsapp.net", {text: `
*Jawaban Game Family100*
${sock[m.chat].family100.gameAnswer.join("\n")}
`}, {quoted: sock[m.chat].family100.gameMessage})
}
break


case "tebakgambar": {
if (!m.isGroup) return m.reply(msg.group)
if (sock[m.chat] && sock[m.chat].tebakgambar) return sock.sendMessage(m.chat, {text: "Masih ada sesi game *tebak gambar* yang belum terselesaikan di grup ini!"}, {quoted: sock[m.chat].tebakgambar.gameMessage})
const gameQuestions = require("../data/game/tebakgambar.js")
const { img, jawaban, deskripsi } = gameQuestions[Math.floor(Math.random() * gameQuestions.length)]
let teks = `
*🎮 Game Tebak Gambar 🎮*

* *Deskripsi*
${deskripsi}
* *Waktu Game (3 menit)*
`
let msgg = await sock.sendMessage(m.chat, {image: {url: img}, caption: teks, contextInfo: { isForwarded: true, forwardingScore: 9999 }}, {quoted: m})
const idGame = func.getRandom("")
sock[m.chat] = {}
sock[m.chat].tebakgambar = {
gameQuestion: deskripsi, 
gameAnswer: jawaban, 
gameRoom: m.chat, 
idGame: idGame, 
gameMessage: msgg, 
gameTime: setTimeout(() => {
if (sock[m.chat].tebakgambar.idGame == idGame) {
sock.sendMessage(sock[m.chat].tebakgambar.gameRoom, {text: `
*Waktu Game Telah Habis ❌*

*Jawabannya Adalah :*
* ${sock[m.chat].tebakgambar.gameAnswer}
`}, {quoted: sock[m.chat].tebakgambar.gameMessage})
delete sock[m.chat]
}
}, 180000)
}
await sock.sendMessage(global.owner+"@s.whatsapp.net", {text: `
*Jawaban Game Tebak Gambar*
* ${sock[m.chat].tebakgambar.gameAnswer}
`}, {quoted: sock[m.chat].tebakgambar.gameMessage})
}
break

case "tebakheroml": {
if (!m.isGroup) return m.reply(msg.group)
if (sock[m.chat] && sock[m.chat].tebakheroml) return sock.sendMessage(m.chat, {text: "Masih ada sesi game *tebak hero ml* yang belum terselesaikan di grup ini!"}, {quoted: sock[m.chat].tebakheroml.gameMessage})
const gameQuestions = require("../data/game/tebakheroml.js")
const { soal, jawaban } = gameQuestions[Math.floor(Math.random() * gameQuestions.length)]
let msgg = await sock.sendMessage(m.chat, {audio: {url: soal}, mimetype: "audio/mpeg", ptt: true, contextInfo: { mentionedJid: [m.sender], isForwarded: true, forwardingScore: 9999, 
externalAdReply: {
title: "🎮 Tebak Hero ML 🎮", 
body: "Waktu Game 3 Menit", 
thumbnailUrl: global.image, 
previewType: "PHOTO"
}
}}, {quoted: m})
const idGame = func.getRandom("")
sock[m.chat] = {}
sock[m.chat].tebakheroml = {
gameQuestion: soal, 
gameAnswer: jawaban.toLowerCase(), 
gameRoom: m.chat, 
idGame: idGame, 
gameMessage: msgg, 
gameTime: setTimeout(() => {
if (sock[m.chat].tebakheroml.idGame == idGame) {
sock.sendMessage(sock[m.chat].tebakheroml.gameRoom, {text: `
*Waktu Game Telah Habis ❌*

*Jawabannya Adalah :*
* ${sock[m.chat].tebakheroml.gameAnswer}
`}, {quoted: sock[m.chat].tebakheroml.gameMessage})
delete sock[m.chat]
}
}, 180000)
}
await sock.sendMessage(global.owner+"@s.whatsapp.net", {text: `
*Jawaban Game Tebak Heroml*
* ${sock[m.chat].tebakheroml.gameAnswer}
`}, {quoted: sock[m.chat].tebakheroml.gameMessage})
}
break

case "tebakanime": {
if (!m.isGroup) return m.reply(msg.group)
if (sock[m.chat] && sock[m.chat].tebakanime) return sock.sendMessage(m.chat, {text: "Masih ada sesi game *tebak anime* yang belum terselesaikan di grup ini!"}, {quoted: sock[m.chat].tebakanime.gameMessage})
const gameQuestions = require("../data/game/tebakanime.js")
const { image, answer } = gameQuestions[Math.floor(Math.random() * gameQuestions.length)]
let teks = `
*🎮 Game Tebak Anime 🎮*

* *Waktu Game (3 menit)*
`
let msgg = await sock.sendMessage(m.chat, {image: {url: image}, caption: teks, contextInfo: { isForwarded: true, forwardingScore: 9999 }}, {quoted: m})
const idGame = func.getRandom("")
sock[m.chat] = {}
sock[m.chat].tebakanime = {
gameQuestion: image, 
gameAnswer: answer, 
gameRoom: m.chat, 
idGame: idGame, 
gameMessage: msgg, 
gameTime: setTimeout(() => {
if (sock[m.chat].tebakanime.idGame == idGame) {
sock.sendMessage(sock[m.chat].tebakanime.gameRoom, {text: `
*Waktu Game Telah Habis ❌*

*Jawabannya Adalah :*
* ${sock[m.chat].tebakanime.gameAnswer}
`}, {quoted: sock[m.chat].tebakanime.gameMessage})
delete sock[m.chat]
}
}, 180000)
}
await sock.sendMessage(global.owner+"@s.whatsapp.net", {text: `
*Jawaban Game Tebak Anime*
* ${sock[m.chat].tebakanime.gameAnswer}
`}, {quoted: sock[m.chat].tebakanime.gameMessage})
}
break

case "boom": case "tebakbom": {
 if (!m.isGroup) return m.reply(msg.group); 
 if (sock[m.chat] && sock[m.chat].tebakboom) return sock.sendMessage(m.chat, { text: "Masih ada sesi game tebak boom yang belum terselesaikan di grup ini!" }, { quoted: sock[m.chat].tebakboom.gameMessage });

const gameQuestions = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣"];
let boom = gameQuestions.map((e, i) => (i === 2 || i === 5 ? e + "\n" : e)).join("");

let teks = `
*🎮 Game Tebak Boom 🎮*

${boom}

* *Waktu Game (5 menit)*
 `;

let msgg = await sock.sendMessage(m.chat, { text: teks, contextInfo: { isForwarded: true, forwardingScore: 9999 } }, { quoted: m });

let randomIndex = Math.floor(Math.random() * gameQuestions.length);

const idGame = func.getRandom("");

sock[m.chat] = sock[m.chat] || {};
sock[m.chat].tebakboom = {
    gameQuestion: [...gameQuestions], // Simpan game board asli tanpa menampilkan bom
    boomIndex: randomIndex, // Simpan indeks bom tanpa menampilkan di game board
    gameRoom: m.chat,
    idGame: idGame,
    gameMessage: msgg,
    gameTime: setTimeout(() => {
        if (sock[m.chat] && sock[m.chat].tebakboom && sock[m.chat].tebakboom.idGame === idGame) {
            let bom = sock[m.chat].tebakboom.boomIndex + 1; // Tampilkan posisi bom yang sebenarnya
            sock.sendMessage(m.chat, { text: `
*Waktu Game Telah Habis ❌*

Boom tidak ditemukan 
${bom} = 💣
 `}, { quoted: sock[m.chat].tebakboom.gameMessage });

delete sock[m.chat].tebakboom;
        }
    }, 5 * 60 * 1000) // 5 menit
};

await sock.sendMessage(global.owner + "@s.whatsapp.net", { text: `
Jawaban Game Boom ada di posisi: ${sock[m.chat].tebakboom.boomIndex + 1} `}, { quoted: sock[m.chat].tebakboom.gameMessage }); 
} 
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "deldomaincf": case "deldomcf": {
if (!isOwner) return m.reply(msg.owner)
if (!text || !text.includes(".")) return example("domainmu.com")
const CLOUDFLARE_API_TOKEN = global.apitoken_cloudflare // Ganti dengan API Token
const CLOUDFLARE_EMAIL = global.email_cloudflare // Jika pakai API Key


async function deleteDomain(domain) {
    try {
        // Ambil Zone ID berdasarkan nama domain
        const zoneResponse = await axios.get(
            `https://api.cloudflare.com/client/v4/zones?name=${domain}`,
            {
                headers: {
                    Authorization: `Bearer ${CLOUDFLARE_API_TOKEN}`, // Jika pakai API Token
                    "X-Auth-Email": CLOUDFLARE_EMAIL, // Jika pakai API Key
                    "Content-Type": "application/json",
                },
            }
        );

        if (!zoneResponse.data.success || zoneResponse.data.result.length === 0) {
            return m.reply(`Domain ${domain} tidak ditemukan di Cloudflare.`);
        }

        const zoneId = zoneResponse.data.result[0].id;

        // Hapus domain berdasarkan Zone ID
        const deleteResponse = await axios.delete(
            `https://api.cloudflare.com/client/v4/zones/${zoneId}`,
            {
                headers: {
                    Authorization: `Bearer ${CLOUDFLARE_API_TOKEN}`, // Jika pakai API Token
                    "X-Auth-Email": CLOUDFLARE_EMAIL, // Jika pakai API Key
                    "Content-Type": "application/json",
                },
            }
        );

        if (deleteResponse.data.success) {
           return m.reply(`Berhasil menghapus domain ${domain} dari Cloudflare ✅`)
        } else {
           return m.reply(`Gagal menghapus domain ${domain}: ` + deleteResponse.data.errors)
        }
    } catch (error) {
        console.error("Error:", error.response ? error.response.data : error.message);
    }
}

return deleteDomain(text.toLowerCase())
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "adddomaincf": case "adddomcf": {
if (!isOwner) return m.reply(msg.owner)
if (!text || !text.includes(".")) return example("domainmu.com")
const CLOUDFLARE_TOKEN = global.apitoken_cloudflare
const CLOUDFLARE_EMAIL = global.email_cloudflare
const cloudflare = axios.create({
    baseURL: 'https://api.cloudflare.com/client/v4',
    headers: {
        'Authorization': `Bearer ${CLOUDFLARE_TOKEN}`,
        'Content-Type': 'application/json'
    }
});
async function addNewDomainToCloudflare(domainName) {
    try {
        const response = await cloudflare.post('/zones', {
            name: domainName,
            account: {
                id: global.accountid_cloudflare
            },
            plan: {
                id: 'free'
            },
            type: 'full',
            jump_start: true
        });
        return response.data
    } catch (error) {
        return 'Gagal menambahkan domain:' + JSON.stringify(error.response ? error.response.data : error.message, null, 2)
    }
}
let res = await addNewDomainToCloudflare(text.toLowerCase())
if (res?.result?.name_servers) {
let respon = `
Domain ${text.toLowerCase()} Berhasil Ditambahkan Kedalam Cloudflare ✅

*Name Server :*
* ns1 ${res.result.name_servers[0]}
* ns2 ${res.result.name_servers[1]}
`
return m.reply(respon)
} else {
return m.reply(JSON.stringify(res, null, 2))
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "clearsubdo": case "clearallsubdo": case "clsubdo": case "clearsubdomain": {
if (!text || !text.includes("|")) return example('zoneid|apikey')
let [apizone, apitoken] = text.split("|")
const CLOUDFLARE_API_KEY = apitoken;  // Ganti dengan API key
const CLOUDFLARE_ZONE_ID = apizone;  // Ganti dengan Zone ID

async function getAllDNSRecords() {
    let allRecords = [];
    let page = 1;
    let totalPages = 1;

    try {
        while (page <= totalPages) {
            const response = await axios.get(`https://api.cloudflare.com/client/v4/zones/${CLOUDFLARE_ZONE_ID}/dns_records`, {
                params: { page, per_page: 100 },
                headers: {
                    'Authorization': `Bearer ${CLOUDFLARE_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.data.success) {
                console.error("Gagal mengambil DNS records:", response.data.errors);
                return [];
            }

            allRecords.push(...response.data.result);
            totalPages = response.data.result_info.total_pages;
            page++;
        }
    } catch (error) {
        console.error("Terjadi kesalahan saat mengambil DNS records:", error.message);
    }
    return allRecords;
}

// Fungsi untuk menghapus semua DNS record
async function deleteAllDNSRecords() {
    try {
        const records = await getAllDNSRecords();
        const totalDns = records.length

        if (records.length === 0) {
            await m.reply("Tidak ada Subdomain yang ditemukan.");
            return;
        }

        m.reply(`${totalDns} Subdomain ditemukan. Memproses penghapusan...`);

        for (const record of records) {
            try {
                const deleteResponse = await axios.delete(`https://api.cloudflare.com/client/v4/zones/${CLOUDFLARE_ZONE_ID}/dns_records/${record.id}`, {
                    headers: {
                        'Authorization': `Bearer ${CLOUDFLARE_API_KEY}`,
                        'Content-Type': 'application/json'
                    }
                });

                if (deleteResponse.data.success) {
                    console.log(`✅ Berhasil menghapus record: ${record.name} (ID: ${record.id})`);
                } else {
                    console.error(`❌ Gagal menghapus record ${record.name}:`, deleteResponse.data.errors);
                }
            } catch (error) {
                console.error(`❌ Terjadi kesalahan saat menghapus record ${record.name}:`, error.message);
            }
        }

        await m.reply(`Berhasil menghapus ${totalDns} Subdomain ✅`);
    } catch (error) {
        console.error("Terjadi kesalahan:", error.message);
    }
}

// Jalankan fungsi
return deleteAllDNSRecords();
}
break

case "listdomaincf": case "listdomcf": {
if (!isOwner) return m.reply(msg.owner)
const CLOUDFLARE_API_KEY = global.apitoken_cloudflare // Ganti dengan API Key atau API Token
const CLOUDFLARE_EMAIL = global.email_cloudflare // Email akun Cloudflare (jika pakai API Key)

async function getAllDomains() {
    let page = 1;
    let domains = [];
    let hasMore = true;

    while (hasMore) {
        const url = `https://api.cloudflare.com/client/v4/zones?page=${page}&per_page=50`; // Maksimal 50 per halaman

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${CLOUDFLARE_API_KEY}`, // Jika pakai API Token
                // 'X-Auth-Email': CLOUDFLARE_EMAIL, // Jika pakai API Key
                // 'X-Auth-Key': CLOUDFLARE_API_KEY  // Jika pakai API Key
            }
        });

        const data = await response.json();
        
        if (data.success) {
            domains = domains.concat(data.result.map(zone => ({
                id: zone.id,
                name: zone.name,
                status: zone.status
            })));

            // Cek apakah masih ada halaman berikutnya
            hasMore = data.result_info.page < data.result_info.total_pages;
            page++;
        } else {
            console.error('Gagal mengambil daftar domain:', data.errors);
            return [];
        }
    }

    console.log('Total Domain:', domains.length);
    console.log('Daftar Domain:', domains);
    return domains;
}


// Jalankan function
let res = await getAllDomains();
if (res.length < 1) return m.reply("Tidak ada domain di cloudflare")
let teks = `\n*Total Domain Cloudflare :* ${res.length}\n`
for (let i of res) {
teks += `
* ${i.name}
* *Status :* ${i.status == "active" ? i.status + " ✅" : i.status == "pending" ? i.status + " 🕞" : i.status + " ❌"}
`
}
return m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "cpaste": case "pastebin": {
if (!text) return example("teksnya")
let { PasteClient, Publicity, ExpireDate } = require("pastebin-api")
const client = new PasteClient("XRP7K6sqg-cafuC5J509m0fFMUiLFxi5");
const url = await client.createPaste({
  code: text,
  expireDate: ExpireDate.Never,
  format: "javascript",
  name: "something.js",
  publicity: Publicity.Public,
});
let links = `https://pastebin.com/raw/${url.split("/")[3]}`
return m.reply(links)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ip": case "getip": {
if (!isOwner) return
let t = await func.fetchJson('https://api64.ipify.org?format=json')
m.reply(`IP Panel : ${t.ip}`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "rst": case "restart": {
if (!isOwner) return
const { spawn } = require("child_process");

function restartServer() {
  // Spawn proses baru untuk menjalankan ulang server
  const newProcess = spawn(process.argv[0], process.argv.slice(1), {
    detached: true,
    stdio: "inherit",
  });

  // Keluar dari proses lama
  process.exit(0);
}

await m.reply("Restarting bot . . .")
// Contoh penggunaan: Restart setelah 5 detik
await setTimeout(() => {
  restartServer();
}, 5000);
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ssweb": {
  if (!text) return m.reply("\nMasukkan link website yang ingin di-screenshot.\n\nContoh *.ssweb* https://example.com\n")

  try {
    const res = await func.fetchJson(`https://api-simplebot.vercel.app/tools/ssweb?apikey=${global.ApikeyRestApi}&url=${encodeURIComponent(text)}`)

    if (!res || !res.result) {
      return sock.sendMessage(m.chat, {
        text: "Gagal mengambil screenshot. Pastikan link yang diberikan valid dan server API aktif.",
      }, { quoted: m })
    }

    return sock.sendMessage(m.chat, {
      image: { url: res.result },
      caption: "Screenshot Web Done ✅"
    }, { quoted: m })

  } catch (err) {
    console.error("Error ssweb:", err)
    return sock.sendMessage(m.chat, {
      text: "Terjadi kesalahan saat mengambil screenshot. Coba lagi nanti.",
    }, { quoted: m })
  }
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "rvo": case "readviewonce": {
if (!m.quoted) return example("dengan reply pesannya")
let msg = m.quoted.fakeObj.message
    let type = Object.keys(msg)[0]
if (!msg[type].viewOnce && m.quoted.mtype !== "viewOnceMessageV2") return m.reply("Pesan itu bukan viewonce!")
let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : type == 'videoMessage' ? 'video' : 'audio')
    let buffer = Buffer.from([])
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
    }
    if (/video/.test(type)) {
        return sock.sendMessage(m.chat, {video: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/image/.test(type)) {
        return sock.sendMessage(m.chat, {image: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/audio/.test(type)) {
        return sock.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: true}, {quoted: m})
    } 
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "clsesi": case "clearsession": {
if (!isOwner) return
await m.reply("Memproses penghapusan file sampah session")
const dirsesi = await fs.readdirSync("./session").filter(e => e !== "creds.json")
const dirsampah = await fs.readdirSync("./server/tmp").filter(e => e !== "akses.txt")
for (const i of dirsesi) {
await fs.unlinkSync("./session/" + i)
}
for (const u of dirsampah) {
await fs.unlinkSync("./server/tmp/" + u)
}
return m.reply(`*Berhasil membersihkan session ✅*
*${dirsesi.length}* sampah session berhasil di hapus.`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ping": case "uptime": {
  const os = require('os');
  const nou = require('node-os-utils');
  const speed = require('performance-now');

  async function getServerInfo(func, m) {
    const timestamp = speed();
    const tio = await nou.os.oos();
    const tot = await nou.drive.info();
    const memInfo = await nou.mem.info(); // <- Added 'await' here
    const totalGB = (memInfo.totalMemMb / 1024).toFixed(2);
    const usedGB = (memInfo.usedMemMb / 1024).toFixed(2);
    const freeGB = (memInfo.freeMemMb / 1024).toFixed(2);
    const cpuCores = os.cpus().length;
    const vpsUptime = func.runtime(os.uptime());
    const botUptime = func.runtime(process.uptime());
    const latency = (speed() - timestamp).toFixed(4);

    const respon = `
*─── SERVER INFORMATION ───*

📂 *OS Platform*: ${nou.os.type()}  
💾 *Total RAM*: ${totalGB} GB  
⚡ *Used RAM*: ${usedGB} GB  
💡 *Free RAM*: ${freeGB} GB  
💻 *Total Disk Space*: ${tot.totalGb} GB  
🧠 *CPU Cores*: ${cpuCores} Core(s)  
⏳ *VPS Uptime*: ${vpsUptime}  

*─── BOT INFORMATION ───*

⚡ *Response Speed*: ${latency} seconds  
🤖 *Bot Uptime*: ${botUptime}  
🖥️ *Running on*: ${os.arch()} architecture  
🔌 *CPU Model*: ${os.cpus()[0].model}  
💼 *Host*: ${os.hostname()}  
`;

    return m.reply(respon);
  }

  return getServerInfo(func, m);
}
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

default:
if ((m.text).startsWith('$')) {
if (!isOwner) return
exec(chats.slice(2), (err, stdout) => {
if(err) return sock.sendMessage(m.chat, {text: err.toString()}, {quoted: m})
if (stdout) return sock.sendMessage(m.chat, {text: util.format(stdout)}, {quoted: m})
})}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

if ((m.text).startsWith("=>")) {
if (!isOwner) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return sock.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: m})
} catch (e) {
return sock.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

if ((m.text).startsWith(">")) {
if (!isOwner) return
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
sock.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: m})
} catch (e) {
sock.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

}} catch (e) {
console.log(e)
sock.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "),
chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})